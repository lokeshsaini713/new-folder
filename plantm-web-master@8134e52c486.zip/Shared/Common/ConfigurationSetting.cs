﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Linq;
using System.Web;

namespace Shared.Common
{
    public static class ApplicationConstants
    {
        //"Admin", "Manager", "User", "Guest"
        public const bool LockoutOnFailure = true;
    }
   
}