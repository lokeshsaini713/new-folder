﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shared.Utilities
{
    /// <summary>
    /// 
    /// </summary>
    public class ConfigurationKey
    {
        public static string MailServer { get; set; }
        public static string Port { get; set; }
        public static string EnableSSL { get; set; }
        public static string EmailFromName { get; set; }
        public static string EmailFromAddress { get; set; }
        public static string MailAuthUser { get; set; }
        public static string MailAuthPass { get; set; }
        public static string EmailPath { get; set; }
        public static string EmailBCC { get; set; }
        public static string SaveImagePath { get; set; }
        public static string WebUrl { get; set; }
        public static string ProfilePicPath { get; set; }

        public static string AndroidInAppAccountEmail { get; set; }
        public static string AndroidInAppPackage { get; set; }
        public static string AndroidInAppCertificatePath { get; set; }

        public static string AdminForgetEmail { get; set; }
        public static string PathToSaveDocumentOrProfile { get; set; }
        public static string AdminMailId { get; internal set; }
        public static string DBConnectionString { get; set; }
    }
}