﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using Microsoft.Extensions.Configuration;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace Shared.Utilities
{
    
    internal class MailConfiguration
    {
        /// <summary>
        /// Constructs a new email sender with the default configuration options
        /// </summary>
        public MailConfiguration()
        {
            this.SmtpClient = new SmtpClient();
        }

        /// <summary>
        /// Constructs a new email sender an SMTP host name and port number
        /// </summary>
        /// <param name="host">The SMTP host name</param>
        /// <param name="port">The SMTP port number (optional)</param>
        public MailConfiguration(string host, int port = 25)
        {
            Contract.Requires(false == String.IsNullOrEmpty(host));
            Contract.Requires(port > 0);
            this.SmtpClient = new SmtpClient(host, port);
        }

        /// <summary>
        /// Constructs a new email sender with the SMTP client reference specified
        /// </summary>
        /// <param name="client">The SMTP client</param>
        public MailConfiguration(SmtpClient client)
        {
            Contract.Requires(client != null);
            this.SmtpClient = client;
        }

        /// <summary>
        /// Gets a reference to the SMTP client
        /// </summary>
        public SmtpClient SmtpClient { get; private set; }

        public IConfiguration Configuration { get; }

        /// <summary>
        /// Sends the specified message to an SMTP server for delivery
        /// </summary>
        /// <param name="message">The mail message to send</param>
        public virtual void Send(MailMessage message)
        {
            Contract.Requires(message != null);
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            this.SmtpClient.Host = "mail.24livehost.com";
            this.SmtpClient.Port = Convert.ToInt32(ConfigurationKey.Port);//Convert.ToInt32(Configuration["AppSettings:Port"]);
            this.SmtpClient.EnableSsl = Convert.ToBoolean(ConfigurationKey.EnableSSL);//Convert.ToBoolean(Configuration["AppSettings:EnableSSL"]);
            this.SmtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
            this.SmtpClient.Credentials = new System.Net.NetworkCredential(ConfigurationKey.MailAuthUser, ConfigurationKey.MailAuthPass);
            this.SmtpClient.Send(message);
        }

        /// <summary>
        /// Sends multiple messages to an SMTP for delivery
        /// </summary>
        /// <param name="messages">The mail messages to send</param>
        public void Send(IEnumerable<MailMessage> messages)
        {
            Contract.Requires(messages != null);

            foreach (var message in messages.ToList())
            {
                Send(message);
            }
        }

        /// <summary>
        /// Sends the specified e-mail message to an SMTP server for delivery
        /// </summary>
        /// <param name="from">The address information of the message sender</param>
        /// <param name="recipients">The addresses that the message is sent to</param>
        /// <param name="subject">The subject line for the message</param>
        /// <param name="body">The message body</param>
        public virtual void Send(string from, string recipients, string subject, string body)
        {
            Contract.Requires(false == String.IsNullOrEmpty(from));
            Contract.Requires(false == String.IsNullOrEmpty(recipients));
            Contract.Requires(false == String.IsNullOrEmpty(subject));

            this.SmtpClient.Send(from, recipients, subject, body);
        }

        /// <summary>
        /// Sends the specified message to an SMTP server for delivery as an asynchronous operation
        /// </summary>
        /// <param name="message">The mail message to send</param>
        /// <returns>The task object representing the asynchronous operation</returns>
        public virtual Task SendMailAsync(MailMessage message)
        {
            Contract.Requires(message != null);
            return this.SmtpClient.SendMailAsync(message);
        }

        /// <summary>
        /// Sends the specified message to an SMTP server for delivery as an asynchronous operation
        /// </summary>
        /// <param name="from">The address information of the message sender</param>
        /// <param name="recipients">The addresses that the message is sent to</param>
        /// <param name="subject">The subject line for the message</param>
        /// <param name="body">The message body</param>
        /// <returns>The task object representing the asynchronous operation</returns>
        public virtual Task SendMailAsync(string from, string recipients, string subject, string body)
        {
            Contract.Requires(false == String.IsNullOrEmpty(from));
            Contract.Requires(false == String.IsNullOrEmpty(recipients));
            Contract.Requires(false == String.IsNullOrEmpty(subject));
            return this.SmtpClient.SendMailAsync(from, recipients, subject, body);
        }
    }
}