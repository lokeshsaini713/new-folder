﻿using Shared.Utilities;
using Microsoft.AspNetCore.Http;

//using PlantMApp.ViewModel;

//using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using Shared.Utilities;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Shared.Utility
{
    public class CommonFunction
    {
        /// <summary>
        /// Gets the current date time.
        /// </summary>
        /// <returns></returns>
        public static DateTime GetCurrentDateTime()
        {
            return DateTime.UtcNow;
        }

        /// <summary>
        /// GetDescription -Provide enum description from enum value
        ///  short st = 1;
        /// ViewBag.Status1 = CommonFunctions.GetDescription((BookingStatus)st);
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>

        public static string GetDescription(Enum value)
        {
            var enumMember = value.GetType().GetMember(value.ToString()).FirstOrDefault();
            var descriptionAttribute =
                enumMember == null
                    ? default(DescriptionAttribute)
                    : enumMember.GetCustomAttribute(typeof(DescriptionAttribute)) as DescriptionAttribute;
            return
                descriptionAttribute == null
                    ? value.ToString()
                    : descriptionAttribute.Description;
        }


        public static List<SelectListItem> EnumToList<T>()
        {
            return (Enum.GetValues(typeof(T)).Cast<T>().Select(
                e => new SelectListItem() { Text = e.ToString(), Value = e.ToString() })).OrderBy(s => s.Text).ToList();
        }

        public static string Randomstring()
        {
            Random r = new Random();
            r.Next(100000, 999999);
            return r.Next(100000, 999999).ToString();
        }

    }
}