﻿using Newtonsoft.Json;
using Shared.Utilities;
using Shared.Utility;
using System;
using System.Collections.Generic;
using System.IO;


namespace Shared.Utilities
{
    public class EmailFunctions
    {
        public static string WebTemplatePath = "";
        public static string MailLogoPath = "";

        /// <summary>
        /// By this method we can send email through deligate
        /// </summary>
        /// <param name="emailHelper"></param>
        public static void SendEmailThroughDelegate(EmailHelperCore emailHelper)
        {
            try
            {
                System.Threading.Tasks.Task.Factory.StartNew(() =>
                {
                    emailHelper.Send();
                });
            }
            catch (Exception ex)
            {
            }
        }

        /// <summary>
        /// Sends the generate password email.
        /// </summary>
        /// <param name="toEmail">To email.</param>
        /// <param name="emailsubject">The emailsubject.</param>
        /// <param name="Name">The name.</param>
        /// <param name="ResetUrl">The reset URL.</param>
        /// <returns></returns>
        public static string SendGeneratePasswordEmail(string toEmail, string emailsubject, string Name, string ResetUrl)
        {
            try
            {
                var serverFilePath = string.Format("{0}{1}", WebTemplatePath, "GeneratePassword.html");

                var emailHelp = new EmailHelperCore
                {  

                Body = EmailHelperCore.GenerateEmailTemplateWithfull(serverFilePath,
                        new MessageKeyValue("##Name##", Name),
                         new MessageKeyValue("##Email##", toEmail),
                        new MessageKeyValue("##ResetUrl##", ResetUrl),
                        new MessageKeyValue("##ImagePath##", MailLogoPath)
                       ),

                    RecipientBCC = ConfigurationKey.EmailBCC,
                    Recipient = toEmail.ToLower(), //== ConfigurationKey.AdminMailId.ToLower() ? ConfigurationKey.AdminForgetEmail : toEmail,
                    Subject = emailsubject
                };
                SendEmailThroughDelegate(emailHelp);
            }
            catch (Exception ex)
            {
                string json = JsonConvert.SerializeObject(ex);
                return json+" --------------  "+ Path.GetFullPath(Path.Combine(ConfigurationKey.EmailPath + "\\GeneratePassword.html"));
            }
            return "";
        }

        /// <summary>
        /// Sends the reset password email.
        /// </summary>
        /// <param name="toEmail">To email.</param>
        /// <param name="emailsubject">The emailsubject.</param>
        /// <param name="Name">The name.</param>
        /// <param name="ResetUrl">The reset URL.</param>
        public static void SendResetPasswordEmail(string toEmail, string emailsubject, string Name, string ResetUrl)
        {
            var serverFilePath = string.Format("{0}{1}", WebTemplatePath, "ResetPassword.html");
            var emailHelp = new EmailHelperCore
            {
                Body = EmailHelperCore.GenerateEmailTemplateWithfull(serverFilePath,
                    new MessageKeyValue("##Name##", Name),
                    new MessageKeyValue("##ResetUrl##", ResetUrl),
                    new MessageKeyValue("##ImagePath##", MailLogoPath)
                   ),
                RecipientBCC = ConfigurationKey.EmailBCC,
                Recipient = toEmail.ToLower(),
                Subject = emailsubject
            };
            SendEmailThroughDelegate(emailHelp);
        }

        /// <summary>
        /// Testings email.
        /// </summary>
        /// <param name="toEmail">To email.</param>
        /// <param name="emailsubject">The emailsubject.</param>
        /// <param name="Name">The name.</param>
        public static void TestingEmail(string toEmail, string emailsubject, string Name, string body)
        {           
            var emailHelp = new EmailHelperCore
            {
                Body = body,//"This is a testing mail",
                RecipientBCC = ConfigurationKey.EmailBCC,
                Recipient = toEmail.ToLower(),
                Subject = emailsubject
            };
            SendEmailThroughDelegate(emailHelp);
        }

    }
}