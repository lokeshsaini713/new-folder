﻿using Shared.Models.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Shared.Models
{
    public class NurseryModel : BaseModel
    {
        public double? Lat { get; set; }
        public double? Lng { get; set; }
        [Display(Name = "Nursery address")]
        [Required(ErrorMessage = "Nursery address is required")]
        [StringLength(500, ErrorMessage = "Maximum 500 characters")]
        public string NurseryAddress { get; set; }

        [Display(Name = "Name")]
        [Required(ErrorMessage = "Name is required")]
        [StringLength(100, ErrorMessage = "Maximum 100 characters")]
        public string Name { get; set; }
        public string Mobile { get; set; }

        [Display(Name = "Contact Person")]
        [Required(ErrorMessage = "Contact person is required")]
        [StringLength(100, ErrorMessage = "Maximum 100 characters")]
        public string ContactPerson { get; set; }
    }
}
