﻿using Shared.Common;
using Shared.Models.Base;
using System;
using System.Collections.Generic;
using System.Text;

namespace Shared.Models
{
    public class QualityControlReportModel
    {
        //Id, IsActive, IsDeleted, CreatedOn, UpdatedOn
        //UserId, Name, AgencyId, NurseryId, Role, DOB, LastLoginOn, PlantingContractorId

        public long Id { get; set; }
       
        public string Name { get; set; }

        public DateTime UsageDate { get; set; }
        public string Compartment { get; set; }
        public int PlotStocking { get; set; }
        public int PlotNumber { get; set; }
        public string Loose { get; set; }
        public string JRoot { get; set; }
        public string SeedlingDamage { get; set; }
        public string PlantedUpsidedown { get; set; }
        public string Tooshallow { get; set; }
        public string Comments { get; set; }
        public decimal Latitude { get; set; }
        public decimal Longitude { get; set; }
        public string Coordinates { get; set; }
        public DateTime CreatedOn { get; set; }


    }
}