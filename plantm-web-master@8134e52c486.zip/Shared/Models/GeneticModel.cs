﻿using Shared.Models.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Shared.Models
{
    public class GeneticModel : BaseModel
    {
        [Display(Name = "Nursery")]
        [Required(ErrorMessage = "Nursery is required")]
        public long NurseryId { get; set; }       
       
        [Display(Name = "Genetic Name")]
        [Required(ErrorMessage = "Genetic Name is required")]
        [StringLength(100, ErrorMessage = "Maximum 100 characters")]
        public string Name { get; set; }
        public string NurseryName { get; set; }


      
    }


    public class GeneticModelV1 : BaseModel
    {
        [Display(Name = "Nursery")]
        [Required(ErrorMessage = "Nursery is required")]
        public long NurseryId { get; set; }

        public List<GeneticNameListModel> GeneticNameListModel { get; set; }

    }

    public class GeneticNameListModel : BaseModel
    {

        [Display(Name = "Genetic Name")]
        [Required(ErrorMessage = "Genetic Name is required")]
        [StringLength(100, ErrorMessage = "Maximum 100 characters")]
        public string Name { get; set; }
        public bool IsDelete { get; set; }
    }

}
