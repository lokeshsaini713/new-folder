﻿using Shared.Models.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Shared.Models
{
    public class LookUpModel : BaseModel
    {
        [Display(Name = "Parameter")]
        [Required(ErrorMessage = "Parameter is required")]
        public string GroupName { get; set; }

        [Display(Name = "Value")]
        [Required(ErrorMessage = "Value is required")]
        [StringLength(100, ErrorMessage = "Maximum 100 characters")]
        public string Value { get; set; }       
      
    }
}
