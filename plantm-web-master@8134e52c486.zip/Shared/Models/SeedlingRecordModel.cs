﻿using Shared.Models.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Shared.Models
{
   public class SeedlingDispatchRecordModel : BaseModel
    {
        public long OperatorId { get; set; }
        public DateTime UsageDate { get; set; }       
        public long ContactOperatorId { get; set; }      
        public long NurseryId { get; set; }      
        public long GeneticId { get; set; }
        [MaxLength(50)]
        public string Compartment { get; set; }
        public int Number { get; set; }
        [MaxLength(250)]
        public string Comments { get; set; }
        public DateTime SyncDate { get; set; }

       
        public string ContactOperator { get; set; }
        public string NurseryName { get; set; }
        public string GeneticName { get; set; }
     
    }
}
