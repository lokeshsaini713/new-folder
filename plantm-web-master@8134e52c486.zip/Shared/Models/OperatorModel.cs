﻿using Microsoft.AspNetCore.Http;
using Shared.Models.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Shared.Models
{
    public class OperatorModel : BaseModel
    {
        public string UserId { get; set; }
        [Required(ErrorMessage = "Operator name is required")]
        [StringLength(100, ErrorMessage = "Maximum 100 characters")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage ="Invalid email")]
        [StringLength(100, ErrorMessage = "Maximum 100 characters")]
        public string Email { get; set; }
        [Required(ErrorMessage = "Agency name is required")]
        public long AgencyId { get; set; }

        public string AgencyName { get; set; }


        [Required(ErrorMessage = "Plating contractor is required")]
        public long PlantingContractorId { get; set; }

        [Required(ErrorMessage = "Nursery name is required")]
        public long[] NurseryId { get; set; }

        public string NurseryName { get; set; }

        public string Role { get; set; }
        public DateTime DOB { get; set; }
        //public string ProfileImage { get; set; }
        public DateTime LastLoginOn { get; set; }

        public bool IsAccessUsage { get; set; }
        public bool IsAccessQC { get; set; }
        public bool IsAccessSeed { get; set; }

        //[Display(Name = "Browse File")]
        //public IFormFile file { get; set; }
    }
}
