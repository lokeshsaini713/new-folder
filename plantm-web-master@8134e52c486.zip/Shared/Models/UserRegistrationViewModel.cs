﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Shared.Models
{
    /// <summary>
    ///
    /// </summary>
    public class UserRegistrationViewModel
    {
        public string FullName { get; set; } //name

        [EmailAddress(ErrorMessage = "Invalid email address")]
        [Required(ErrorMessage = "Email is required")]
        public string Email { get; set; }
        
        [Required(ErrorMessage = "Password is required")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        
        [Required(ErrorMessage = "Password is required")]
        [DataType(DataType.Password)]
        public string ConfirmPassword { get; set; }

        public string Company { get; set; }
        
        public short UserType { get; set; }
        
        public string Department { get; set; }

        public string Country { get; set; }
        public string ProfileImage { get; set; }

        public IFormFile BusinessLogo { get; set; }
    }

    public class UserRegistrationResponseModel
    {
        public long PlantMId { get; set; }
        public string Name { get; set; }
        public string UserId { get; set; }
        public string Email { get; set; }
        public string UserType { get; set; }
        public string ProfilePic { get; set; }
        public string JwtToken { get; set; }
    }

    public class UserLoginViewModel
    {
        [EmailAddress(ErrorMessage = "Invalid email address")]
        [Required(ErrorMessage = "Please enter email address.")]
        [StringLength(100, ErrorMessage = "Max length should be 100 characters of Email")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Please enter password.")]
        public string Password { get; set; }

        public short DeviceType { get; set; }
        public string DeviceToken { get; set; }
        public short UserType { get; set; }
        public int TimezonoffsetInseconds { get; set; }
    }

    public class LoginResponseModel
    {
        public string UserId { get; set; }
        public long OperatorId { get; set; }
        public string PlantingContractor { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        //public string ProfileImage { get; set; }
        public string AuthorizationToken { get; set; }
        public DateTime TokenExpiredOn { get; set; }
        public int UserType { get; set; }
        public bool IsOnline { get; set; }
        public long DefaultAddressId { get; set; }
        public bool OperatorIsActive { get; set; }
        public bool OperatorIsDeleted { get; set; }
        public bool CallMasterDataAPI { get; set; }
        public string OperatorAccess { get; set; }
    }

    /// <summary>
    /// Forgot password request
    /// </summary>
    public class ForgotPassword
    {
        [EmailAddress(ErrorMessage = "Invalid email address")]
        [Required(ErrorMessage = "Email is required")]
        public string EmailID { get; set; }
    }
}