﻿using System.ComponentModel.DataAnnotations;


namespace Shared.Models
{

    /// <summary>
    /// Forgot Password Model
    /// </summary>
    public class ForgotPasswordModel
    {
        /// <summary>
        /// Gets or sets the email.
        /// </summary>
        /// <value>
        /// The email.
        /// </value>
        [Display(Name = "Email Address")]
        [Required(ErrorMessage = "Email address required")]
        [EmailAddress(ErrorMessage = "Invalid email address")]
        public string Email { get; set; }
    }
}
