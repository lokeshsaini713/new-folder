﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shared.Models
{
    public class SPGetSeedingDispatchListModel
    {
        public long Id { get; set; }
        public long ContactOperatorId { get; set; }
        public string ContactOperator { get; set; }
        public DateTime UsageDate { get; set; }
        public string Compartment { get; set; }
        public long NurseryId { get; set; }
        public string NurseryName { get; set; }
        public long GeneticId { get; set; }
        public string GeneticName { get; set; }
        public int Number { get; set; }
        public string Comments { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime SyncDate { get; set; }
    }
}
