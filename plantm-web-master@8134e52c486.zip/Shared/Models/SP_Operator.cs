﻿using Shared.Common;
using Shared.Models.Base;
using System;
using System.Collections.Generic;
using System.Text;

namespace Shared.Models.SP
{
    public class SP_Operator
    {
        //Id, IsActive, IsDeleted, CreatedOn, UpdatedOn
        //UserId, Name, AgencyId, NurseryId, Role, DOB, LastLoginOn, PlantingContractorId

        public long Id { get; set; }

        private DateTime? createDate;
        public DateTime? CreatedOn
        {
            get
            {
                if (createDate == null || createDate == DateTime.MinValue)
                {
                    createDate = DateTime.UtcNow.GetLocal();
                }
                return createDate.Value;
            }
            set { createDate = value; }
        }
        private DateTime? modificationDate;
        public DateTime? UpdatedOn
        {
            get
            {
                if (modificationDate == null || modificationDate == DateTime.MinValue)
                {
                    modificationDate = DateTime.UtcNow.GetLocal();
                }
                return modificationDate.Value;
            }
            set { modificationDate = value; }
        }

        private bool? isActive;
        public bool IsActive
        {
            get
            {
                return isActive ?? true;
            }
            set
            {
                isActive = value;
            }
        }

        private bool? isDeleted;
        public bool IsDeleted
        {
            get
            {
                return isDeleted ?? false;
            }
            set
            {
                isDeleted = value;
            }
        }

        public string UserId { get; set; }
        public string Name { get; set; }
        public long AgencyId { get; set; }
        public long PlantingContractorId { get; set; }
        public long NurseryId { get; set; }
        public string Role { get; set; }
        public DateTime DOB { get; set; }
        public DateTime LastLoginOn { get; set; }
    }

}