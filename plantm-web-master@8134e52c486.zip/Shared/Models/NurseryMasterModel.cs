﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shared.Models
{
    public class NurseryMasterModel
    {
        public long NurseryId { get; set; }
        public string NurseryName { get; set; }

        public List<NurseryGeneticModel> GeneticList { get; set; }
    }

    public class NurseryGeneticModel
    {
        public long GeneticId { get; set; }
        public string GeneticName { get; set; }
    }
}
