﻿using Shared.Models;
using Shared.Models.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.Models
{
    public class ExceptionModel : BaseModel
    {
        public string ExceptionType { get; set; }
        public string ExceptionMessage { get; set; }
        public string StackTrace { get; set; }
        public string APISource { get; set; }
        public string FunctionName { get; set; }
        public string SourceFileName { get; set; }
        public string ModelValues { get; set; }
    }
}