﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shared.Models
{
   public class SaveAllDataModel
    {
        /// <summary>
        /// Gets or sets the type.
        /// 1 for usage record
        /// 2 for QC records
        /// 3 for seedling records
        /// </summary>
        /// <value>
        /// The type.
        /// </value>
        public int Type { get; set; }

        public List<UsageRecordModel> usageRecordModel { get; set; }
        public List<QCRecordModel> qcRecordModel { get; set; }
        public List<SeedlingDispatchRecordModel> seedlingRecordModel { get; set; }
    }
}
