﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shared.Models
{
   public class SPGetUsageRecordListModel
    {
        public long Id { get; set; }
        public long OperatorId { get; set; }
        public string OperatorName { get; set; }
        public DateTime UsageDate { get; set; }
        public string Compartment { get; set; }
        public long NurseryId { get; set; }
        public string NurseryName { get; set; }
        public long GeneticId { get; set; }
        public string GeneticName { get; set; }
        public string PlantingContractor { get; set; }
        public short TargetStocking { get; set; }
        public short NumberPlanted { get; set; }
        public bool FireAffected { get; set; }
        public string SoilCondition { get; set; }
        public string Temp { get; set; }
        public string WeatherCondition { get; set; }
        public string Comments { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime SyncDate { get; set; }

       
    }
}
