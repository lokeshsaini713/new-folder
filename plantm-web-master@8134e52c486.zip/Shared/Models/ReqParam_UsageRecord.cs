﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shared.Models
{
    public class ReqParam_UsageRecord
    {
        //public DateTime FromDate { get; set; }
        //public DateTime ToDate { get; set; }

        public string UserId { get; set; }
        public int PageNo { get; set; }
        public int PageSize { get; set; }
    }
}
