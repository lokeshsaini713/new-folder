﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shared.Models
{
    public class UsageRecordMasterModel
    {
        public List<NurseryMasterModel> NurseryList { get; set; }
        public List<CommonTextValueModel> CompartmentList { get; set; }
        public List<CommonTextValueModel> AgencyList { get; set; }
        public List<CommonTextValueModel> LooseList { get; set; }
        public List<CommonTextValueModel> JRootList { get; set; }
        public List<CommonTextValueModel> SeedlingDamageList { get; set; }
        public List<CommonTextValueModel> PlantedUpsidedownList { get; set; }
        public List<ContactOperatorModel> ContactList { get; set; }
    }

    public class CommonTextValueModel
    {
        public string Text { get; set; }
        public string Value { get; set; }
    }

    public class ContactOperatorModel
    {
        public long OperatorId { get; set; }
        public string OperatorName { get; set; }
    }
}
