﻿using AutoMapper;
using Data.Entities;
using Data.IRepository;
using Services.Generic;
using Services.IServices;
using Shared.Models;
using Shared.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Services.Services
{
    public class NurseryService : GenericService<NurseryModel, NurseryEntity>, INurseryService
    {
        public NurseryService(IGenericDataRepository<NurseryEntity> repository, IMapper mapper) : base(repository, mapper)
        {

        }

        public List<NurseryMasterModel> GetAllNurseryWithGenetic(string UserId)
        {
            List<NurseryMasterModel> lstModel = new List<NurseryMasterModel>();

            var objOperator = this.repository.context.Operators.Where(e => e.UserId == UserId && e.IsDeleted == false).FirstOrDefault();


            var lstNursery = (from o in this.repository.context.Operators
                              join no in this.repository.context.OperatorNursery on o.Id equals no.OperatorId
                              join n in this.repository.context.Nurseries on no.NurseryId equals n.Id
                              select new
                              {
                                  NurseryId = n.Id,
                                  NurseryName = n.Name,
                                  OperatorId = no.OperatorId,
                                  IsNurseryDeleted = n.IsDeleted,
                                  IsNurseryActive = n.IsActive

                              }).Where(a => a.OperatorId == objOperator.Id && a.IsNurseryDeleted == false && a.IsNurseryActive == true).OrderBy(s => s.NurseryId).ToList();

            //var lstNursery = this.repository.context.Nurseries.Where(e => e.IsDeleted == false).ToList();

            if (lstNursery != null && lstNursery.Count > 0)
            {
                foreach (var nurseryItem in lstNursery)
                {
                    NurseryMasterModel nurseryModel = new NurseryMasterModel();

                    nurseryModel.NurseryId = nurseryItem.NurseryId;
                    nurseryModel.NurseryName = nurseryItem.NurseryName;

                    var lstGenetic = this.repository.context.Genetic.Where(e => e.NurseryId == nurseryItem.NurseryId && e.IsDeleted == false).ToList();

                    if (lstGenetic != null && lstGenetic.Count > 0)
                    {
                        nurseryModel.GeneticList = new List<NurseryGeneticModel>();
                        foreach (var geneticItem in lstGenetic)
                        {
                            NurseryGeneticModel geneticModel = new NurseryGeneticModel();

                            geneticModel.GeneticId = geneticItem.Id;
                            geneticModel.GeneticName = geneticItem.Name;

                            nurseryModel.GeneticList.Add(geneticModel);
                        }
                    }
                    else
                    {
                        nurseryModel.GeneticList = new List<NurseryGeneticModel>();
                    }
                    lstModel.Add(nurseryModel);
                }
            }

            if (lstModel != null && lstModel.Count > 0)
            {
                return lstModel;
            }
            else
            {
                return new List<NurseryMasterModel>();
            }

        }



        public override IList<NurseryModel> GetAll()
        {
            return base.GetAll().Where(s => s.IsActive == true && s.IsDeleted == false).OrderByDescending(a => a.CreatedOn).ToList();
        }

        public override IList<NurseryModel> GetListByUserId(string userId)
        {
            throw new NotImplementedException();
        }

        public override bool Remove(long id)
        {
            var lstGenetic = this.repository.context.Genetic.Where(e => e.NurseryId == id && e.IsDeleted == false).ToList();
            if (lstGenetic != null && lstGenetic.Count > 0)
            {
                foreach (var item in lstGenetic)
                {
                    var objGenetic = this.repository.context.Genetic.FirstOrDefault(e => e.Id == item.Id);
                    objGenetic.IsDeleted = true;
                    objGenetic.UpdatedOn = CommonFunction.GetCurrentDateTime();
                    this.repository.context.SaveChanges();
                }
            }
            return base.Remove(id);
        }

        public bool CheckExist(string NurseyName, long ID)
        {
            bool IsExist = false;
            var objData = repository.CheckExist(e => e.Name == NurseyName && e.IsDeleted == false);
            if (objData == null)
                IsExist = false;
            else
            {
                if (ID > 0)
                    IsExist = objData.Id == ID ? false : true;  // self exist then false
                else
                    IsExist = true;
            }
            return IsExist;
        }




    }
}
