﻿using Services.IService;
using Shared.Models;
using System;
using System.Collections.Generic;
using System.Text;
using Data.Context;
using Shared.Utility;
using Newtonsoft.Json;
using Shared.Utilities;
using System.Linq;
using Data.Entities;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Data.Entities.Identity;
using System.Globalization;

namespace Services.Services
{
    public class UserService : IUserService
    {
        private List<string> _errors = new List<string>();

        private PlantMAppContext dbContext;
        private readonly UserManager<User> _userManager;

        public UserService(PlantMAppContext dbContext, UserManager<User> userManager)
        {
            this.dbContext = dbContext;
            _userManager = userManager;
        }

        public void ManageLoginDeviceInfo(string userId, short deviceType, string deviceToken, string Token, int TimezoneOffsetInSeconds)
        {
            try
            {
                var deviceObj = dbContext.UserDeviceInfos.FirstOrDefault(x => x.UserId == userId);
                if (deviceObj != null)
                {
                    deviceObj.DeviceToken = deviceToken;
                    deviceObj.DeviceType = deviceType;
                    deviceObj.AuthorizationToken = Token;
                    deviceObj.UpdatedOn = DateTime.UtcNow;
                    deviceObj.TimezoneOffsetInSeconds = TimezoneOffsetInSeconds;
                    dbContext.UserDeviceInfos.Update(deviceObj);
                }
                else
                {
                    UserDeviceInfoEntity obj = new UserDeviceInfoEntity()
                    {
                        DeviceToken = deviceToken,
                        DeviceType = deviceType,
                        UserId = userId,
                        AuthorizationToken = Token,
                        CreatedOn = DateTime.UtcNow,
                        TimezoneOffsetInSeconds = TimezoneOffsetInSeconds
                    };
                    dbContext.UserDeviceInfos.Add(obj);
                }

                // save operator login date time

                var objOperator = dbContext.Operators.FirstOrDefault(x => x.UserId == userId);
                if (objOperator != null)
                {
                    objOperator.LastLoginOn = CommonFunction.GetCurrentDateTime();
                }

                dbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<bool> IsUserActiveOrNot(string userid)
        {
            var user = await _userManager.FindByIdAsync(userid);
            if (user != null)
            {
                return user.IsActive;
            }
            return false;
        }

        //public bool CheckSamePassword(string UserId, string OldPassword, string NewPassword)
        //{           
        //        var user = _userManager.Users.FirstOrDefault(a => a.Id == UserId);
        //        if (user != null)
        //        {
        //        if(user.PasswordHash == PasswordHasher<> )
        //            return user.IsActive;
        //        }
        //        return false;

        //}

        public ApiResponses<LoginResponseModel> GetLoginUserDetails(string userId)
        {
            LoginResponseModel model = new LoginResponseModel();
            try
            {
                var userObj = _userManager.FindByIdAsync(userId).Result;
                if (userObj != null)
                {
                    /// Get operator details
                    var objOperator = (from o in dbContext.Operators
                                       join l in dbContext.LookUp on o.PlantingContractorId equals l.Id
                                       select new
                                       {
                                           Name = o.Name,
                                           OperatorId = o.Id,
                                           PlantingContractor = l.Value,
                                           AspNetUserId = o.UserId,
                                           OperatorIsActive = o.IsActive,
                                           OperatorIsDelete = o.IsDeleted,
                                           Access = o.Role,
                                           Lastlogin = o.LastLoginOn
                                       }).Where(a => a.AspNetUserId == userObj.Id && a.OperatorIsDelete == false).FirstOrDefault();

                    if (objOperator != null && objOperator.OperatorId > 0)
                    {
                        model.Email = userObj.Email;
                        model.Name = string.IsNullOrEmpty(objOperator.Name) ? "" : objOperator.Name;
                        model.OperatorId = objOperator.OperatorId;
                        model.PlantingContractor = objOperator.PlantingContractor;
                        model.OperatorIsActive = objOperator.OperatorIsActive;
                        model.OperatorAccess = objOperator.Access;

                        var lstNursery = dbContext.Nurseries.Where(a => a.UpdatedOn > objOperator.Lastlogin).ToList();
                        if (lstNursery != null && lstNursery.Count > 0)
                        {
                            model.CallMasterDataAPI = true;
                        }

                        var lstGenetic = dbContext.Genetic.Where(a => a.UpdatedOn > objOperator.Lastlogin).ToList();
                        if (lstGenetic != null && lstGenetic.Count > 0)
                        {
                            model.CallMasterDataAPI = true;
                        }

                        var lstLookUp = dbContext.LookUp.Where(a => a.UpdatedOn > objOperator.Lastlogin).ToList();
                        if (lstLookUp != null && lstLookUp.Count > 0)
                        {
                            model.CallMasterDataAPI = true;
                        }

                        var lstOperators = dbContext.Operators.Where(a => a.UpdatedOn > objOperator.Lastlogin).ToList();
                        if (lstOperators != null && lstOperators.Count > 0)
                        {
                            model.CallMasterDataAPI = true;
                        }

                        return new ApiResponses<LoginResponseModel>(ResponseMsg.Ok, model, _errors, successMsg: ResponseStatus.success, apiName: "Login");
                    }
                    else
                    {
                        return new ApiResponses<LoginResponseModel>(ResponseMsg.Error, null, _errors, failureMsg: ResponseStatus.userNotFound, apiName: "Login");
                    }
                }
                else
                {
                    return new ApiResponses<LoginResponseModel>(ResponseMsg.Error, null, _errors, failureMsg: ResponseStatus.userNotFound, apiName: "Login");
                }
            }
            catch (Exception ex)
            {
                string InputData = string.Format(CultureInfo.InvariantCulture, "Id: {0}", userId);
                return new ApiResponses<LoginResponseModel>(ResponseMsg.Error, null, _errors, failureMsg: ResponseStatus.notFound, apiName: "Login");
            }
        }

        public ApiResponses<bool> Logout(string userId)
        {
            try
            {
                var deviceInfo = dbContext.UserDeviceInfos.Where(x => x.UserId == userId).FirstOrDefault();
                if (deviceInfo != null)
                {
                    //update user device info
                    deviceInfo.AuthorizationToken = "";
                    deviceInfo.DeviceToken = "";
                    deviceInfo.DeviceType = 0;
                    deviceInfo.UpdatedOn = CommonFunction.GetCurrentDateTime();
                    dbContext.UserDeviceInfos.Update(deviceInfo);
                    dbContext.SaveChanges();

                    return new ApiResponses<bool>(ResponseMsg.Ok, true, _errors, successMsg: ResponseStatus.LogOutSucessfully, apiName: "Logout");
                }
                else
                {
                    return new ApiResponses<bool>(ResponseMsg.Error, false, _errors, failureMsg: ResponseStatus.FailedToLogout, apiName: "Logout");
                }
            }
            catch (Exception ex)
            {
                return new ApiResponses<bool>(ResponseMsg.Error, false, _errors, failureMsg: ResponseStatus.FailedToLogout, apiName: "Logout");
            }
        }


        public ApiResponses<bool> CheckUserActiveDeleteStatus(string userId)
        {
            bool result = false;
            try
            {
                var user = dbContext.Users.Where(x => x.Id == userId).FirstOrDefault();
                if (user != null)
                {
                    if (user.IsActive == false || user.IsDeleted == true)
                    {
                        result = true;
                    }
                    else
                    {
                        result = false;
                    }

                    return new ApiResponses<bool>(ResponseMsg.Ok, result, _errors, successMsg: ResponseStatus.LogOutSucessfully, apiName: "CheckUserActiveDeleteStatus");
                }
                else
                {
                    return new ApiResponses<bool>(ResponseMsg.Error, result, _errors, failureMsg: ResponseStatus.FailedToLogout, apiName: "CheckUserActiveDeleteStatus");
                }
            }
            catch (Exception ex)
            {
                return new ApiResponses<bool>(ResponseMsg.Error, false, _errors, failureMsg: ResponseStatus.FailedToLogout, apiName: "CheckUserActiveDeleteStatus");
            }
        }

        public void UpdateUserToken(string userId, string Token)
        {
            try
            {
                var deviceObj = dbContext.UserDeviceInfos.FirstOrDefault(x => x.UserId == userId);
                if (deviceObj != null)
                {
                    deviceObj.DeviceToken = Token;
                    deviceObj.AuthorizationToken = Token;
                    deviceObj.UpdatedOn = DateTime.UtcNow;
                    dbContext.UserDeviceInfos.Update(deviceObj);
                    dbContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GetUserNameById(string UserId)
        {
            string UserName = string.Empty;
            try
            {
                var user = _userManager.FindByIdAsync(UserId).Result;
                if (user != null)
                {
                    UserName = user.UserName;
                }
                return UserName;
            }
            catch (Exception)
            {
                return UserName;
            }
        }

        public async Task<bool> SaveToken(string userId, string token, bool isUpdate)
        {
            var user = await _userManager.FindByIdAsync(userId);
            if (user != null)
            {
                if (isUpdate)
                {
                    user.ResetToken = "";
                }
                else
                {
                    user.ResetToken = token;
                }

                user.ModifiedDate = DateTime.UtcNow;
                await _userManager.UpdateAsync(user);
                return true;
            }
            else { return false; }
        }

        public bool IsPasswordResetWithToken(string userId)
        {
            var user = _userManager.FindByIdAsync(userId).Result;
            if (user != null)
            {
                if (string.IsNullOrEmpty(user.ResetToken))
                {
                    return true;
                }
                else { return false; }
            }
            else { return false; }
        }

        public void UpdateUserResetToken(string id, string token)
        {
            var user = _userManager.FindByIdAsync(id).Result;
            if (user != null)
            {
                user.ResetToken = token;
            }
            dbContext.SaveChanges();
        }


        #region Extra Functionalities

        /*
        public ApiResponses<bool> Register(UserRegistrationViewModel request, string userId)
        {
            try
            {
                PlantM technician = new PlantM
                {
                    UserId = userId,
                    Name = request.FullName,
                    Company = request.Company,
                    Department = request.Department,
                    Country = request.Country,
                    CreatedOn = DateTime.UtcNow,
                    IsActive = true,
                    IsDelete = false,
                    VehicleType = request.VehicleType,
                    ToeMeasurementType = request.ToeMeasurementType,
                };

                if (request.BusinessLogo != null)
                {
                    var ProfilePath = Common.SaveFile(new List<IFormFile> { request.BusinessLogo }, "\\BusinessLogo", null, request.ImageType);
                    technician.BusinessLogo = ProfilePath.FirstOrDefault();
                }

                dbContext.PlantM.Add(technician);
                dbContext.SaveChanges();
                //var responseModel = new UserRegistrationResponseModel
                //{
                //    Name = technician.Name,
                //    ProfilePic = technician.BusinessLogo,
                //    PlantMId = technician.Id
                //};

                return new ApiResponses<bool>(ResponseMsg.Ok, true, _errors, successMsg: ResponseStatus.YourAccountIsSuccessfullyCreated, apiName: "Register");
            }
            catch (Exception ex)
            {
                // delete created user if error occured
                dbContext.ChangeTracker.Entries()
                .Where(e => e.Entity != null).ToList()
                .ForEach(e => e.State = Microsoft.EntityFrameworkCore.EntityState.Detached);

                // RemoveCreatedUser(request.Email);

                return new ApiResponses<bool>(ResponseMsg.Error, false, _errors, failureMsg: JsonConvert.SerializeObject(ex), apiName: "Register");
            }
        }


          public async Task<ApiResponses<bool>> UpdatePlantMProfileAsync(long technicianId, UpdatePlantMProfileViewModel request)
        {
            try
            {
                var technician = await dbContext.PlantM.FirstOrDefaultAsync(x => x.Id == technicianId);
                if (technician != null)
                {
                    technician.Name = request.FullName;
                    technician.AlternativeEmail = request.AlternativeEmail;
                    technician.ToeMeasurementType = request.ToeMeasurementType;
                    technician.VehicleType = request.VehicleType;
                    technician.IsAutoSync = request.IsAutoSync;
                    technician.UpdatedOn = DateTime.UtcNow;
                }

                if (request.BusinessLogo != null)
                {
                    var ProfilePath = Common.SaveFile(new List<IFormFile> { request.BusinessLogo }, "/BusinessLogo");
                    technician.BusinessLogo = ProfilePath.FirstOrDefault();
                }

                dbContext.Entry(technician).State = EntityState.Modified;
                dbContext.SaveChanges();

                return new ApiResponses<bool>(ResponseMsg.Ok, true, _errors, successMsg: ResponseStatus.YourAccountIsSuccessfullyUpdated, apiName: "UpdatePlantMProfile");
            }
            catch (Exception ex)
            {
                // delete created user if error occured
                dbContext.ChangeTracker.Entries()
                .Where(e => e.Entity != null).ToList()
                .ForEach(e => e.State = Microsoft.EntityFrameworkCore.EntityState.Detached);

                // RemoveCreatedUser(request.Email);

                return new ApiResponses<bool>(ResponseMsg.Error, false, _errors, failureMsg: JsonConvert.SerializeObject(ex), apiName: "UpdatePlantMProfile");
            }
        }

        /// <summary>
        /// Gets the user data setting API.
        /// </summary>
        /// <param name="UserId">The user identifier.</param>
        /// <returns></returns>
        public async Task<ApiResponses<UserDataSettingResponseModel>> GetUserDataSettingAPI(string UserId)
        {
            UserDataSettingResponseModel respones = new UserDataSettingResponseModel();
            try
            {
                var technician = dbContext.PlantM.FirstOrDefault(x => x.UserId == UserId);
                if (technician != null)
                {
                    string sqlQuery = "EXEC [dbo].[GetPlantMDetailsById] @Id";
                    SqlParameter parameterTechId = new SqlParameter("@Id", technician.Id);

                    var techData = dbContext.GetPlantMDetailsById_Result.FromSqlRaw(sqlQuery, parameterTechId).ToList().FirstOrDefault();
                    if (techData != null)
                    {
                        respones.Id = techData.Id;
                        respones.PlantMName = techData.Name;
                        respones.Email = techData.Email;
                        respones.IsAutoSync = techData.IsAutoSync;
                        respones.ToeMeasurementType = techData.ToeMeasurementType;
                        respones.VehicleType = Common.GetDescription((VehicleType)techData.VehicleType);
                        respones.BusinessLogo = Common.GetImagePath(techData.BusinessLogo);
                        return new ApiResponses<UserDataSettingResponseModel>(ResponseMsg.Ok, respones, _errors, successMsg: ResponseStatus.UserDataSettingSuccess, apiName: "GetUserDataSettingAPI");
                    }
                    else
                    {
                        return new ApiResponses<UserDataSettingResponseModel>(ResponseMsg.Ok, respones, _errors, failureMsg: ResponseStatus.NoDataFound, apiName: "GetUserDataSettingAPI");
                    }
                }
                else
                {
                    return new ApiResponses<UserDataSettingResponseModel>(ResponseMsg.Ok, respones, _errors, failureMsg: ResponseStatus.NoDataFound, apiName: "GetUserDataSettingAPI");
                }
            }
            catch (Exception ex)
            {
                // delete created user if error occured
                dbContext.ChangeTracker.Entries()
                .Where(e => e.Entity != null).ToList()
                .ForEach(e => e.State = Microsoft.EntityFrameworkCore.EntityState.Detached);

                // RemoveCreatedUser(request.Email);

                return new ApiResponses<UserDataSettingResponseModel>(ResponseMsg.Error, null, _errors, failureMsg: ResponseStatus.ServerError, apiName: "GetUserDataSettingAPI");
            }
        }

        */

        #endregion
    }
}
