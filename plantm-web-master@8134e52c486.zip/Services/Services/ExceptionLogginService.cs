﻿using AutoMapper;
using Data.Entities;
using Data.Repository.GenericRepository;
using Newtonsoft.Json;
using Services.Generic;
using Services.IService;
using Shared.Common;
using Shared.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Services.Services
{
    /// <summary>
    /// Exception logging service
    /// </summary>
    public class ExceptionLogginService : GenericService<ExceptionModel, ExceptionEntity>, IExceptionLogginService
    {
        public ExceptionLogginService(GenericDataRepository<ExceptionEntity> repo, IMapper mapper) : base(repo, mapper)
        {
        }
        /// <summary>
        /// Save Exception details.
        /// </summary>
        /// <param name="model">exception model value for save.</param>
        /// <returns>Is successfullt save or not in terms of True/False</returns>
        public bool SaveException(ExceptionModel model)
        {

            try
            {
                LogExceptionInFile(model);

                if (model != null)
                {
                    var entity = mapper.Map<ExceptionEntity>(model);
                    repository.Add(entity);
                }
                return true;
            }
            catch (Exception ex)
            {
                ex.Log();
                return false;
            }
        }


        public void LogExceptionInFile(object model)
        {
            FileStream ostrm;
            StreamWriter writer;
            TextWriter oldOut = Console.Out;
            try
            {
                ostrm = new FileStream("./ExceptionLoggin.txt", FileMode.OpenOrCreate, FileAccess.Write);
                writer = new StreamWriter(ostrm);
            }
            catch (Exception e)
            {
                Console.WriteLine("Cannot open Redirect.txt for writing");
                Console.WriteLine(e.Message);
                return;
            }

            writer.WriteLine(JsonConvert.SerializeObject(model, Formatting.Indented) + "\n\n\n\n\n\n\n" + DateTime.UtcNow.GetLocal()
                .ToString());

            writer.Close();
            ostrm.Close();
        }

        /// <summary>
        /// Save Exception details.
        /// </summary>
        /// <param name="model">exception value for save.</param>
        /// <returns>Is successfullt save or not in terms of True/False</returns>
        public bool SaveException(Exception model)
        {
            try
            {
                //LogExceptionInFile(model);

                if (model != null)
                {
                    ExceptionEntity exe = new ExceptionEntity();
                    exe.CreatedOn = DateTime.UtcNow.GetLocal();
                    exe.UpdatedOn = DateTime.UtcNow.GetLocal();
                    exe.IsActive = true;
                    exe.IsDeleted = false;
                    exe.StackTrace = model.StackTrace;
                    exe.FunctionName = model.TargetSite.Name;
                    exe.SourceFileName = model.TargetSite.ReflectedType.FullName;
                    exe.APISource = model.Source;
                    exe.ExceptionType = model.GetType().Name;
                    exe.ExceptionMessage = model.ToString();
                    exe.ModelValues = string.Empty;

                    repository.Add(exe);
                }
                return true;
            }
            catch (Exception ex)
            {
                ex.Log();
                return false;
            }
        }
    }

    /// <summary>
    /// Exception logging extention method
    /// </summary>
    public static class ExceptionLoggerExtentionMetod
    {
        public static IExceptionLogginService service;
        /// <summary>
        /// Log the exception in DB
        /// </summary>
        /// <param name="model"></param>
        public static void Log(this Exception model)
        {
            if (model != null)
            {
                service?.SaveException(model);
            }
        }

        /// <summary>
        /// Log the exception model in DB
        /// </summary>
        /// <param name="model"></param>
        public static void Log(this ExceptionModel model)
        {
            if (model != null)
            {
                service?.SaveException(model);
            }
        }

        /// <summary>
        /// Get exception model from exception
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public static ExceptionModel GetExceptionModel(this Exception model)
        {
            ExceptionModel exe = new ExceptionModel();
            if (model != null)
            {

                exe.CreatedOn = DateTime.UtcNow.GetLocal();
                exe.UpdatedOn = DateTime.UtcNow.GetLocal();
                exe.IsActive = true;
                exe.IsDeleted = false;
                exe.StackTrace = model.StackTrace;
                exe.FunctionName = model.TargetSite.Name;
                exe.SourceFileName = model.TargetSite.ReflectedType.FullName;
                exe.APISource = model.Source;
                exe.ExceptionType = model.GetType().Name;
                exe.ExceptionMessage = model.ToString();

            }
            return exe;
        }

    }
}
