﻿using AutoMapper;
using Data.Entities;
using Data.IRepository;
using Services.Generic;
using Services.IServices;
using Shared.Models;
using Shared.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Services.Services
{
    public class LookUpService : GenericService<LookUpModel, LookUpEntity>, ILookUpService
    {
        public LookUpService(IGenericDataRepository<LookUpEntity> repository, IMapper mapper) : base(repository, mapper)
        {

        }

        /// <summary>
        /// Gets all parameters which is not deleted.
        /// </summary>
        /// <returns></returns>
        public override IList<LookUpModel> GetAll()
        {
            List<LookUpModel> lstLookUp = new List<LookUpModel>();
            var lookupData = repository.context.LookUp.Where(e => e.IsDeleted == false).OrderByDescending(a => a.Id).ToList();
            if (lookupData != null && lookupData.Count > 0)
            {
                foreach (var item in lookupData)
                {
                    LookUpModel model = new LookUpModel()
                    {
                        Id = item.Id,
                        GroupName = item.GroupName,
                        Value = item.Value,
                        IsActive = item.IsActive
                    };
                    lstLookUp.Add(model);
                }
            }
            return lstLookUp;
        }


        /// <summary>
        /// Gets the compartment list.
        /// </summary>
        /// <returns></returns>
        public List<CommonTextValueModel> GetCompartmentList()
        {
            List<CommonTextValueModel> lst = new List<CommonTextValueModel>();
            var lstCompartments = repository.context.LookUp.Where(e => e.GroupName == ParameterEnum.Compartments.ToString() && e.IsDeleted == false).ToList();
            if (lstCompartments != null && lstCompartments.Count > 0)
            {
                foreach (var item in lstCompartments)
                {
                    CommonTextValueModel model = new CommonTextValueModel();
                    model.Value = item.Id.ToString();
                    model.Text = item.Value;
                    lst.Add(model);
                }
            }
            if (lst != null && lst.Count > 0)
            {
                return lst;
            }
            else
            {
                return new List<CommonTextValueModel>();
            }
        }


        /// <summary>
        /// Gets the agency.
        /// </summary>
        /// <returns></returns>
        public List<CommonTextValueModel> GetAgency()
        {
            List<CommonTextValueModel> lst = new List<CommonTextValueModel>();
            var lstCompartments = repository.context.LookUp.Where(e => e.GroupName == ParameterEnum.Agency.ToString() && e.IsDeleted == false).ToList();
            if (lstCompartments != null && lstCompartments.Count > 0)
            {
                foreach (var item in lstCompartments)
                {
                    CommonTextValueModel model = new CommonTextValueModel();
                    model.Value = item.Id.ToString();
                    model.Text = item.Value;
                    lst.Add(model);
                }
            }
            if (lst != null && lst.Count > 0)
            {
                return lst;
            }
            else
            {
                return new List<CommonTextValueModel>();
            }
        }



        /// <summary>
        /// Gets the seedling damage.
        /// </summary>
        /// <returns></returns>
        //public List<CommonTextValueModel> GetSeedlingDamage()
        //{
        //    List<CommonTextValueModel> lst = new List<CommonTextValueModel>();
        //    var lstCompartments = repository.context.LookUp.Where(e => e.GroupName == ParameterEnum.SeedlingDamage.ToString() && e.IsDeleted == false).ToList();
        //    if (lstCompartments != null && lstCompartments.Count > 0)
        //    {
        //        foreach (var item in lstCompartments)
        //        {
        //            CommonTextValueModel model = new CommonTextValueModel();
        //            model.Value = item.Id.ToString();
        //            model.Text = item.Value;
        //            lst.Add(model);
        //        }
        //    }
        //    if (lst != null && lst.Count > 0)
        //    {
        //        return lst;
        //    }
        //    else
        //    {
        //        return new List<CommonTextValueModel>();
        //    }
        //}

        /// <summary>
        /// Gets the list by user identifier.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public override IList<LookUpModel> GetListByUserId(string userId)
        {
            throw new NotImplementedException();
        }


        /// <summary>
        /// Checks the exist.
        /// </summary>
        /// <param name="GroupName">Name of the group.</param>
        /// <param name="Value">The value.</param>
        /// <param name="ID">The identifier.</param>
        /// <returns></returns>
        public bool CheckExist(string GroupName, string Value, long ID)
        {
            bool IsExist = false;
            var objData = repository.CheckExist(e => e.GroupName == GroupName && e.Value == Value && e.IsDeleted == false);
            if (objData == null)
                IsExist = false;
            else
            {
                if (ID > 0)
                    IsExist = objData.Id == ID ? false : true;  // self exist then false
                else
                    IsExist = true;
            }
            return IsExist;
        }
    }
}
