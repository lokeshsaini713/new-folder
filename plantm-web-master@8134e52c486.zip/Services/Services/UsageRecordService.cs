﻿using Services.IService;
using Shared.Models;
using System;
using System.Collections.Generic;
using System.Text;
using Data.Context;
using Shared.Utility;
using Newtonsoft.Json;
using Shared.Utilities;
using System.Linq;
using Data.Entities;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Data.Entities.Identity;
using System.Globalization;
using Services.Generic;
using Data.IRepository;
using AutoMapper;
using Shared.Models.SP;
using MySql.Data.MySqlClient;

namespace Services.Services
{
    public class UsageRecordService : GenericService<UsageRecordModel, UsageRecordEntity>, IUsageRecordService
    {

        public UsageRecordService(IGenericDataRepository<UsageRecordEntity> repository, IMapper mapper) : base(repository, mapper)
        {

        }



        public List<UsageRecordModel> GetUsageRecordList(DateTime? FromDate, DateTime? ToDate)
        {
            try
            {              
                MySqlParameter[] param = { new MySqlParameter("@FromDate",FromDate == null ? null : FromDate.Value.ToString("yyyy-MM-dd")),
                                       new MySqlParameter("@ToDate",ToDate == null ? null : ToDate.Value.ToString("yyyy-MM-dd"))};
                var result = this.repository.SqlQuery<SPGetUsageRecordListModel>("CALL GetUsageRecordList(@FromDate,@ToDate)", param);
                var obj = mapper.Map<List<UsageRecordModel>>(result);
                return obj;

            }
            catch (Exception ex)
            {
                return new List<UsageRecordModel>();
            }
        }


        public List<UsageRecordModel> GetUsageRecordListPagging(ReqParam_UsageRecord model)
        {
            try
            {
                var objOperator = this.repository.context.Operators.FirstOrDefault(a => a.UserId == model.UserId);

                MySqlParameter[] param = {new MySqlParameter("@PageNo",model.PageNo),
                                          new MySqlParameter("@PageSize",model.PageSize),
                                          new MySqlParameter("@OperatorId",objOperator.Id)};
                var result = this.repository.SqlQueryAPI<SPGetUsageRecordListModel>("CALL GetUsageRecordForAPI(@PageNo,@PageSize,@OperatorId)", param);
                var obj = mapper.Map<List<UsageRecordModel>>(result);
                return obj;
            }
            catch (Exception ex)
            {
                return new List<UsageRecordModel>();
            }
        }


        public List<UsageRecordModel> GetUsageRecordListByOperator(string UserId)
        {
            var objOperator = this.repository.context.Operators.FirstOrDefault(a => a.UserId == UserId);

            MySqlParameter[] param = { new MySqlParameter("@OperatorId", objOperator.Id)
                                       };
            var result = this.repository.SqlQuery<SPGetUsageRecordListModel>("CALL GetUsageRecordList(@OperatorId)", param);
            var obj = mapper.Map<List<UsageRecordModel>>(result);
            return obj;
        }


        public bool SaveUsageData(List<UsageRecordModel> model)
        {
            try
            {
                if (model != null && model.Count > 0)
                {
                    foreach (var item in model)
                    {
                        if (item != null && item.OperatorId > 0)
                        {
                            UsageRecordEntity obj = new UsageRecordEntity()
                            {
                                UsageDate = item.UsageDate,
                                PlantingContractor = item.PlantingContractor,
                                NurseryId = item.NurseryId,
                                GeneticId = item.GeneticId,
                                OperatorId = item.OperatorId,
                                Compartment = item.Compartment,
                                TargetStocking = item.TargetStocking,
                                NumberPlanted = item.NumberPlanted,
                                FireAffected = item.FireAffected,
                                SoilCondition = item.SoilCondition,
                                Temp = item.Temp,
                                WeatherCondition = item.WeatherCondition,
                                Comments = item.Comments,
                                IsActive = true,
                                IsDeleted = false,
                                CreatedOn = item.CreatedOn.Value,
                                SyncDate = CommonFunction.GetCurrentDateTime()
                            };
                            repository.context.UsageRecord.Add(obj);
                        }
                        else
                        {
                            return false;
                        }
                    }
                    repository.context.SaveChanges();
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
        }




    }
}
