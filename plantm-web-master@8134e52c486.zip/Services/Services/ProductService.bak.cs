﻿using AutoMapper;
using Data.Entities;
using Data.IRepository;
using Data.Repository.GenericRepository;
using Services.Generic;
using Services.IServices;
using Shared.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Services.Services
{
    public class ProductService : GenericService<ProductModel, ProductEntity>, IProductService
    {
        public ProductService(IGenericDataRepository<ProductEntity> repo, IMapper mapper) : base(repo, mapper)
        {

        }
        public override void Add(params ProductModel[] items)
        {
            base.Add(items);
        }

        public override IList<ProductModel> GetAll()
        {
            return base.GetAll();
        }

        public override ProductModel GetById(long Id)
        {
            return base.GetById(Id);
        }

        public override IList<ProductModel> GetListByUserId(long userId)
        {
            return base.GetListByUserId(userId);
        }

        public override void Remove(params ProductModel[] items)
        {
            base.Remove(items);
        }

        public override void Remove(long id)
        {
            base.Remove(id);
        }

        public override void Update(params ProductModel[] items)
        {
            base.Update(items);
        }
    }
}
