﻿using Services.IService;
using Shared.Models;
using System;
using System.Collections.Generic;
using System.Text;
using Data.Context;
using Shared.Utility;
using Newtonsoft.Json;
using Shared.Utilities;
using System.Linq;
using Data.Entities;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Data.Entities.Identity;
using System.Globalization;
using Services.Generic;
using Data.IRepository;
using AutoMapper;
using MySql.Data.MySqlClient;

namespace Services.Services
{
    public class QCRecordService : GenericService<QCRecordModel, QCRecordEntity>, IQCRecordService
    {

        public QCRecordService(IGenericDataRepository<QCRecordEntity> repository, IMapper mapper) : base(repository, mapper)
        {

        }

        public bool SaveQCRecord(List<QCRecordModel> model)
        {
            try
            {
                if (model != null && model.Count > 0)
                {
                    foreach (var item in model)
                    {
                        if (item.OperatorId > 0)
                        {
                            QCRecordEntity obj = new QCRecordEntity()
                            {
                                UsageDate = item.UsageDate,
                                OperatorId = item.OperatorId,
                                Compartment = item.Compartment,
                                JRoot = item.JRoot,
                                Latitude = item.Latitude,
                                Longitude = item.Longitude,
                                Loose = item.Loose,
                                PlantedUpsidedown = item.PlantedUpsidedown,
                                PlotNumber = item.PlotNumber,
                                PlotStocking = item.PlotStocking,
                                SeedlingDamage = item.SeedlingDamage,
                                Tooshallow = item.Tooshallow,
                                Comments = item.Comments,
                                IsActive = true,
                                IsDeleted = false,
                                CreatedOn = item.CreatedOn.Value,
                                SyncDate = CommonFunction.GetCurrentDateTime()
                            };
                            repository.context.QCRecord.Add(obj);
                        }
                        else
                        {
                            return false;
                        }
                    }
                    repository.context.SaveChanges();
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
        }



        public List<QCRecordModel> GetQCReportList(DateTime? FromDate, DateTime? ToDate)
        {
            try
            {
                MySqlParameter[] param = { new MySqlParameter("@FromDate", FromDate == null ? null : FromDate.Value.ToString("yyyy-MM-dd")),
                                       new MySqlParameter("@ToDate",ToDate == null ? null : ToDate.Value.ToString("yyyy-MM-dd"))};
                var result = this.repository.SqlQuery<QualityControlReportModel>("CALL GetQualityControlReportList(@FromDate,@ToDate)", param);

                var obj = mapper.Map<List<QCRecordModel>>(result);
                return obj;
            }
            catch (Exception ex)
            {
                return new List<QCRecordModel>();
            }
        }

    }
}
