﻿using AutoMapper;
using Data.Entities;
using Data.Entities.Identity;
using Data.IRepository;
using Services.Generic;
using Services.IServices;
using Shared.Models;
using System;
using System.Collections.Generic;
using System.Text;
using Data.Context;
using Data.Entities.Base;
using Microsoft.EntityFrameworkCore;
using Shared.Common;
using System.Linq;
using System.Linq.Expressions;
using Shared.Utility;
using MySql.Data.MySqlClient;
using Shared.Models.SP;
using Shared.Utilities;

namespace Services.Services
{
    public class OperatorService : GenericService<OperatorModel, OperatorEntity>, IOperatorService
    {
        public OperatorService(IGenericDataRepository<OperatorEntity> repository, IGenericDataRepository<User> userRepository, IMapper mapper) : base(repository, mapper)
        {

        }

        public override IList<OperatorModel> GetListByUserId(string userId)
        {
            throw new NotImplementedException();
        }

        public override bool Add(params OperatorModel[] items)
        {
            bool result = false;
            try
            {
                foreach (var item in items)
                {
                    string access = "";

                    if (item.IsAccessUsage == true)
                    {
                        access = OperatorAccessEnum.Usage.ToDescriptionString();
                    }
                    if (item.IsAccessQC == true)
                    {
                        access = !string.IsNullOrEmpty(access) ? access + "#" + OperatorAccessEnum.QC.ToDescriptionString() : OperatorAccessEnum.QC.ToDescriptionString();
                    }
                    if (item.IsAccessSeed == true)
                    {
                        access = !string.IsNullOrEmpty(access) ? access + "#" + OperatorAccessEnum.Seed.ToDescriptionString() : OperatorAccessEnum.Seed.ToDescriptionString();
                    }

                    OperatorEntity operatorEntity = new OperatorEntity();

                    operatorEntity.Name = item.Name;
                    operatorEntity.PlantingContractorId = item.PlantingContractorId;
                    operatorEntity.UserId = item.UserId;
                    operatorEntity.AgencyId = item.AgencyId;
                    operatorEntity.IsActive = true;
                    operatorEntity.IsDeleted = false;
                    operatorEntity.Role = access;
                    operatorEntity.CreatedOn = CommonFunction.GetCurrentDateTime();
                    this.repository.context.Operators.Add(operatorEntity);
                    this.repository.context.SaveChanges();

                    if (operatorEntity.Id > 0)
                    {
                        foreach (var nurseryItem in item.NurseryId)
                        {
                            OperatorNurseryEntity objOperatorNursery = new OperatorNurseryEntity();
                            objOperatorNursery.NurseryId = nurseryItem;
                            objOperatorNursery.OperatorId = operatorEntity.Id;

                            this.repository.context.OperatorNursery.Add(objOperatorNursery);
                        }
                        this.repository.context.SaveChanges();
                        result = true;
                    }
                    else
                    {
                        result = true;
                    }
                }
            }
            catch (Exception ex)
            {
                result = false;
            }
            return result;
        }


        public override bool Update(params OperatorModel[] items)
        {
            try
            {
                foreach (var item in items)
                {
                    string access = "";

                    if (item.IsAccessUsage == true)
                    {
                        access = OperatorAccessEnum.Usage.ToDescriptionString();
                    }
                    if (item.IsAccessQC == true)
                    {
                        access = !string.IsNullOrEmpty(access) ? access + "#" + OperatorAccessEnum.QC.ToDescriptionString() : OperatorAccessEnum.QC.ToDescriptionString();
                    }
                    if (item.IsAccessSeed == true)
                    {
                        access = !string.IsNullOrEmpty(access) ? access + "#" + OperatorAccessEnum.Seed.ToDescriptionString() : OperatorAccessEnum.Seed.ToDescriptionString();
                    }

                    var operatorEntity = this.repository.context.Operators.FirstOrDefault(e => e.Id == item.Id);
                    operatorEntity.Name = item.Name;
                    operatorEntity.Role = access;
                    operatorEntity.AgencyId = item.AgencyId;
                    operatorEntity.PlantingContractorId = item.PlantingContractorId;
                    operatorEntity.UpdatedOn = CommonFunction.GetCurrentDateTime();

                    var getOperatorNursery = this.repository.context.OperatorNursery.Where(a => a.OperatorId == item.Id).ToList();
                    if (getOperatorNursery != null && getOperatorNursery.Count > 0)
                    {
                        this.repository.context.OperatorNursery.RemoveRange(getOperatorNursery);
                        this.repository.context.SaveChanges();
                    }

                    foreach (var nurseryItem in item.NurseryId)
                    {
                        OperatorNurseryEntity objOperatorNursery = new OperatorNurseryEntity();
                        objOperatorNursery.NurseryId = nurseryItem;
                        objOperatorNursery.OperatorId = operatorEntity.Id;

                        this.repository.context.OperatorNursery.Add(objOperatorNursery);
                    }
                    this.repository.context.SaveChanges();
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }


        public OperatorModel GetOperatorById(long Id)
        {
            OperatorModel objOperator = new OperatorModel();

            var objData = (from o in this.repository.context.Operators
                           join u in this.repository.context.Users on o.UserId equals u.Id
                           select new
                           {
                               Name = o.Name,
                               Email = u.Email,
                               AspNetId = o.UserId,
                               OperatorId = o.Id,
                               AgencyId = o.AgencyId,
                               IsActive = u.IsActive,
                               OperatorIsActive = o.IsActive,
                               OperatorIsDelete = o.IsDeleted,
                               PlantingContractorId = o.PlantingContractorId,
                               OperatorCreatedOn = o.CreatedOn,
                               Access = o.Role

                           }).Where(a => a.OperatorId == Id && a.OperatorIsDelete == false).FirstOrDefault();

            if (objData != null)
            {
                if (!string.IsNullOrEmpty(objData.Access))
                {
                    var splitAccess = objData.Access.Split("#");
                    foreach (var item in splitAccess)
                    {
                        if (item == OperatorAccessEnum.Usage.ToDescriptionString())
                        {
                            objOperator.IsAccessUsage = true;
                        }
                        else if (item == OperatorAccessEnum.QC.ToDescriptionString())
                        {
                            objOperator.IsAccessQC = true;
                        }
                        else if (item == OperatorAccessEnum.Seed.ToDescriptionString())
                        {
                            objOperator.IsAccessSeed = true;
                        }
                    }
                }

                objOperator.Id = objData.OperatorId;
                objOperator.Name = objData.Name;
                objOperator.IsDeleted = objData.OperatorIsDelete;
                objOperator.IsActive = objData.OperatorIsActive;
                objOperator.Email = objData.Email;
                objOperator.PlantingContractorId = objData.PlantingContractorId;
                objOperator.AgencyId = objData.AgencyId;
                objOperator.CreatedOn = objData.OperatorCreatedOn;
                objOperator.UserId = objData.AspNetId;

                var lstNursery = this.repository.context.OperatorNursery.Where(a => a.OperatorId == objData.OperatorId).ToList();
                if (lstNursery != null && lstNursery.Count > 0)
                {
                    objOperator.NurseryId = new long[lstNursery.Count];

                    objOperator.NurseryId = lstNursery.Select(a => a.NurseryId).ToArray();
                }
            }
            return objOperator;
        }

        public List<ContactOperatorModel> GetContactOperatorlist(string UserId)
        {
            var objOperator = this.repository.context.Operators.FirstOrDefault(x => x.UserId == UserId);

            var listData = this.repository.context.Operators.Where(a => a.Id != objOperator.Id && a.IsActive == true && a.IsDeleted == false).OrderBy(s => s.Name).ToList();

            List<ContactOperatorModel> list = new List<ContactOperatorModel>();

            if (listData != null && listData.Count > 0)
            {
                foreach (var item in listData)
                {
                    ContactOperatorModel Operator = new ContactOperatorModel();

                    Operator.OperatorId = item.Id;
                    Operator.OperatorName = item.Name;

                    list.Add(Operator);
                }
            }
            if (list != null && list.Count > 0)
            {
                return list;
            }
            else
            {
                return new List<ContactOperatorModel>();
            }
        }

        public List<OperatorModel> GetOperatorlist()
        {
            var listData = (from o in this.repository.context.Operators
                            join u in this.repository.context.Users on o.UserId equals u.Id
                            join l in this.repository.context.LookUp on o.AgencyId equals l.Id
                            join lPC in this.repository.context.LookUp on o.PlantingContractorId equals lPC.Id
                            select new
                            {
                                Name = o.Name,
                                Email = u.Email,
                                AspNetId = o.UserId,
                                OperatorId = o.Id,
                                AgencyId = o.AgencyId,
                                AgencyName = l.Value,
                                PlantingContractorId = o.PlantingContractorId,
                                PlantingContractorName = lPC.Value,
                                IsActive = u.IsActive,
                                OperatorIsActive = o.IsActive,
                                OperatorIsDelete = o.IsDeleted,
                                OperatorCreatedOn = o.CreatedOn

                            }).Where(a => a.OperatorIsDelete == false).OrderByDescending(s => s.OperatorCreatedOn).ToList();

            List<OperatorModel> list = new List<OperatorModel>();

            if (listData != null && listData.Count > 0)
            {
                foreach (var item in listData)
                {
                    OperatorModel objOperator = new OperatorModel();

                    objOperator.Id = item.OperatorId;
                    objOperator.UserId = item.AspNetId;
                    objOperator.Name = item.Name;
                    objOperator.IsDeleted = item.OperatorIsDelete;
                    objOperator.IsActive = item.OperatorIsActive;
                    objOperator.Email = item.Email;
                    objOperator.AgencyId = item.AgencyId;
                    objOperator.AgencyName = item.AgencyName;
                    objOperator.CreatedOn = item.OperatorCreatedOn;

                    list.Add(objOperator);
                }
            }
            return list;
        }

        public override bool ChangeStatus(long id)
        {
            bool result = false;
            var objOperator = this.repository.context.Operators.FirstOrDefault(a => a.Id == id);
            if (objOperator != null)
            {
                var objUser = this.repository.context.Users.FirstOrDefault(s => s.Id == objOperator.UserId);
                if (objUser != null)
                {
                    if (objOperator.IsActive == true)
                    {
                        objOperator.IsActive = false;
                    }
                    else
                    {
                        objOperator.IsActive = true;
                    }

                    if (objUser.IsActive == true)
                    {
                        objUser.IsActive = false;
                    }
                    else
                    {
                        objUser.IsActive = true;
                    }
                    objOperator.UpdatedOn = CommonFunction.GetCurrentDateTime();
                    objUser.ModifiedDate = CommonFunction.GetCurrentDateTime();
                    this.repository.context.SaveChanges();
                    result = true;
                }
            }
            return result;
        }


        public override bool Remove(long id)
        {
            bool result = false;
            var objOperator = this.repository.context.Operators.FirstOrDefault(a => a.Id == id);
            if (objOperator != null)
            {
                var objUser = this.repository.context.Users.FirstOrDefault(s => s.Id == objOperator.UserId);
                if (objUser != null)
                {
                    objOperator.IsDeleted = true;
                    objUser.IsDeleted = true;

                    objOperator.UpdatedOn = CommonFunction.GetCurrentDateTime();
                    objUser.ModifiedDate = CommonFunction.GetCurrentDateTime();
                    this.repository.context.SaveChanges();
                    result = true;
                }
            }
            return result;
        }

    }
}
