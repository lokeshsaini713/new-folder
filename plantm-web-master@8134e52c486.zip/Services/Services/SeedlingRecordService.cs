﻿using Services.IService;
using Shared.Models;
using System;
using System.Collections.Generic;
using System.Text;
using Data.Context;
using Shared.Utility;
using Newtonsoft.Json;
using Shared.Utilities;
using System.Linq;
using Data.Entities;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Data.Entities.Identity;
using System.Globalization;
using Services.Generic;
using Data.IRepository;
using AutoMapper;
using MySql.Data.MySqlClient;

namespace Services.Services
{
    public class SeedlingRecordService : GenericService<SeedlingDispatchRecordModel, SeedlingRecordEntity>, ISeedlingRecordService
    {
        private readonly IQCRecordService _qCRecordService;
        private readonly IUsageRecordService _usageRecordService;

        public SeedlingRecordService(IGenericDataRepository<SeedlingRecordEntity> repository, IMapper mapper) : base(repository, mapper)
        {

        }



        /// <summary>
        /// Gets the seedling dispatch report list.
        /// </summary>
        /// <param name="FromDate">From date.</param>
        /// <param name="ToDate">To date.</param>
        /// <returns></returns>
        public List<SeedlingDispatchRecordModel> GetSeedlingDispatchReportList(DateTime? FromDate, DateTime? ToDate)
        {
            try
            {
                MySqlParameter[] param = { new MySqlParameter("@FromDate", FromDate == null ? null : FromDate.Value.ToString("yyyy-MM-dd")),
                                       new MySqlParameter("@ToDate",ToDate == null ? null : ToDate.Value.ToString("yyyy-MM-dd"))};
                var result = this.repository.SqlQuery<SPGetSeedingDispatchListModel>("CALL GetSeedingDispatchList(@FromDate,@ToDate)", param);
                var obj = mapper.Map<List<SeedlingDispatchRecordModel>>(result);
                return obj;
            }
            catch (Exception ex)
            {
                return new List<SeedlingDispatchRecordModel>();
            }
        }


        public bool SaveSeedlingRecord(List<SeedlingDispatchRecordModel> model)
        {
            try
            {
                if (model != null && model.Count > 0)
                {
                    foreach (var item in model)
                    {
                        if (item.OperatorId > 0)
                        {
                            SeedlingRecordEntity obj = new SeedlingRecordEntity()
                            {
                                UsageDate = item.UsageDate,
                                NurseryId = item.NurseryId,
                                GeneticId = item.GeneticId,
                                OperatorId = item.OperatorId,
                                Compartment = item.Compartment,
                                Comments = item.Comments,
                                ContactOperatorId = item.ContactOperatorId,
                                Number = item.Number,
                                IsActive = true,
                                IsDeleted = false,
                                CreatedOn = item.CreatedOn.Value,
                                SyncDate = CommonFunction.GetCurrentDateTime()
                            };
                            repository.context.SeedlingRecord.Add(obj);
                        }
                        else
                        {
                            return false;
                        }
                    }
                    repository.context.SaveChanges();
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool SaveUsageData(List<UsageRecordModel> model)
        {
            try
            {
                if (model != null && model.Count > 0)
                {
                    foreach (var item in model)
                    {
                        if (item != null && item.OperatorId > 0)
                        {
                            UsageRecordEntity obj = new UsageRecordEntity()
                            {
                                UsageDate = item.UsageDate,
                                PlantingContractor = item.PlantingContractor,
                                NurseryId = item.NurseryId,
                                GeneticId = item.GeneticId,
                                OperatorId = item.OperatorId,
                                Compartment = item.Compartment,
                                TargetStocking = item.TargetStocking,
                                NumberPlanted = item.NumberPlanted,
                                FireAffected = item.FireAffected,
                                SoilCondition = item.SoilCondition,
                                Temp = item.Temp,
                                WeatherCondition = item.WeatherCondition,
                                Comments = item.Comments,
                                IsActive = true,
                                IsDeleted = false,
                                CreatedOn = item.CreatedOn.Value,
                                SyncDate = CommonFunction.GetCurrentDateTime()
                            };
                            repository.context.UsageRecord.Add(obj);
                        }
                        else
                        {
                            return false;
                        }
                    }
                    repository.context.SaveChanges();
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool SaveQCRecord(List<QCRecordModel> model)
        {
            try
            {
                if (model != null && model.Count > 0)
                {
                    foreach (var item in model)
                    {
                        if (item.OperatorId > 0)
                        {
                            QCRecordEntity obj = new QCRecordEntity()
                            {
                                UsageDate = item.UsageDate,
                                OperatorId = item.OperatorId,
                                Compartment = item.Compartment,
                                JRoot = item.JRoot,
                                Latitude = item.Latitude,
                                Longitude = item.Longitude,
                                Loose = item.Loose,
                                PlantedUpsidedown = item.PlantedUpsidedown,
                                PlotNumber = item.PlotNumber,
                                PlotStocking = item.PlotStocking,
                                SeedlingDamage = item.SeedlingDamage,
                                Tooshallow = item.Tooshallow,
                                Comments = item.Comments,
                                IsActive = true,
                                IsDeleted = false,
                                CreatedOn = item.CreatedOn.Value,
                                SyncDate = CommonFunction.GetCurrentDateTime()
                            };
                            repository.context.QCRecord.Add(obj);
                        }
                        else
                        {
                            return false;
                        }
                    }
                    repository.context.SaveChanges();
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool SaveAllData(List<SaveAllDataModel> model)
        {
            bool result = false;

            foreach (var item in model)
            {
                try
                {
                    if (item.Type == 1)
                    {
                        result = SaveUsageData(item.usageRecordModel);
                    }
                    else if (item.Type == 2)
                    {
                        result = SaveQCRecord(item.qcRecordModel);
                    }
                    else
                    {
                        result = SaveSeedlingRecord(item.seedlingRecordModel);
                    }
                    result = true;
                }
                catch (Exception ex)
                {
                    result = false;
                }
            }
            return result;
        }


    }
}
