﻿using AutoMapper;
using Data.Entities;
using Data.Entities.Identity;
using Data.IRepository;
using Services.Generic;
using Services.IServices;
using Shared.Models;
using System;
using System.Collections.Generic;
using System.Text;
using Data.Context;
using Data.Entities.Base;
using Microsoft.EntityFrameworkCore;
using Shared.Common;
using System.Linq;
using System.Linq.Expressions;
using Shared.Utility;

namespace Services.Services
{
    public class GeneticService : GenericService<GeneticModel, GeneticEntity>, IGeneticService
    {
        public GeneticService(IGenericDataRepository<GeneticEntity> repository, INurseryService nurseryService, IMapper mapper) : base(repository, mapper)
        {

        }

        public override IList<GeneticModel> GetListByUserId(string userId)
        {
            throw new NotImplementedException();
        }

        public int AddGenetic(GeneticModelV1 model)
        {
            int result = 0;
            try
            {
                if (model != null && model.GeneticNameListModel.Count > 0)
                {
                    foreach (var Item in model.GeneticNameListModel)
                    {
                        if (CheckExist(Item.Name, model.NurseryId, 0) == false)
                        {
                            if (!string.IsNullOrEmpty(Item.Name) && Item.IsDelete == false)
                            {
                                GeneticEntity objGeneticEntity = new GeneticEntity();
                                objGeneticEntity.NurseryId = model.NurseryId;
                                objGeneticEntity.Name = Item.Name;
                                objGeneticEntity.IsActive = true;
                                objGeneticEntity.IsDeleted = false;
                                objGeneticEntity.CreatedOn = CommonFunction.GetCurrentDateTime();

                                this.repository.context.Genetic.Add(objGeneticEntity);
                                this.repository.context.SaveChanges();
                                result = 1;
                            }
                        }
                        else
                        {
                            return result = 2;
                        }
                    }                                       
                }
                return result;
            }
            catch (Exception ex)
            {
                return result = 3;
            }
        }

        /// <summary>
        /// Gets the geneticlist.
        /// </summary>
        /// <returns></returns>
        public List<GeneticModel> GetGeneticlist()
        {
            // var query = this.repository.context.Operators;
            var listData = (from G in this.repository.context.Genetic
                            join n in this.repository.context.Nurseries on G.NurseryId equals n.Id
                            select new
                            {
                                GeneticId = G.Id,
                                Name = G.Name,
                                NurseryId = G.NurseryId,
                                NurseryName = n.Name,
                                IsDelete = G.IsDeleted,
                                CreatedOn = G.CreatedOn,
                                UpdatedOn = G.UpdatedOn,

                            }).Where(a => a.IsDelete == false).OrderByDescending(s => s.CreatedOn).ToList();

            List<GeneticModel> list = new List<GeneticModel>();

            if (listData != null && listData.Count > 0)
            {
                foreach (var item in listData)
                {
                    GeneticModel objGenetic = new GeneticModel();

                    objGenetic.Id = item.GeneticId;
                    objGenetic.Name = item.Name;
                    objGenetic.IsDeleted = item.IsDelete;
                    objGenetic.NurseryId = item.NurseryId;
                    objGenetic.NurseryName = item.NurseryName;
                    objGenetic.CreatedOn = item.CreatedOn;
                    objGenetic.UpdatedOn = item.UpdatedOn;
                    list.Add(objGenetic);
                }
            }

            return list;
        }


        /// <summary>
        /// Checks the exist.
        /// </summary>
        /// <param name="Name">The name.</param>
        /// <param name="NurseryId">The nursery identifier.</param>
        /// <returns></returns>
        public bool CheckExist(string Name, long NurseryId, long ID)
        {
            bool IsExist = false;
            var objData = repository.CheckExist(e => e.Name == Name && e.NurseryId == NurseryId && e.IsDeleted == false);
            if (objData == null)
                IsExist = false;
            else
            {
                if (ID > 0)
                    IsExist = objData.Id == ID ? false : true;  // self exist then false
                else
                    IsExist = true;
            }
            return IsExist;
        }

    }
}
