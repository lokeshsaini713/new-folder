﻿using AutoMapper;
using Data.IRepository;
using Data.Repository.GenericRepository;
using Services.IService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Services.Generic
{
    /// <summary>
    /// This is a generic service in this we have generic functions 
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <typeparam name="E"></typeparam>
    /// <seealso cref="Services.IService.IGenericService{T}" />
    /// <seealso cref="System.IDisposable" />
    public abstract class GenericService<T, E> : IGenericService<T>, IDisposable where E : class
    {
        protected readonly IGenericDataRepository<E> repository;
        protected readonly IMapper mapper;

        public GenericService(IGenericDataRepository<E> repository, IMapper mapper)
        {
            this.repository = repository;
            this.mapper = mapper;
        }

        public virtual bool Add(params T[] items)
        {
            return repository.Add(mapper.Map<E[]>(items));
        }

        public virtual bool Remove(params T[] items)
        {
            return repository.Remove(mapper.Map<E[]>(items));
        }

        public virtual bool Remove(long id)
        {
            return repository.Remove(id);
        }

        public virtual bool Update(params T[] items)
        {
            return repository.Update(mapper.Map<E[]>(items));
        }

        public virtual IList<T> GetAll()
        {
            return mapper.Map<IList<T>>(repository.GetAll());
        }

        public virtual IList<T> GetAllWithInActive()
        {
            return mapper.Map<IList<T>>(repository.GetAllWithInActive());
        }

        public virtual T GetById(long Id)
        {
            return mapper.Map<T>(repository.GetSingle(Id));
        }

        public virtual IList<T> GetListByUserId(string userId)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Changes the status.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        public virtual bool ChangeStatus(long id)
        {
            return repository.ChangeStatus(id);
        }


        public void Dispose()
        {
            repository.Dispose();
            //IDisposable disposable = this as IDisposable;
            //if (disposable != null)
            //{
            //    disposable.Dispose();
            //}
        }
    }
}
