﻿using Services.IService;
using Shared.Models;
using System.Collections.Generic;

namespace Services.IServices
{
    public interface INurseryService : IGenericService<NurseryModel>
    {
        bool CheckExist(string NurseyName, long ID);

        /// <summary>
        /// Gets all nursery with genetic.
        /// </summary>
        /// <returns></returns>
        List<NurseryMasterModel> GetAllNurseryWithGenetic(string UserId);
    }
}