﻿using Shared.Models;
using Shared.Utility;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Services.IService
{
    public interface ISeedlingRecordService : IGenericService<SeedlingDispatchRecordModel>
    {
        /// <summary>
        /// Saves the seedling record.
        /// </summary>
        /// <param name="model">The model.</param>
        /// <returns></returns>
        bool SaveSeedlingRecord(List<SeedlingDispatchRecordModel> model);

        /// <summary>
        /// Saves the usage data.
        /// </summary>
        /// <param name="model">The model.</param>
        /// <returns></returns>
        bool SaveUsageData(List<UsageRecordModel> model);

        /// <summary>
        /// Saves the qc record.
        /// </summary>
        /// <param name="model">The model.</param>
        /// <returns></returns>
        bool SaveQCRecord(List<QCRecordModel> model);

        /// <summary>
        /// Saves all data(usage, seedling, QC).
        /// </summary>
        /// <param name="model">The model.</param>
        /// <returns></returns>
        bool SaveAllData(List<SaveAllDataModel> model);

        /// <summary>
        /// Gets the seedling dispatch report list.
        /// </summary>
        /// <param name="FromDate">From date.</param>
        /// <param name="ToDate">To date.</param>
        /// <returns></returns>
        List<SeedlingDispatchRecordModel> GetSeedlingDispatchReportList(DateTime? FromDate, DateTime? ToDate);
    }
}
