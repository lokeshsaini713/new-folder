﻿using Services.IService;
using Shared.Models;
using System.Collections.Generic;

namespace Services.IServices
{
    public interface IOperatorService : IGenericService<OperatorModel>
    {
        /// <summary>
        /// Gets the operator by identifier.
        /// </summary>
        /// <param name="Id">The identifier.</param>
        /// <returns></returns>
        OperatorModel GetOperatorById(long Id);
     
        /// <summary>
        /// Gets the operatorlist.
        /// </summary>
        /// <returns></returns>
        List<OperatorModel> GetOperatorlist();

        
        List<ContactOperatorModel> GetContactOperatorlist(string UserId);

    }
}