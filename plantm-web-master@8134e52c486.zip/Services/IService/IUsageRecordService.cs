﻿using Shared.Models;
using Shared.Utility;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Services.IService
{
    public interface IUsageRecordService : IGenericService<UsageRecordModel>
    {
        /// <summary>
        /// Saves the usage data.
        /// </summary>
        /// <param name="model">The model.</param>
        /// <returns></returns>
        bool SaveUsageData(List<UsageRecordModel> model);

        /// <summary>
        /// Gets the usage record report list.
        /// </summary>
        /// <param name="FromDate">From date.</param>
        /// <param name="ToDate">To date.</param>
        /// <returns></returns>
        List<UsageRecordModel> GetUsageRecordList(DateTime? FromDate, DateTime? ToDate);


        /// <summary>
        /// Gets the usage record list with pagging for API.
        /// </summary>
        /// <param name="model">The model.</param>
        /// <returns></returns>
        List<UsageRecordModel> GetUsageRecordListPagging(ReqParam_UsageRecord model);

        /// <summary>
        /// Gets the usage record list by operator.
        /// </summary>
        /// <param name="UserId">The user identifier.</param>
        /// <returns></returns>
        List<UsageRecordModel> GetUsageRecordListByOperator(string UserId);
    }
}
