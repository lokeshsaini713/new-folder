﻿using Services.IService;
using Shared.Models;
using System.Collections.Generic;

namespace Services.IServices
{
    public interface IGeneticService : IGenericService<GeneticModel>
    {
        /// <summary>
        /// Checks the exist.
        /// </summary>
        /// <param name="Name">The name.</param>
        /// <param name="NurseryId">The nursery identifier.</param>
        /// <returns></returns>
        bool CheckExist(string Name, long NurseryId, long ID);

        /// <summary>
        /// this function is used to add genetics.
        /// </summary>
        /// <param name="model">The model.</param>
        /// <returns></returns>
        int AddGenetic(GeneticModelV1 model);

        /// <summary>
        /// Gets the geneticlist.
        /// </summary>
        /// <returns></returns>
        List<GeneticModel> GetGeneticlist();
    }
}