﻿using Shared.Models;
using Shared.Utility;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Services.IService
{
    public interface IQCRecordService : IGenericService<QCRecordModel>
    {
        /// <summary>
        /// Saves the qc record.
        /// </summary>
        /// <param name="model">The model.</param>
        /// <returns></returns>
        bool SaveQCRecord(List<QCRecordModel> model);

        List<QCRecordModel> GetQCReportList(DateTime? FromDate, DateTime? ToDate);
    }
}
