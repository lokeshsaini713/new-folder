﻿using Services.IService;
using Shared.Models;
using System.Collections.Generic;

namespace Services.IServices
{
    public interface ILookUpService : IGenericService<LookUpModel>
    {
        /// <summary>
        /// Checks the exist.
        /// </summary>
        /// <param name="GroupName">Name of the group.</param>
        /// <param name="Value">The value.</param>
        /// <param name="ID">The identifier.</param>
        /// <returns></returns>
        bool CheckExist(string GroupName, string Value, long ID);

        /// <summary>
        /// Gets the compartment list.
        /// </summary>
        /// <returns></returns>
        List<CommonTextValueModel> GetCompartmentList();
      
        /// <summary>
        /// Gets the agency.
        /// </summary>
        /// <returns></returns>
        List<CommonTextValueModel> GetAgency();

        /// <summary>
        /// Gets the seedling damage.
        /// </summary>
        /// <returns></returns>
        //List<CommonTextValueModel> GetSeedlingDamage();
              
    }
}