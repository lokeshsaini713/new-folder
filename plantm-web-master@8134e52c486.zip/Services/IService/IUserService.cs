﻿using Shared.Models;
using Shared.Utility;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Services.IService
{
    public interface IUserService
    {
        /// <summary>
        /// Registers the specified request.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <param name="userId">The user identifier.</param>
        /// <returns></returns>
        //ApiResponses<bool> Register(UserRegistrationViewModel request, string userId);

        /// <summary>
        /// Determines whether [is user active or not] [the specified userid].
        /// </summary>
        /// <param name="userid">The userid.</param>
        /// <returns></returns>
        Task<bool> IsUserActiveOrNot(string userid);

        /// <summary>
        /// Manages the login device information.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <param name="deviceType">Type of the device.</param>
        /// <param name="deviceToken">The device token.</param>
        /// <param name="Token">The token.</param>
        /// <param name="TimezoneOffsetInSeconds">The timezone offset in seconds.</param>
        void ManageLoginDeviceInfo(string userId, short deviceType, string deviceToken, string Token, int TimezoneOffsetInSeconds);

        /// <summary>
        /// Gets the login user details.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <returns></returns>
        ApiResponses<LoginResponseModel> GetLoginUserDetails(string userId);

        /// <summary>
        /// Logouts the specified user identifier.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <returns></returns>
        ApiResponses<bool> Logout(string userId);


        /// <summary>
        /// Checks the user active delete status.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <returns></returns>
        ApiResponses<bool> CheckUserActiveDeleteStatus(string userId);

        /// <summary>
        /// Updates the user token.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <param name="Token">The token.</param>
        void UpdateUserToken(string userId, string Token);

        /// <summary>
        /// Gets the user name by identifier.
        /// </summary>
        /// <param name="UserId">The user identifier.</param>
        /// <returns></returns>
        string GetUserNameById(string UserId);

        /// <summary>
        /// Saves the token.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <param name="token">The token.</param>
        /// <param name="isUpdate">if set to <c>true</c> [is update].</param>
        /// <returns></returns>
        Task<bool> SaveToken(string userId, string token, bool isUpdate);

        /// <summary>
        /// Determines whether [is password reset with token] [the specified user identifier].
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <returns>
        ///   <c>true</c> if [is password reset with token] [the specified user identifier]; otherwise, <c>false</c>.
        /// </returns>
        bool IsPasswordResetWithToken(string userId);

        /// <summary>
        /// Updates the user reset token.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="token">The token.</param>
        void UpdateUserResetToken(string id, string token);
    }
}
