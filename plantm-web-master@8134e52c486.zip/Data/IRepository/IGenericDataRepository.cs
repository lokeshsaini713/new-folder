﻿using Data.Context;
using Data.Entities.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Data.IRepository
{
    public interface IGenericDataRepository<T> : IDisposable where T : class
    {
        PlantMAppContext context { get; set; }

        IList<T> GetAll(params Expression<Func<T, object>>[] navigationProperties);
        IList<T> GetAllWithInActive(params Expression<Func<T, object>>[] navigationProperties);

        /// <summary>
        /// call SP and functions/ views
        /// </summary>
        /// <typeparam name="E"></typeparam>
        /// <param name="sql">The SQL.</param>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        IList<E> SqlQuery<E>(string sql, params object[] parameters) where E : class;

        /// <summary>
        /// SQLs the query API.
        /// </summary>
        /// <typeparam name="E"></typeparam>
        /// <param name="sql">The SQL.</param>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        IList<E> SqlQueryAPI<E>(string sql, params object[] parameters) where E : class;

        IList<T> GetList(Func<T, bool> where, params Expression<Func<T, object>>[] navigationProperties);
        T GetSingle(long id);
        T GetSingle(Func<T, bool> where, params Expression<Func<T, object>>[] navigationProperties);
        T CheckExist(Func<T, bool> where);
        bool Add(params T[] items);
        bool Add(T items);
        string AddReturnWithId(T items);
        bool Update(params T[] items);
        bool Remove(params T[] items);
        bool Remove(long Id);
        bool ChangeStatus(long id);
    }
}
