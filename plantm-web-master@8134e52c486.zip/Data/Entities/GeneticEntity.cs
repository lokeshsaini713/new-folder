﻿using Data.Entities.Base;
using Data.Entities.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Data.Entities
{
    /*
     * Genetic
     * Id int  NOT NULL ,
     * NurseryId	BIGINT,
     * Name nvarchar(100) NULL,	
     * IsActive bit NOT NULL default 0,
     * IsDelete bit NOT NULL default 0,
     * UpdatedOn datetime NOT NULL,
     * CreatedOn datetime NOT NULL,
     */
    [Table("Genetic")]
	public class GeneticEntity : BaseEntity
    {
		[ForeignKey("Nursery")]
        public long NurseryId { get; set; }     
        public string Name { get; set; }
      
    }
}
