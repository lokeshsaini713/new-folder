﻿using Data.Entities.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Data.Entities
{
    /*
     * CREATE TABLE [dbo].[Nursery]
     *   (
     *   [Id] [int] IDENTITY(1,1) NOT NULL primary key,
     *   [Locatopn] geography ,
     *   [NurseryAddress] nvarchar(500),
     *   [Name] [nvarchar](100) NULL,
     *   [ContactPerson] [nvarchar](150) NULL,
     *   [Mobile] [nvarchar](40) NULL,
     *   [IsActive] [bit] NOT NULL default(0),
     *   [IsDelete] [bit] NOT NULL default(1),
     *   [UpdatedOn] [datetime2](7) NOT NULL,
     *   [CreatedOn] [datetime2](7) NOT NULL
     *
     *   )
     */
    [Table("Nursery")]
    public class NurseryEntity : BaseEntity
    {
        public double? Lat { get; set; }
        public double? Lng { get; set; }
        public string NurseryAddress { get; set; }
        public string Name { get; set; }
        [MaxLength(150)]
        public string ContactPerson { get; set; }
        [MaxLength(40)]
        public string Mobile { get; set; }
    }
}
