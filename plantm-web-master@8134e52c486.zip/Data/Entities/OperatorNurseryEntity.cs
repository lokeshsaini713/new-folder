﻿using Data.Entities.Base;
using Data.Entities.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Data.Entities
{
    /*
     * OperatorNursery
     */
    [Table("OperatorNursery")]
    public class OperatorNurseryEntity 
    {
        public long Id { get; set; }
        [ForeignKey("Operator")]
        public long OperatorId { get; set; }

        [ForeignKey("Nursery")]
        public long NurseryId { get; set; }


    }
}
