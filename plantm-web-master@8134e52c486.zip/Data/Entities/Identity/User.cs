using Microsoft.AspNetCore.Identity;
using Shared.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace Data.Entities.Identity
{
    [Table("AspNetUsers")]
    public class User : IdentityUser
    {
        public User()
        {
            this.CreatedDate = DateTime.UtcNow.GetLocal();
            this.ModifiedDate = DateTime.UtcNow.GetLocal();
            this.IsDeleted = false;
            this.IsActive = true;
        }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public bool IsActive { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }


        private DateTime? createDate;
        public DateTime CreatedDate
        {
            get
            {
                if (createDate == null || createDate == DateTime.MinValue)
                {
                    createDate = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, TimeZoneInfo.FindSystemTimeZoneById("India Standard Time"));
                }
                return createDate.Value;
            }
            set { createDate = value; }
        }
        private DateTime? modificationDate;
        public DateTime ModifiedDate
        {
            get
            {
                if (modificationDate == null || modificationDate == DateTime.MinValue)
                {
                    modificationDate = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, TimeZoneInfo.FindSystemTimeZoneById("India Standard Time"));
                }
                return modificationDate.Value;
            }
            set { modificationDate = value; }
        }
        private bool? isDeleted;
        public bool IsDeleted
        {
            get
            {
                if (isDeleted == null)
                {
                    isDeleted = false;
                }
                return isDeleted.Value;
            }
            set
            {
                isDeleted = value;
            }
        }

        public ICollection<UserRole> UserRoles { get; set; }
        public string ProfileImage { get; set; }
        public string ResetToken { get; set; }
    }
}