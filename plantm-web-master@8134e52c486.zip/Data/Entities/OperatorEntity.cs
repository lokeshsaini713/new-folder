﻿using Data.Entities.Base;
using Data.Entities.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Data.Entities
{
	/*
     * Operato
     * [Id] [bigint] IDENTITY(1,1) NOT NULL primary key,
	 * 	[UserId] [nvarchar](450) NULL FOREIGN KEY REFERENCES [dbo].[AspNetUsers] ([Id]),
	 *	[Name] [nvarchar](100) NULL,
	 *	[AgencyId] int, --FK Table
	 *	[NurseryId]	int, --FK table
	 *	[RoleType] varchar(30) null,
	 *	[DOB] [date] NULL,
	 *	[ProfileImage] [varchar](60) NULL,
	 *	[IsActive] [bit] NOT NULL default(0),
	 *	[IsDelete] [bit] NOT NULL default(1),
	 *	[LastLoginOn] [datetime2](7) NOT NULL,
	 *	[UpdatedOn] [datetime2](7) NOT NULL,
	 *	[CreatedOn] [datetime2](7) NOT NULL
     */
	[Table("Operators")]
	public class OperatorEntity : BaseEntity
    {
		[ForeignKey("User")]
        public string UserId { get; set; }
        public User User { get; set; }
        public string Name { get; set; }
		[ForeignKey("LookUp")]
		public long AgencyId { get; set; }
		[ForeignKey("LookUp")]
		public long PlantingContractorId { get; set; }
		//[ForeignKey("Nursery")]
		//public long NurseryId { get; set; }
		[MaxLength(30)]
        public string Role { get; set; }
        public DateTime DOB { get; set; }
        //public string ProfileImage { get; set; }
        public DateTime LastLoginOn { get; set; }
    }
}
