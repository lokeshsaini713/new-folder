﻿using Data.Entities.Base;
using Data.Entities.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Data.Entities
{
    /*
     * UsageRecord
     */
    [Table("SeedlingRecord")]
    public class SeedlingRecordEntity : BaseEntity
    {
        [ForeignKey("Operator")]
        public long OperatorId { get; set; }
        public DateTime UsageDate { get; set; }
        [ForeignKey("Operator")]
        public long ContactOperatorId { get; set; }
        [ForeignKey("Nursery")]
        public long NurseryId { get; set; }
        [ForeignKey("Genetic")]
        public long GeneticId { get; set; }
        [MaxLength(50)]
        public string Compartment { get; set; }          
        public int Number { get; set; }       
        [MaxLength(250)]
        public string Comments { get; set; }
        public DateTime SyncDate { get; set; }

    }
}
