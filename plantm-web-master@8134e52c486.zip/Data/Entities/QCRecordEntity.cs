﻿using Data.Entities.Base;
using Data.Entities.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Data.Entities
{
    /*
     * QCRecord
     */
    [Table("QCRecord")]
    public class QCRecordEntity : BaseEntity
    {
        [ForeignKey("Operator")]
        public long OperatorId { get; set; }
        public decimal Latitude { get; set; }
        public decimal Longitude { get; set; }
        public DateTime UsageDate { get; set; }
        [MaxLength(50)]
        public string Compartment { get; set; }     
        public short PlotStocking { get; set; }
        public short PlotNumber { get; set; }
        [MaxLength(50)]
        public string Loose { get; set; }
        [MaxLength(50)]
        public string JRoot { get; set; }
        [MaxLength(50)]
        public string SeedlingDamage { get; set; }
        [MaxLength(50)]
        public string PlantedUpsidedown { get; set; }
        [MaxLength(50)]
        public string Tooshallow { get; set; }
        [MaxLength(250)]
        public string Comments { get; set; }
        public DateTime SyncDate { get; set; }

    }
}
