﻿using Data.Entities.Base;
using Data.Entities.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Data.Entities
{
    /*
     * LookUp
     * Id int NOT NULL AUTO_INCREMENT,
     * GroupName  varchar(50),
     * keyText  varchar(50),
     * Value  varchar(50),
     * IsActive bit NOT NULL default 0,
     * IsDelete bit NOT NULL default 0,
     * ModifiedDate datetime NOT NULL,
     * CreatedDate datetime NOT NULL,
     */
    [Table("LookUp")]
	public class LookUpEntity : BaseEntity
    {
	
        public string GroupName { get; set; }     
        //public string keyText { get; set; }
        public string Value { get; set; }
      
    }
}
