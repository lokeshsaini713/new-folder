﻿using Data.Context;
using Data.Entities.Base;
using Data.IRepository;
using Microsoft.EntityFrameworkCore;
using Shared.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using MySql.Data.EntityFrameworkCore;
using MySql.Data.MySqlClient;
using System.Data;
using System.Reflection;
using Shared.Utilities;
using Shared.Utility;

namespace Data.Repository.GenericRepository
{
    public class GenericDataRepository<T> : IGenericDataRepository<T>, IDisposable where T : class
    {
        //readonly PlantMAppContext context;
        public PlantMAppContext context { get; set; }
        public GenericDataRepository(PlantMAppContext context)
        {
            this.context = context;
        }
        public bool Add(params T[] items)
        {
            // assume Entity base class have an Id property for all items
            var mySet = context.Set<T>();
            mySet.AddRange(items);
            context.SaveChanges();
            return true;
        }
        public bool Add(T items)
        {
            // assume Entity base class have an Id property for all items
            var mySet = context.Set<T>();
            mySet.Add(items);
            context.SaveChanges();
            return true;
        }
        public string AddReturnWithId(T items)
        {
            // assume Entity base class have an Id property for all items
            var mySet = context.Set<T>();
            mySet.Add(items);
            context.SaveChanges();
            return "";
        }

        public bool Remove(params T[] items)
        {
            if (items != null)
            {
                foreach (var item in items)
                {
                    if (item is BaseEntity)
                    {
                        (item as BaseEntity).IsDeleted = true;
                        (item as BaseEntity).UpdatedOn = CommonFunction.GetCurrentDateTime();
                    }
                }
                this.Update(items);
            }
            return true;
        }

        public bool Remove(long id)
        {
            // assume Entity base class have an Id property for all items
            var mySet = context.Set<T>();
            var entity = mySet.Find(id);
            if (entity == null)
            {
                throw new Exception("Record not fount");
            }
            else
            {
                (entity as BaseEntity).IsDeleted = true;
                (entity as BaseEntity).IsActive = false;
                (entity as BaseEntity).UpdatedOn = CommonFunction.GetCurrentDateTime();
            }
            context.Entry(entity).CurrentValues.SetValues(entity);
            context.SaveChanges();
            return true;
        }

        public bool Update(params T[] items)
            {
            var mySet = context.Set<T>();
           
            if (items != null)
            {
                foreach (var entityToUpdate in items)
                {
                    mySet.Attach(entityToUpdate);
                    context.Entry(entityToUpdate).State = EntityState.Modified;
                    context.SaveChanges();
                }
            }
            return true;
        }

        public virtual IList<T> GetAll(params Expression<Func<T, object>>[] navigationProperties)
        {
            List<T> list;

            IQueryable<T> dbQuery = context.Set<T>();

            foreach (Expression<Func<T, object>> navigationProperty in navigationProperties)
                dbQuery = dbQuery.Include<T, object>(navigationProperty);

            list = dbQuery
                .AsNoTracking()
                .ToList<T>().Where(e => e is BaseEntity ? !(e as BaseEntity).IsDeleted : true).ToList();

            return list;
        }

        public virtual IList<T> GetAllWithInActive(params Expression<Func<T, object>>[] navigationProperties)
        {
            List<T> list;

            IQueryable<T> dbQuery = context.Set<T>();

            foreach (Expression<Func<T, object>> navigationProperty in navigationProperties)
                dbQuery = dbQuery.Include<T, object>(navigationProperty);

            list = dbQuery
                .AsNoTracking()
                .ToList<T>().Where(e => e is BaseEntity ? !(e as BaseEntity).IsDeleted : true).OrderByDescending(a => (a as BaseEntity).Id).ToList();

            return list;
        }


        public IList<E> SqlQuery<E>(string sql, params object[] parameters) where E : class
        {
            try
            {
                using (var con = new MySqlConnection())
                {

                    //var mySet = context.Set<E>();
                    //var result1 = mySet.FromSqlRaw<E>(sql, parameters);

                    var entityCon = context.Database.GetDbConnection();
                    con.ConnectionString = entityCon.ConnectionString;

                    // Create a SQL command to execute the sproc
                    var cmd = new MySqlCommand();
                    cmd.CommandText = sql;
                    cmd.Parameters.AddRange(parameters);
                    cmd.Connection = con;

                    con.Open();
                    // Run the sproc
                    var reader = cmd.ExecuteReader();

                    //Get rad opening details
                    var result = DataReaderMapToList<E>(reader);//reader.Cast<E>();

                    //var rads = ((IObjectContextAdapter)db.DB).ObjectContext.Translate<Rad>(reader).ToList();
                    return result.ToList();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public IList<E> SqlQueryAPI<E>(string sql, params object[] parameters) where E : class
        {
            try
            {
                using (var con = new MySqlConnection())
                {

                    //var mySet = context.Set<E>();
                    //var result1 = mySet.FromSqlRaw<E>(sql, parameters);

                    var entityCon = context.Database.GetDbConnection();
                    con.ConnectionString = ConfigurationKey.DBConnectionString; //entityCon.ConnectionString;

                    // Create a SQL command to execute the sproc
                    var cmd = new MySqlCommand();
                    cmd.CommandText = sql;
                    cmd.Parameters.AddRange(parameters);
                    cmd.Connection = con;

                    con.Open();
                    // Run the sproc
                    var reader = cmd.ExecuteReader();

                    //Get rad opening details
                    var result = DataReaderMapToList<E>(reader);//reader.Cast<E>();

                    //var rads = ((IObjectContextAdapter)db.DB).ObjectContext.Translate<Rad>(reader).ToList();
                    return result.ToList();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<M> DataReaderMapToList<M>(IDataReader dr)
        {
            List<M> list = new List<M>();
            M obj = default(M);

            var fieldNames = Enumerable.Range(0, dr.FieldCount).Select(i => dr.GetName(i)).ToArray();

            while (dr.Read())
            {
                obj = Activator.CreateInstance<M>();
                foreach (PropertyInfo prop in obj.GetType().GetProperties())
                {
                    //var exists = Enumerable.Range(0, dr.FieldCount).Any(i => string.Equals(dr.GetName(i), fieldName, StringComparison.OrdinalIgnoreCase));
                    if (fieldNames.Contains(prop.Name) && !object.Equals(dr[prop.Name], DBNull.Value))
                    {
                        prop.SetValue(obj, dr[prop.Name], null);
                    }
                }
                list.Add(obj);
            }
            return list;
        }



        public virtual IList<T> GetList(Func<T, bool> where, params Expression<Func<T, object>>[] navigationProperties)
        {
            List<T> list;

            IQueryable<T> dbQuery = context.Set<T>();

            foreach (Expression<Func<T, object>> navigationProperty in navigationProperties)
                dbQuery = dbQuery.Include<T, object>(navigationProperty);

            list = dbQuery
                .AsNoTracking()
                .Where(where)
                .ToList<T>().Where(e => e is BaseEntity ? !(e as BaseEntity).IsDeleted && (e as BaseEntity).IsActive : true).ToList();

            return list;
        }

        public virtual T GetSingle(long id)
        {
            // assume Entity base class have an Id property for all items
            var mySet = context.Set<T>();
            var entity = mySet.Find(id);
            return (T)entity;

        }

        public virtual T GetSingle(Func<T, bool> where, params Expression<Func<T, object>>[] navigationProperties)
        {
            T item = null;
            IQueryable<T> dbQuery = context.Set<T>();
            //Apply eager loading
            foreach (Expression<Func<T, object>> navigationProperty in navigationProperties)
                dbQuery = dbQuery.Include<T, object>(navigationProperty);

            item = dbQuery
                .AsNoTracking() //Don't track any changes for the selected item
                .FirstOrDefault(where); //Apply where clause

            return item;
        }

        public bool ChangeStatus(long id)
        {
            // assume Entity base class have an Id property for all items
            var mySet = context.Set<T>();
            var entity = mySet.Find(id);
            if (entity == null)
            {
                throw new Exception("Record not fount");
            }
            else
            {
                (entity as BaseEntity).IsActive = !(entity as BaseEntity).IsActive;
                (entity as BaseEntity).UpdatedOn = CommonFunction.GetCurrentDateTime();
            }
            context.Entry(entity).CurrentValues.SetValues(entity);
            context.SaveChanges();
            return true;
        }

        public virtual T CheckExist(Func<T, bool> where)
        {
            T item = null;
            IQueryable<T> dbQuery = context.Set<T>();
            //Apply eager loading

            item = dbQuery
                .AsNoTracking() //Don't track any changes for the selected item
                .FirstOrDefault(where); //Apply where clause

            return item;
        }


        public void Dispose()
        {
            //IDisposable disposable = this as IDisposable;
            //if (disposable != null)
            //    disposable.Dispose();
        }
    }
}
