﻿using Data.Entities.Identity;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using Shared.Common;
using Shared.Utilities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Data.Context
{
    /// <summary>
    /// here we are create user roles and admin user when app start (if there is no role and user not exist with same details)
    /// </summary>
    public class PlantMAppContextSeed
    {
        public static async Task SeedAsync(IServiceProvider services, PlantMAppContext dbContext)
        {
            var userManager = services.GetRequiredService<UserManager<User>>();
            var roleMgr = services.GetRequiredService<RoleManager<Role>>();

            if (!dbContext.Roles.Any())
            {
                var rolesData = File.ReadAllText("../Data/Context/SeedData/Roles.json");
                var roles = JsonSerializer.Deserialize<List<string>>(rolesData);
                foreach (var item in roles)
                {
                    await roleMgr.CreateAsync(new Role(item));
                }
            }

            if (!userManager.Users.Any())
            {
                var userData = File.ReadAllText("../Data/Context/SeedData/Users.json");
                var users = JsonSerializer.Deserialize<List<User>>(userData);
                foreach (var item in users)
                {
                    await userManager.CreateAsync(item, "Admin@123");

                    if (item?.UserName?.ToLower().Contains(UserRoleEnum.Admin.ToString().ToLower()) == true)
                    {
                        await userManager.AddToRoleAsync(item, "Admin");
                    }
                    //else if (item?.UserName?.ToLower().Contains(UserRoleEnum.Operator.ToString().ToLower()) == true)
                    //{
                    //    await userManager.AddToRoleAsync(item, "Operator");
                    //}
                }
            }
        }
    }
}
