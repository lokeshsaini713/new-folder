﻿using Data.Entities;
using Data.Entities.Identity;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using MySql.Data.Types;
using System.Drawing;

namespace Data.Context
{
    //IdentityDbContext contains all the identity tables
    public class PlantMAppContext : IdentityDbContext<User, Role, string, IdentityUserClaim<string>,
        UserRole, IdentityUserLogin<string>, IdentityRoleClaim<string>, IdentityUserToken<string>>
    {
        public PlantMAppContext(DbContextOptions<PlantMAppContext> options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<IdentityUserLogin<string>>()
                    .Property(u => u.UserId)
                    .HasMaxLength(255);

            builder.Entity<IdentityUserLogin<string>>()
                  .Property(u => u.LoginProvider)
                  .HasMaxLength(255);

            builder.Entity<IdentityUserLogin<string>>()
                  .Property(u => u.ProviderKey)
                  .HasMaxLength(255);

            builder.Entity<UserRole>()
                  .Property(u => u.UserId)
                  .HasMaxLength(255);

            builder.Entity<UserRole>()
                  .Property(u => u.RoleId)
                  .HasMaxLength(255);


            builder.Entity<IdentityUserToken<string>>()
                  .Property(u => u.Name)
                  .HasMaxLength(255);
            builder.Entity<IdentityUserToken<string>>()
                  .Property(u => u.UserId)
                  .HasMaxLength(255);
            builder.Entity<IdentityUserToken<string>>()
                  .Property(u => u.LoginProvider)
                  .HasMaxLength(255);

            builder.Entity<UserRole>(userRole =>
            {
                userRole.HasKey(ur => new { ur.UserId, ur.RoleId });

                userRole.HasOne(ur => ur.Role)
                    .WithMany(r => r.UserRoles)
                    .HasForeignKey(ur => ur.RoleId)
                    .IsRequired();

                userRole.HasOne(ur => ur.User)
                    .WithMany(r => r.UserRoles)
                    .HasForeignKey(ur => ur.UserId)
                    .IsRequired();

            });
        }


        public DbSet<ExceptionEntity> Exceptions { get; set; }
        public DbSet<OperatorEntity> Operators { get; set; }
        public DbSet<NurseryEntity> Nurseries { get; set; }
        public DbSet<GeneticEntity> Genetic { get; set; }
        public DbSet<LookUpEntity> LookUp { get; set; }
        public DbSet<UserDeviceInfoEntity> UserDeviceInfos { get; set; }
        public DbSet<UsageRecordEntity> UsageRecord { get; set; }
        public DbSet<QCRecordEntity> QCRecord { get; set; }
        public DbSet<SeedlingRecordEntity> SeedlingRecord { get; set; }
        public DbSet<OperatorNurseryEntity> OperatorNursery { get; set; }



    }
}
