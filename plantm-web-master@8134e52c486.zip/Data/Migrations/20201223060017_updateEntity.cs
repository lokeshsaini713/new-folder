﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Data.Migrations
{
    public partial class updateEntity : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ProfileImage",
                table: "Operators");

            migrationBuilder.DropColumn(
                name: "keyText",
                table: "LookUp");

            migrationBuilder.AddColumn<string>(
                name: "ContactPerson",
                table: "Nursery",
                maxLength: 150,
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ContactPerson",
                table: "Nursery");

            migrationBuilder.AddColumn<string>(
                name: "ProfileImage",
                table: "Operators",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "keyText",
                table: "LookUp",
                type: "text",
                nullable: true);
        }
    }
}
