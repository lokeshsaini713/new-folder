﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using MySql.Data.EntityFrameworkCore.Metadata;

namespace Data.Migrations
{
    public partial class CreateQCRecordAndSeedlingRecordEntity1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "QCRecord",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("MySQL:ValueGenerationStrategy", MySQLValueGenerationStrategy.IdentityColumn),
                    CreatedOn = table.Column<DateTime>(nullable: false),
                    UpdatedOn = table.Column<DateTime>(nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDeleted = table.Column<bool>(nullable: false),
                    OperatorId = table.Column<long>(nullable: false),
                    Latitude = table.Column<long>(nullable: false),
                    Longitude = table.Column<long>(nullable: false),
                    UsageDate = table.Column<DateTime>(nullable: false),
                    Compartment = table.Column<string>(maxLength: 50, nullable: true),
                    PlotStocking = table.Column<short>(nullable: false),
                    PlotNumber = table.Column<short>(nullable: false),
                    Loose = table.Column<string>(maxLength: 50, nullable: true),
                    JRoot = table.Column<string>(maxLength: 50, nullable: true),
                    SeedlingDamage = table.Column<string>(maxLength: 50, nullable: true),
                    PlantedUpsidedown = table.Column<string>(maxLength: 50, nullable: true),
                    Tooshallow = table.Column<string>(maxLength: 50, nullable: true),
                    Comments = table.Column<string>(maxLength: 250, nullable: true),
                    SyncDate = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_QCRecord", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SeedlingRecord",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("MySQL:ValueGenerationStrategy", MySQLValueGenerationStrategy.IdentityColumn),
                    CreatedOn = table.Column<DateTime>(nullable: false),
                    UpdatedOn = table.Column<DateTime>(nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDeleted = table.Column<bool>(nullable: false),
                    OperatorId = table.Column<long>(nullable: false),
                    UsageDate = table.Column<DateTime>(nullable: false),
                    ContactOperatorId = table.Column<long>(nullable: false),
                    NurseryId = table.Column<long>(nullable: false),
                    GeneticId = table.Column<long>(nullable: false),
                    Compartment = table.Column<string>(maxLength: 50, nullable: true),
                    Number = table.Column<int>(nullable: false),
                    Comments = table.Column<string>(maxLength: 250, nullable: true),
                    SyncDate = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SeedlingRecord", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "QCRecord");

            migrationBuilder.DropTable(
                name: "SeedlingRecord");
        }
    }
}
