﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using MySql.Data.EntityFrameworkCore.Metadata;

namespace Data.Migrations
{
    public partial class CreateUsageRecordEntity1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "UsageRecord",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("MySQL:ValueGenerationStrategy", MySQLValueGenerationStrategy.IdentityColumn),
                    CreatedOn = table.Column<DateTime>(nullable: false),
                    UpdatedOn = table.Column<DateTime>(nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDeleted = table.Column<bool>(nullable: false),
                    OperatorId = table.Column<long>(nullable: false),
                    UsageDate = table.Column<DateTime>(nullable: false),
                    PlantingContractor = table.Column<string>(maxLength: 50, nullable: true),
                    NurseryId = table.Column<long>(nullable: false),
                    GeneticId = table.Column<long>(nullable: false),
                    Compartment = table.Column<string>(maxLength: 50, nullable: true),
                    TargetStocking = table.Column<short>(nullable: false),
                    NumberPlanted = table.Column<short>(nullable: false),
                    FireAffected = table.Column<bool>(nullable: false),
                    SoilCondition = table.Column<string>(maxLength: 50, nullable: true),
                    Temp = table.Column<string>(maxLength: 50, nullable: true),
                    WeatherCondition = table.Column<string>(maxLength: 50, nullable: true),
                    Comments = table.Column<string>(maxLength: 250, nullable: true),
                    SyncDate = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UsageRecord", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "UsageRecord");
        }
    }
}
