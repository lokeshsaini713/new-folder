﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Data.Entities.Identity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.EntityFrameworkCore.Internal;
using Microsoft.Extensions.Options;
using PlantM.Web.Common;
using PlantM.Web.Model;
using Services.IService;
using Services.IServices;
using Shared.Common;
using Shared.Models;
using Shared.Utilities;
using Shared.Utility;

namespace PlantM.Web.Areas.API.Controllers
{
    /// <summary>
    /// User account controller
    /// This controller will contains all method related to user login,signup,change password.
    /// </summary>

    [ApiController]
    [Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
    [Route("api/[controller]")]
    public class SeedlingRecordController : BaseAPIController
    {
        #region [ Variables & Ctrs]

        private List<string> _errors = new List<string>();

        private readonly JwtTokenSettings jwtTokenSettings;

        private readonly UserManager<User> userManager;

        private readonly SignInManager<User> signInManager;
        private readonly IUserService userservice;
        private readonly INurseryService _nurseryService;
        private readonly ILookUpService _lookUpService;
        private readonly ISeedlingRecordService _seedlingRecordService;
        private readonly IQCRecordService _QCRecordService;
        private readonly IUsageRecordService _usageRecordService;

        /// <summary>
        /// Initialize connstructor
        /// </summary>
        /// <param name="accountService"></param>
        /// <param name="jwtOptions"></param>
        /// <param name="userManager"></param>
        /// <param name="signInManager"></param>
        /// <param name="commonService"></param>
        /// <param name="userService"></param>
        /// <param name="operatorService"></param>
        /// <param name="courierService"></param>
        ///<param name=" fileService"></param>

        public SeedlingRecordController(UserManager<User> userManager, IOptions<JwtTokenSettings> jwtOptions, SignInManager<User> signInManager, IUserService userservice, INurseryService nurseryService, ILookUpService lookUpService, ISeedlingRecordService seedlingRecordService, IQCRecordService qCRecordService, IUsageRecordService usageRecordService)
        {
            this.userManager = userManager;
            this.signInManager = signInManager;
            this.jwtTokenSettings = jwtOptions.Value;
            this.userservice = userservice;
            this._nurseryService = nurseryService;
            this._lookUpService = lookUpService;
            this._seedlingRecordService = seedlingRecordService;
            this._QCRecordService = qCRecordService;
            this._usageRecordService = usageRecordService;

        }

        #endregion [ Variables & Ctrs]


        #region Save seedling dispatch 

        [Route("SaveSeedlingDispatchRecord")]
        [HttpPost]
        public async Task<ApiResponses<bool>> SaveSeedlingDispatchRecord(List<SeedlingDispatchRecordModel> model)
        {
            if (!string.IsNullOrWhiteSpace(UserId))
            {
                if (userservice.CheckUserActiveDeleteStatus(UserId).Data == false)
                {
                    bool result = _seedlingRecordService.SaveSeedlingRecord(model);
                    if (result == true)
                    {
                        return new ApiResponses<bool>(ResponseMsg.Ok, true, _errors, successMsg: ResponseStatus.SeedlingSaved, apiName: "SaveSeedlingRecord");                    }
                    else
                    {
                        return new ApiResponses<bool>(ResponseMsg.Error, false, _errors, failureMsg: ResponseStatus.error, apiName: "SaveSeedlingRecord");
                    }
                }
                else
                {
                    return new ApiResponses<bool>(ResponseMsg.Error, true, _errors, failureMsg: ResponseStatus.UserAccountInActiveDeleteContactAdmin, apiName: "SaveUsageRecord");
                }
            }
            else
                return new ApiResponses<bool>(ResponseMsg.Error, false, _errors, failureMsg: ResponseStatus.InvalidToken, apiName: "SaveSeedlingRecord");
        }

        #endregion

        #region Save all records (usage, QC and seedling)

        [Route("SaveAllRecord")]
        [HttpPost]
        public async Task<ApiResponses<bool>> SaveAllRecord(List<SaveAllDataModel> model)
        {
            if (!string.IsNullOrWhiteSpace(UserId))
            {
                bool result = _seedlingRecordService.SaveAllData(model);

                if (result == true)
                {
                    if (userservice.CheckUserActiveDeleteStatus(UserId).Data == true)
                    {
                        return new ApiResponses<bool>(ResponseMsg.OkWithInActiveUser, true, _errors, successMsg: ResponseStatus.AllRecordSavedWithInActiveAccount, apiName: "SaveAllRecord");
                    }
                    else
                    {
                        return new ApiResponses<bool>(ResponseMsg.Ok, true, _errors, successMsg: ResponseStatus.AllRecordSaved, apiName: "SaveAllRecord");
                    }
                }
                else
                {
                    return new ApiResponses<bool>(ResponseMsg.Error, false, _errors, failureMsg: ResponseStatus.error, apiName: "SaveAllRecord");
                }
            }
            else
                return new ApiResponses<bool>(ResponseMsg.Error, false, _errors, failureMsg: ResponseStatus.InvalidToken, apiName: "SaveAllRecord");
        }

        #endregion

    }
}
