﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Data.Entities.Identity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.EntityFrameworkCore.Internal;
using Microsoft.Extensions.Options;
using PlantM.Web.Common;
using PlantM.Web.Model;
using Services.IService;
using Shared.Common;
using Shared.Models;
using Shared.Utilities;
using Shared.Utility;

namespace PlantM.Web.Areas.API.Controllers
{
    /// <summary>
    /// User account controller
    /// This controller will contains all method related to user login,signup,change password.
    /// </summary>

    [ApiController]
    [Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
    [Route("api/[controller]")]
    public class UserAccountController : BaseAPIController
    {
        #region [ Variables & Ctrs]

        private List<string> _errors = new List<string>();

        private readonly JwtTokenSettings jwtTokenSettings;

        private readonly UserManager<User> userManager;

        private readonly SignInManager<User> signInManager;
        private readonly IUserService userservice;

        /// <summary>
        /// Initialize connstructor
        /// </summary>
        /// <param name="accountService"></param>
        /// <param name="jwtOptions"></param>
        /// <param name="userManager"></param>
        /// <param name="signInManager"></param>
        /// <param name="commonService"></param>
        /// <param name="userService"></param>
        /// <param name="operatorService"></param>
        /// <param name="courierService"></param>
        ///<param name=" fileService"></param>

        public UserAccountController(UserManager<User> userManager, IOptions<JwtTokenSettings> jwtOptions, SignInManager<User> signInManager, IUserService userservice)

        {
            this.userManager = userManager;
            this.signInManager = signInManager;
            this.jwtTokenSettings = jwtOptions.Value;
            this.userservice = userservice;
        }

        #endregion [ Variables & Ctrs]

        #region [LOGIN AND LOGOUT SECTION]

        [Route("Login")]
        [HttpPost, AllowAnonymous]
        public async Task<ApiResponses<LoginResponseModel>> Login([FromBody] UserLoginViewModel request)
        {
            if (ModelState.IsValid)
            {
                var userCheck = await userManager.FindByEmailAsync(request.Email);

                if (userCheck != null)
                {
                    if (!userCheck.EmailConfirmed)
                    {
                        return new ApiResponses<LoginResponseModel>(ResponseMsg.Error, null, _errors, failureMsg: ResponseStatus.EmailNotVarified, apiName: "Login");
                    }
                    if (!(await userManager.CheckPasswordAsync(userCheck, request.Password)))
                    {
                        return new ApiResponses<LoginResponseModel>(ResponseMsg.Error, null, _errors, failureMsg: ResponseStatus.InvalidPassword, apiName: "Login");
                    }

                    if (!(userCheck.IsActive))
                    {
                        return new ApiResponses<LoginResponseModel>(ResponseMsg.Error, null, _errors, failureMsg: ResponseStatus.UserAccountInActiveContactAdmin, apiName: "Login");
                    }

                    if (userCheck.IsDeleted == true)
                    {
                        return new ApiResponses<LoginResponseModel>(ResponseMsg.Error, null, _errors, failureMsg: ResponseStatus.UserAccountInActiveContactAdmin, apiName: "Login");
                    }

                    var userSignInResult = await signInManager.PasswordSignInAsync(userCheck, request.Password, true, true);
                    if (userSignInResult.Succeeded)
                    {
                        var loginModel = userservice.GetLoginUserDetails(userCheck.Id);
                        if (loginModel.Data != null && loginModel.Data.OperatorId > 0 && loginModel.Data.OperatorIsActive == true && userCheck.IsActive == true && userCheck.IsDeleted == false)
                        {
                            var userType = (short)UserRoleEnum.Operator;
                            JwtTokenBuilder tokenBuilder = new JwtTokenBuilder();
                            var token = tokenBuilder.GetToken(jwtTokenSettings, userCheck.Id, userType);//need to discuss

                            userservice.ManageLoginDeviceInfo(userCheck.Id, request.DeviceType, request.DeviceToken, token.Value, request.TimezonoffsetInseconds);

                            LoginResponseModel responseModel = new LoginResponseModel();

                            if (loginModel.ResponseCode == ResponseCode.Ok)
                            {
                                responseModel = new LoginResponseModel()
                                {
                                    UserId = userCheck.Id,
                                    AuthorizationToken = token.Value,
                                    TokenExpiredOn = token.ValidTo,
                                    Email = request.Email,
                                    Name = loginModel.Data.Name,
                                    OperatorId = loginModel.Data.OperatorId,
                                    PlantingContractor = loginModel.Data.PlantingContractor,
                                    OperatorAccess = loginModel.Data.OperatorAccess,
                                    CallMasterDataAPI = loginModel.Data.CallMasterDataAPI,
                                };
                            }
                            return new ApiResponses<LoginResponseModel>(ResponseMsg.Ok, responseModel, _errors, successMsg: ResponseStatus.success, apiName: "Login");
                        }
                        else
                        {
                            if(userCheck.IsDeleted == true)
                            {
                                return new ApiResponses<LoginResponseModel>(ResponseMsg.Error, null, _errors, failureMsg: ResponseStatus.UserAccountInActiveDeleteContactAdmin, apiName: "Login");
                            }
                            else
                            {
                                return new ApiResponses<LoginResponseModel>(ResponseMsg.Error, null, _errors, failureMsg: ResponseStatus.UserAccountInActiveDeleteContactAdmin, apiName: "Login");
                            }
                        }
                    }
                    else
                    {
                        return new ApiResponses<LoginResponseModel>(ResponseMsg.Error, null, _errors, failureMsg: ResponseStatus.InvalidCredentials, apiName: "Login");
                    }
                }
                else
                {
                    return new ApiResponses<LoginResponseModel>(ResponseMsg.Error, null, _errors, failureMsg: ResponseStatus.InvalidEmailCredentials, apiName: "Login");
                }
            }
            else
            {
                return new ApiResponses<LoginResponseModel>(ResponseMsg.Error, null, _errors, failureMsg: ValidationErrors(), apiName: "Login");
            }
        }

        [Route("Logout")]
        [HttpPost]
        public async Task<ApiResponses<bool>> Logout()
        {
            if (!string.IsNullOrWhiteSpace(UserId))
            {
                await signInManager.SignOutAsync();
                return userservice.Logout(UserId);
            }
            else
                return new ApiResponses<bool>(ResponseMsg.Error, false, _errors, failureMsg: ResponseStatus.InvalidToken, apiName: "Logout");
        }

        [Route("RefreshToken")]
        [HttpGet]
        public async Task<ApiResponses<string>> RefreshToken()
        {
            try
            {
                var user = await userManager.FindByIdAsync(UserId);
                if (user == null)
                {
                    return new ApiResponses<string>(ResponseMsg.Error, null, _errors, failureMsg: ResponseStatus.userNotFound, apiName: "RefreshToken");
                }
                else
                {
                    JwtTokenBuilder tokenBuilder = new JwtTokenBuilder();
                    var userType = (short)UserRoleEnum.Operator;
                    var token = tokenBuilder.GetToken(jwtTokenSettings, user.Id, userType);
                    userservice.UpdateUserToken(UserId, token.Value);
                    return new ApiResponses<string>(ResponseMsg.Ok, token.Value, _errors, successMsg: ResponseStatus.TokenRefershed, apiName: "RefreshToken");
                }
            }
            catch (Exception ex)
            {
                return new ApiResponses<string>(ResponseMsg.Error, null, _errors, failureMsg: ValidationErrors(), apiName: "RefreshToken");
            }
        }

        #endregion [LOGIN AND LOGOUT SECTION]

        #region Change Password

        [Route("ChangePassword")]
        [HttpPost]
        public async Task<ApiResponses<bool>> ChangePassword(ChangePasswordModel model)
        {
            if (!string.IsNullOrWhiteSpace(UserId))
            {
                if (userservice.CheckUserActiveDeleteStatus(UserId).Data == false)
                {
                    var user = await userManager.FindByIdAsync(UserId);

                    bool isPassCorrect = (await userManager.CheckPasswordAsync(user, model.OldPassword));
                    if (isPassCorrect == true)
                    {
                        if (model.OldPassword == model.NewPassword)
                        {
                            return new ApiResponses<bool>(ResponseMsg.Error, false, _errors, failureMsg: ResponseStatus.OldPasswordNewPasswordSame, apiName: "ChangePassword");
                        }
                        else
                        {
                            var result = userManager.ChangePasswordAsync(user, model.OldPassword, model.NewPassword);

                            if (result.Result.Succeeded == false)
                            {
                                return new ApiResponses<bool>(ResponseMsg.Error, false, _errors, failureMsg: result.Result.Errors.FirstOrDefault().Description == "Incorrect password." ? "Incorrect old password." : result.Result.Errors.FirstOrDefault().Description, apiName: "ChangePassword");
                            }
                            else
                            {
                                return new ApiResponses<bool>(ResponseMsg.Ok, true, _errors, successMsg: ResponseStatus.PasswordChangeSuccess, apiName: "ChangePassword");
                            }
                        }
                    }
                    else
                    {
                        return new ApiResponses<bool>(ResponseMsg.Error, false, _errors, failureMsg: ResponseStatus.WrongOldPassword, apiName: "ChangePassword");
                    }

                }
                else
                {
                    return new ApiResponses<bool>(ResponseMsg.Error, false, _errors, failureMsg: ResponseStatus.UserAccountInActiveDeleteContactAdmin, apiName: "ChangePassword");
                }
            }
            else
                return new ApiResponses<bool>(ResponseMsg.Error, false, _errors, failureMsg: ResponseStatus.InvalidToken, apiName: "ChangePassword");
        }

        #endregion

        #region User Status

        [Route("UserStatus")]
        [HttpPost]
        public async Task<ApiResponses<LoginResponseModel>> UserStatus()
        {
            LoginResponseModel responseModel = new LoginResponseModel();
            if (!string.IsNullOrWhiteSpace(UserId))
            {
                if (userservice.CheckUserActiveDeleteStatus(UserId).Data == false)
                {
                    var user = await userManager.FindByIdAsync(UserId);
                    var loginModel = userservice.GetLoginUserDetails(UserId);
                    if (loginModel.Data.OperatorIsActive == true)
                    {
                        if (loginModel.ResponseCode == ResponseCode.Ok)
                        {
                            responseModel = new LoginResponseModel()
                            {
                                UserId = user.Id,
                                Email = user.Email,
                                Name = loginModel.Data.Name,
                                OperatorId = loginModel.Data.OperatorId,
                                PlantingContractor = loginModel.Data.PlantingContractor,
                                OperatorAccess = loginModel.Data.OperatorAccess,
                                CallMasterDataAPI = loginModel.Data.CallMasterDataAPI,
                            };
                            return new ApiResponses<LoginResponseModel>(ResponseMsg.Ok, responseModel, _errors, successMsg: ResponseStatus.success, apiName: "UserStatus");
                        }
                        else
                        {
                            return new ApiResponses<LoginResponseModel>(ResponseMsg.Error, null, _errors, failureMsg: ResponseStatus.userNotFound, apiName: "UserStatus");
                        }
                    }
                    else
                    {
                        return new ApiResponses<LoginResponseModel>(ResponseMsg.Error, null, _errors, failureMsg: ResponseStatus.userNotFound, apiName: "UserStatus");
                    }

                }
                else
                {
                    return new ApiResponses<LoginResponseModel>(ResponseMsg.Error, null, _errors, failureMsg: ResponseStatus.UserAccountInActiveDeleteContactAdmin, apiName: "UserStatus");
                }
            }
            else
            {
                return new ApiResponses<LoginResponseModel>(ResponseMsg.Error, null, _errors, failureMsg: ResponseStatus.InvalidToken, apiName: "UserStatus");
            }
        }

        #endregion

        #region [FORGOT PASSWORD ]

        [Route("ForgotPassword")]
        [HttpPost, AllowAnonymous]
        public async Task<ApiResponses<bool>> ForgotPassword([FromBody] ForgotPassword request)
        {
            TResponse response = new TResponse();
            if (ModelState.IsValid)
            {
                var user = await userManager.FindByEmailAsync(request.EmailID);
                if (user != null)
                {
                    if (userservice.CheckUserActiveDeleteStatus(user.Id).Data == false)
                    {
                        if (user != null && await userManager.IsEmailConfirmedAsync(user))
                        {
                            var token = await userManager.GeneratePasswordResetTokenAsync(user);

                            var passwordResetLink = Url.Action("ResetPassword", "Account", new { email = request.EmailID, token = token }, Request.Scheme);
                            var userName = userservice.GetUserNameById(user.Id);
                            EmailFunctions.SendResetPasswordEmail(request.EmailID, "Forgot Password", (string.IsNullOrWhiteSpace(userName) ? user.NormalizedUserName : userName), passwordResetLink);

                            await userservice.SaveToken(user.Id, token, false);

                            return new ApiResponses<bool>(ResponseMsg.Ok, true, _errors, successMsg: ResponseStatus.ForgotPasswordSuccess, apiName: "ForgotPassword");
                        }
                        else
                        {
                            return new ApiResponses<bool>(ResponseMsg.Error, false, _errors, failureMsg: ResponseStatus.ForgotPasswordFailed, apiName: "ForgotPassword");
                        }
                    }
                    else
                    {
                        return new ApiResponses<bool>(ResponseMsg.Error, false, _errors, failureMsg: ResponseStatus.UserAccountInActiveDeleteContactAdmin, apiName: "ForgotPassword");
                    }
                }
                else
                {
                    return new ApiResponses<bool>(ResponseMsg.Error, false, _errors, failureMsg: ResponseStatus.InvalidEmailCredentials, apiName: "ForgotPassword");                    
                }
            }
            else
            {
                return new ApiResponses<bool>(ResponseMsg.Error, false, _errors, failureMsg: ValidationErrors(), apiName: "ForgotPassword");
            }
        }

        #endregion [FORGOT PASSWORD ]

        #region Validation error

        private string ValidationErrors()
        {
            return string.Join(", ", ModelState.Values.Where(E => E.Errors.Count > 0).SelectMany(E => E.Errors).Select(E => E.ErrorMessage)).ToString().Trim(',').Trim();
        }

        #endregion
    }
}
