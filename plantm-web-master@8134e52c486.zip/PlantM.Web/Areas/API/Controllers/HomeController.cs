﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace PlantM.Web.Areas.API.Controllers
{
    [Area(areaName: "API")]
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            var link = Url.Action("", "Swagger", new { area = "" });
            return Redirect(link);
        }
    }
}
