﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Data.Entities.Identity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.EntityFrameworkCore.Internal;
using Microsoft.Extensions.Options;
using PlantM.Web.Common;
using PlantM.Web.Model;
using Services.IService;
using Services.IServices;
using Shared.Common;
using Shared.Models;
using Shared.Utilities;
using Shared.Utility;

namespace PlantM.Web.Areas.API.Controllers
{
    /// <summary>
    /// User account controller
    /// This controller will contains all method related to user login,signup,change password.
    /// </summary>

    [ApiController]
    [Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
    [Route("api/[controller]")]
    public class MasterController : BaseAPIController
    {
        #region [ Variables & Ctrs]

        private List<string> _errors = new List<string>();

        private readonly JwtTokenSettings jwtTokenSettings;

        private readonly UserManager<User> userManager;

        private readonly SignInManager<User> signInManager;
        private readonly IUserService userservice;
        private readonly INurseryService _nurseryService;
        private readonly ILookUpService _lookUpService;
        private readonly IOperatorService _operatorService;

        /// <summary>
        /// Initialize connstructor
        /// </summary>
        /// <param name="accountService"></param>
        /// <param name="jwtOptions"></param>
        /// <param name="userManager"></param>
        /// <param name="signInManager"></param>
        /// <param name="commonService"></param>
        /// <param name="userService"></param>
        /// <param name="operatorService"></param>
        /// <param name="courierService"></param>
        ///<param name=" fileService"></param>

        public MasterController(UserManager<User> userManager, IOptions<JwtTokenSettings> jwtOptions, SignInManager<User> signInManager, IUserService userservice, INurseryService nurseryService, ILookUpService lookUpService, IOperatorService operatorService)
        {
            this.userManager = userManager;
            this.signInManager = signInManager;
            this.jwtTokenSettings = jwtOptions.Value;
            this.userservice = userservice;
            this._nurseryService = nurseryService;
            this._lookUpService = lookUpService;
            this._operatorService = operatorService;
        }

        #endregion [ Variables & Ctrs]


        #region Master data 

        /// <summary>
        /// Get all the master data like nursery, genetic, parameters and operators .
        /// </summary>
        /// <returns></returns>
        [Route("MasterData")]
        [HttpPost]
        public async Task<ApiResponses<UsageRecordMasterModel>> MasterData()
        {
            UsageRecordMasterModel model = new UsageRecordMasterModel();
            if (!string.IsNullOrWhiteSpace(UserId))
            {
                if (userservice.CheckUserActiveDeleteStatus(UserId).Data == false)
                {
                    var lstNursery = _nurseryService.GetAllNurseryWithGenetic(UserId);
                    var lstCompartments = _lookUpService.GetCompartmentList();
                    var lstAgency = _lookUpService.GetAgency();
                    //var lstSeedlingDamage = _lookUpService.GetSeedlingDamage();
                    model.ContactList = _operatorService.GetContactOperatorlist(UserId);

                    if (lstNursery != null && lstNursery.Count > 0)
                    {
                        model.NurseryList = new List<NurseryMasterModel>();
                        model.NurseryList = lstNursery;
                    }
                    else
                    {
                        model.NurseryList = new List<NurseryMasterModel>();
                    }

                    if (lstCompartments != null && lstCompartments.Count > 0)
                    {
                        model.CompartmentList = new List<CommonTextValueModel>();
                        model.CompartmentList = lstCompartments;
                    }
                    else
                    {
                        model.CompartmentList = new List<CommonTextValueModel>();
                    }

                    if (lstAgency != null && lstAgency.Count > 0)
                    {
                        model.AgencyList = new List<CommonTextValueModel>();
                        model.AgencyList = lstAgency;
                    }
                    else
                    {
                        model.AgencyList = new List<CommonTextValueModel>();
                    }

                    //if (lstSeedlingDamage != null && lstSeedlingDamage.Count > 0)
                    //{
                    //    model.SeedlingDamageList = new List<CommonTextValueModel>();
                    //    //model.SeedlingDamageList = lstSeedlingDamage;
                    //}
                    //else
                    //{
                    //    model.SeedlingDamageList = new List<CommonTextValueModel>();
                    //}

                    model.SeedlingDamageList = new List<CommonTextValueModel>();

                    if (model != null)
                    {
                        return new ApiResponses<UsageRecordMasterModel>(ResponseMsg.Ok, model, _errors, successMsg: ResponseStatus.success, apiName: "MasterData");
                    }
                    else
                    {
                        return new ApiResponses<UsageRecordMasterModel>(ResponseMsg.NotFound, new UsageRecordMasterModel(), _errors, failureMsg: ResponseStatus.NoDataFound, apiName: "MasterData");
                    }

                }
                else
                {
                    return new ApiResponses<UsageRecordMasterModel>(ResponseMsg.Error, new UsageRecordMasterModel(), _errors, failureMsg: ResponseStatus.UserAccountInActiveDeleteContactAdmin, apiName: "MasterData");
                }
            }
            else
                return new ApiResponses<UsageRecordMasterModel>(ResponseMsg.Error, new UsageRecordMasterModel(), _errors, failureMsg: ResponseStatus.InvalidToken, apiName: "MasterData");
        }

        #endregion

    }
}
