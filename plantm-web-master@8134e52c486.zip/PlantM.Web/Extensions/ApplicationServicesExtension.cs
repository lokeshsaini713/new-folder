﻿using Data.Context;
using Data.IRepository;
using Data.Repository.GenericRepository;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Services.Generic;
using Services.IService;
using Services.IServices;
using Services.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PlantM.Web.Extensions
{
    /// <summary>
    ///  Here we have dependency injections  
    /// </summary>
    public static class ApplicationServicesExtension
    {

        public static IServiceCollection AddServices(this IServiceCollection services)
        {
            services.AddScoped<PlantMAppContext, PlantMAppContext>();

            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            services.AddScoped(typeof(IGenericDataRepository<>), typeof(GenericDataRepository<>));
            services.AddScoped(typeof(GenericDataRepository<>), typeof(GenericDataRepository<>));
            services.AddScoped<ExceptionLogginService, ExceptionLogginService>();
            services.AddScoped<IExceptionLogginService, ExceptionLogginService>();
            services.AddScoped<IOperatorService, OperatorService>();
            services.AddScoped<INurseryService, NurseryService>();
            services.AddScoped<IGeneticService, GeneticService>();
            services.AddScoped<ILookUpService, LookUpService>();
            services.AddScoped<IUserService, UserService>();
            services.AddScoped<IUsageRecordService, UsageRecordService>();
            services.AddScoped<IQCRecordService, QCRecordService>();
            services.AddScoped<ISeedlingRecordService, SeedlingRecordService>();

            return services;
        }
    }
}
