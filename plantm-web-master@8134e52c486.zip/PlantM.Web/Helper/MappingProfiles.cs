﻿using AutoMapper;
using Data.Entities;
using Data.Entities.Identity;
using Shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlantM.Web.Helper
{
    public class MappingProfiles : Profile
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MappingProfiles"/> class.
        /// here we are mapping models and entities 
        /// </summary>
        public MappingProfiles()
        {
            //cfg.CreateMap<Order, OrderEntity>().ForMember(dest => dest.OrderStatus, opt => opt.MapFrom<CustomResolver, string>(src => src.OrderStatus)); ;
            //cfg.CreateMap<OrderEntity, Order>().ForMember(dest => dest.OrderStatus, opt => opt.MapFrom<CustomResolver, int>(src => src.OrderStatus)); ;
            CreateMap<OperatorModel, OperatorEntity>().ReverseMap();
            CreateMap<NurseryModel, NurseryEntity>().ReverseMap();
            CreateMap<GeneticModel, GeneticEntity>().ReverseMap();
            CreateMap<LookUpModel, LookUpEntity>().ReverseMap();
            CreateMap<ExceptionModel, ExceptionEntity>().ReverseMap();
            CreateMap<UsageRecordEntity, UsageRecordModel>().ReverseMap();
            CreateMap<QCRecordEntity, QCRecordModel>().ReverseMap();
            CreateMap<SeedlingRecordEntity, SeedlingDispatchRecordModel>().ReverseMap();
            CreateMap<SPGetUsageRecordListModel, UsageRecordModel>().ReverseMap();
            CreateMap<SPGetSeedingDispatchListModel, SeedlingDispatchRecordModel>().ReverseMap();
            CreateMap<QualityControlReportModel, QCRecordModel>().ReverseMap();
        }
    }
}
