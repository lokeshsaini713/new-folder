﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Data.Entities.Identity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using PlantM.Web.Controllers.Base;
using PlantM.Web.Extensions;
using Services.IService;
using Services.IServices;
using Services.Services;
using Shared.Models;
using Shared.Utilities;
using Shared.Utility;

namespace PlantM.Web.Controllers
{
    /// <summary>
    /// Operator management
    /// </summary>
    [Authorize(Roles = "Admin")]
    public class OperatorController : BaseController<OperatorModel>
    {
        private readonly UserManager<User> userManager;
        private readonly SignInManager<User> signInManager;
        private readonly INurseryService _nurseryService;
        private readonly ILookUpService _lookUpService;
        private readonly IUserService _userService;


        /// <summary>
        /// construct services
        /// </summary>
        /// <param name="saveFormFileSerivce"></param>
        /// <param name="service"></param>
        public OperatorController(UserManager<User> userManager, SignInManager<User> signInManager, IOperatorService service, INurseryService nurseryService, ILookUpService lookUpService, IUserService userService) : base(service)
        {
            this.userManager = userManager;
            this.signInManager = signInManager;
            this._nurseryService = nurseryService;
            this._lookUpService = lookUpService;
            this._userService = userService;
        }


        #region  Operator list

        /// <summary>
        /// View Operator
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            if (TempData["Message"] != null)
            {
                ViewBag.ResultMSG = TempData["Message"];
                TempData["Message"] = null;
            }

            return View();
        }


        /// <summary>
        /// Get all Operator details
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public override ActionResult GetAll()
        {
            var list = ((IOperatorService)service).GetOperatorlist();

            return base.GetJoinList(list);
        }


        /// <summary>
        /// Get all Operator details with inactive operators
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public override ActionResult GetAllWithInActive()
        {
            return base.GetAllWithInActive();
        }

        #endregion


        #region  Add update operator

        /// <summary>
        /// Get barnd for Add or update
        /// </summary>
        /// <param name="id">Operator id</param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult AddUpdateOperator(long id)
        {
            var nurseryData = _nurseryService.GetAll();
            ViewBag.NurseryList = nurseryData.Select(a => new SelectListItem { Text = a.Name, Value = a.Id.ToString() }).OrderBy(s => s.Text).ToList();

            var lookUpData = _lookUpService.GetAll().Where(a => a.GroupName == ParameterEnum.Agency.ToString());
            ViewBag.AgencyList = lookUpData.Select(a => new SelectListItem { Text = a.Value, Value = a.Id.ToString() }).OrderBy(s => s.Text).ToList();

            var lookUpDataPlatingContractor = _lookUpService.GetAll().Where(a => a.GroupName == ParameterEnum.PlantingContractor.ToString());
            ViewBag.PlatingContractorList = lookUpDataPlatingContractor.Select(a => new SelectListItem { Text = a.Value, Value = a.Id.ToString() }).OrderBy(s => s.Text).ToList();
            if (id > 0)
            {
                var model = ((IOperatorService)service).GetOperatorById(id);
                return base.GetById(model);
            }
            else
            {
                return base.AddUpdate(id);
            }
        }

        /// <summary>
        /// added or updated Operator
        /// </summary>
        /// <param name="model">Operator detais</param>
        /// <returns></returns>
        [HttpPost]
        public async Task<ActionResult> AddUpdateOperator(OperatorModel model)
        {
            var nurseryData = _nurseryService.GetAll();
            ViewBag.NurseryList = nurseryData.Select(a => new SelectListItem { Text = a.Name, Value = a.Id.ToString() }).OrderBy(s => s.Text).ToList();

            var lookUpData = _lookUpService.GetAll().Where(a => a.GroupName == CommonFunction.GetDescription(ParameterEnum.Agency));
            ViewBag.AgencyList = lookUpData.Select(a => new SelectListItem { Text = a.Value, Value = a.Id.ToString() }).OrderBy(s => s.Text).ToList();

            var lookUpDataPlatingContractor = _lookUpService.GetAll().Where(a => a.GroupName == ParameterEnum.PlantingContractor.ToString());
            ViewBag.PlatingContractorList = lookUpDataPlatingContractor.Select(a => new SelectListItem { Text = a.Value, Value = a.Id.ToString() }).OrderBy(s => s.Text).ToList();

            if (ModelState.IsValid)
            {
                if (model != null)
                {
                    try
                    {
                        bool flag;
                        if (model.Id > 0)
                        {
                            flag = service.Update(model);
                            if (flag == true)
                            {
                                SuccessMessageModel successMsgModel = new SuccessMessageModel();
                                successMsgModel.IsSuccess = true;
                                successMsgModel.Message = ResponseStatus.OperatorUpdated;
                                string successMsg = JsonConvert.SerializeObject(successMsgModel);

                                TempData["Message"] = successMsgModel.Message;
                                TempData.Keep("Message");
                            }
                            else
                            {
                                SuccessMessageModel successMsgModel = new SuccessMessageModel();
                                successMsgModel.IsSuccess = false;
                                successMsgModel.Message = ResponseStatus.error;
                                string successMsg = JsonConvert.SerializeObject(successMsgModel);

                                TempData["Message"] = successMsgModel.Message;
                                TempData.Keep("Message");
                            }
                        }
                        else
                        {
                            string userNameGuid = "_" + Guid.NewGuid();
                            var user = new User()
                            {                                
                                Email = model.Email,
                                NormalizedEmail = model.Email,
                                UserName = model.Name.Replace(" ", "")+ userNameGuid,
                                NormalizedUserName = model.Name.Replace(" ", "")+ userNameGuid,
                                EmailConfirmed = true
                            };
                            var result = await userManager.CreateAsync(user, CommonFunction.Randomstring());

                            if (result.Succeeded == true)
                            {
                                var findUser = await userManager.FindByEmailAsync(model.Email);
                                model.UserId = findUser.Id;

                                flag = service.Add(model);

                                if (findUser != null && flag == true)
                                {
                                    var token = await userManager.GeneratePasswordResetTokenAsync(findUser);

                                    var passwordResetLink = Url.Action("GeneratePassword", "Account", new { email = model.Email, token = token }, Request.Scheme);
                                    var userName = _userService.GetUserNameById(user.Id);
                                    var re = EmailFunctions.SendGeneratePasswordEmail(model.Email, "Your PlantM account is ready to access", model.Name, passwordResetLink);

                                    await _userService.SaveToken(user.Id, token, false);

                                    SuccessMessageModel successMsgModel = new SuccessMessageModel();
                                    successMsgModel.IsSuccess = true;
                                    successMsgModel.Message = ResponseStatus.OperatorAdd;
                                    string successMsg = JsonConvert.SerializeObject(successMsgModel);

                                    TempData["Message"] = successMsgModel.Message;
                                    TempData.Keep("Message");

                                    //ModelState.AddModelError("message", re);
                                    //return View("AddUpdateOperator", model);
                                }
                                else
                                {
                                    SuccessMessageModel successMsgModel = new SuccessMessageModel();
                                    successMsgModel.IsSuccess = false;
                                    successMsgModel.Message = ResponseStatus.OperatorNotAdd;
                                    string successMsg = JsonConvert.SerializeObject(successMsgModel);

                                    TempData["Message"] = successMsgModel.Message;
                                    TempData.Keep("Message");
                                }
                            }
                            else
                            {
                                ModelState.AddModelError("message", result.Errors.FirstOrDefault().Description);
                                return View("AddUpdateOperator", model);
                            }
                        }
                        return RedirectToAction("Index");
                    }
                    catch (Exception ex)
                    {
                        ex.Log();
                        ModelState.AddModelError("message", ResponseStatus.error);
                        return View("AddUpdateOperator", model);
                    }
                }
            }
            return View("AddUpdateOperator", model);
        }


        #endregion


        #region Remove operator

        /// <summary>
        /// Remove Operator
        /// </summary>
        /// <param name="id">Operator id</param>
        /// <returns></returns>
        [HttpPost]
        public override ActionResult Remove(long id)
        {
            //return base.service.Remove(id);
            bool flag = base.service.Remove(id);
            return Json(new { flag });
        }

        #endregion


        #region Active/Deactive operator

        /// <summary>
        /// change Operator status
        /// </summary>
        /// <param name="id">Operator id</param>
        /// <returns></returns>
        public ActionResult ChangeStatus(long id)
        {
            bool flag = base.service.ChangeStatus(id);
            return Json(new { flag });
        }

        #endregion
    }
}