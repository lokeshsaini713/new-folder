﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PlantM.Web.Controllers.Base;
using PlantM.Web.Extensions;
using Services.IServices;
using Services.Services;
using Shared.Models;

namespace PlantM.Web.Controllers
{
    /// <summary>
    /// Nursery management
    /// </summary>
    [Authorize(Roles = "Admin")]
    public class NurseryController : BaseController<NurseryModel>
    {
        /// <summary>
        /// construct services
        /// </summary>
        /// <param name="saveFormFileSerivce"></param>
        /// <param name="service"></param>
        public NurseryController(INurseryService service) : base(service)
        {
        }

        #region Get nursery list

        /// <summary>
        /// View nursery
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            if (TempData["Message"] != null)
            {
                ViewBag.ResultMSG = TempData["Message"];
                TempData["Message"] = null;
            }
            return View();
        }



        /// <summary>
        /// Get all nursery list
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public override ActionResult GetAll()
        {
            return base.GetAllWithInActive();
        }

        #endregion


        #region add update nursery

        /// <summary>
        /// Get nursery for Add or update
        /// </summary>
        /// <param name="id">nursery id</param>
        /// <returns></returns>
        [HttpGet]
        public override ActionResult AddUpdate(long id)
        {
            return base.AddUpdate(id);
        }

        /// <summary>
        /// added or updated nursery
        /// </summary>
        /// <param name="model">nursery detais</param>
        /// <returns></returns>
        [HttpPost]
        public override ActionResult AddUpdate(NurseryModel model)
        {
            if (ModelState.IsValid)
            {
                if (model != null)
                {
                    if (model.Id == 0)
                    {
                        if (((INurseryService)service).CheckExist(model.Name,0))
                        {
                            ModelState.AddModelError("message", ResponseStatus.NurseryExists);
                            return View("AddUpdate", model);
                        }
                        else
                        {
                            SuccessMessageModel successMsgModel = new SuccessMessageModel();
                            successMsgModel.IsSuccess = true;
                            successMsgModel.Message = ResponseStatus.NurseryAdd;
                            string successMsg = JsonConvert.SerializeObject(successMsgModel);

                            TempData["Message"] = successMsgModel.Message;
                            TempData.Keep("Message");
                            return base.AddUpdate(model);
                        }
                    }
                    else
                    {
                        if (((INurseryService)service).CheckExist(model.Name, model.Id))
                        {
                            ModelState.AddModelError("message", ResponseStatus.NurseryExists);
                            return View("AddUpdate", model);
                        }
                        else
                        {
                            SuccessMessageModel successMsgModel = new SuccessMessageModel();
                            successMsgModel.IsSuccess = true;
                            successMsgModel.Message = ResponseStatus.NurseryUpdated;
                            string successMsg = JsonConvert.SerializeObject(successMsgModel);

                            TempData["Message"] = successMsgModel.Message;
                            TempData.Keep("Message");
                            return base.AddUpdate(model);
                        }
                    }
                }
            }
            return View("AddUpdate", model);
        }


        #endregion


        #region Remove nursery

        /// <summary>
        /// Remove nursery
        /// </summary>
        /// <param name="id">nursery id</param>
        /// <returns></returns>
        [HttpPost]
        public override ActionResult Remove(long id)
        {
            return base.Remove(id);
        }

        #endregion


        #region Active/Deactive nursery

        /// <summary>
        /// change nursery status
        /// </summary>
        /// <param name="id">nursery id</param>
        /// <returns></returns>
        public ActionResult ChangeStatus(long id)
        {
            bool flag = base.service.ChangeStatus(id);
            return Json(new { flag });
        }

        #endregion
    }
}