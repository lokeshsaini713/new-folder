﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using PlantM.Web.Controllers.Base;
using PlantM.Web.Extensions;
using Services.IServices;
using Services.Services;
using Shared.Models;

namespace PlantM.Web.Controllers
{
    /// <summary>
    /// Genetic management
    /// </summary>
    [Authorize(Roles = "Admin")]
    public class GeneticController : BaseController<GeneticModel>
    {
        private readonly INurseryService _nurseryService;


        /// <summary>
        /// construct services
        /// </summary>
        /// <param name="saveFormFileSerivce"></param>
        /// <param name="service"></param>
        public GeneticController(IGeneticService service, INurseryService nurseryService) : base(service)
        {
            this._nurseryService = nurseryService;
        }

        #region Genetic List

        /// <summary>
        /// View Genetic list
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            if (TempData["Message"] != null)
            {
                ViewBag.ResultMSG = TempData["Message"];
                TempData["Message"] = null;
            }

            return View();
        }


        /// <summary>
        /// Get all Genetic details
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public override ActionResult GetAll()
        {
            var list = ((IGeneticService)service).GetGeneticlist();
            return base.GetJoinList(list);
        }

        #endregion


        #region "Add Update"



        public ActionResult AddGenetic(long id)
        {
            var data = _nurseryService.GetAll();

            ViewBag.NurseryList = data.Select(a => new SelectListItem { Text = a.Name, Value = a.Id.ToString() }).OrderBy(s => s.Text).ToList();

            GeneticModelV1 model = new GeneticModelV1();
            model.GeneticNameListModel = new List<GeneticNameListModel>();

            model.GeneticNameListModel.Add(new GeneticNameListModel() { Name = "" });

            return View(model);
        }




        /// <summary>
        /// add Genetic
        /// </summary>
        /// <param name="model">Genetic detais</param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult AddGenetic(GeneticModelV1 model)
        {
            var data = _nurseryService.GetAll();

            ViewBag.NurseryList = data.Select(a => new SelectListItem { Text = a.Name, Value = a.Id.ToString() }).OrderBy(s => s.Text).ToList();

            if (model != null)
            {
                int response = ((IGeneticService)service).AddGenetic(model);
                if (response == 0)
                {
                    TempData["Message"] = ResponseStatus.error;
                    TempData.Keep("Message");
                    return View("AddGenetic", model);
                }
                else if (response == 1)
                {
                    SuccessMessageModel successMsgModel = new SuccessMessageModel();
                    successMsgModel.IsSuccess = true;
                    successMsgModel.Message = ResponseStatus.GeneticAdd;
                    string successMsg = JsonConvert.SerializeObject(successMsgModel);
                    TempData["Message"] = successMsgModel.Message;
                    TempData.Keep("Message");

                    return RedirectToAction("Index");
                }
                else if (response == 2)
                {
                    ModelState.AddModelError("message", ResponseStatus.GeneticExists);
                    return View("AddGenetic", model);
                }
                else
                {
                    ModelState.AddModelError("message", ResponseStatus.error);
                    return View("AddGenetic", model);
                }
            }

            return View("AddGenetic", model);
        }

        /// <summary>
        /// add update genetics
        /// </summary>
        /// <param name="id">Genetic id</param>
        /// <returns></returns>
        [HttpGet]
        public override ActionResult AddUpdate(long id)
        {
            var data = _nurseryService.GetAll();

            ViewBag.NurseryList = data.Select(a => new SelectListItem { Text = a.Name, Value = a.Id.ToString() }).OrderBy(s => s.Text).ToList();

            return base.AddUpdate(id);
        }


        /// <summary>
        /// add or updated Genetic
        /// </summary>
        /// <param name="model">Genetic detais</param>
        /// <returns></returns>
        [HttpPost]
        public override ActionResult AddUpdate(GeneticModel model)
        {
            var data = _nurseryService.GetAll();

            ViewBag.NurseryList = data.Select(a => new SelectListItem { Text = a.Name, Value = a.Id.ToString() }).OrderBy(s => s.Text).ToList();

            if (ModelState.IsValid)
            {
                if (model != null)
                {
                    if (model.Id == 0)
                    {
                        if (((IGeneticService)service).CheckExist(model.Name, model.NurseryId, 0))
                        {
                            ModelState.AddModelError("message", ResponseStatus.GeneticExists);
                            return View("AddUpdate", model);
                        }
                        else
                        {
                            SuccessMessageModel successMsgModel = new SuccessMessageModel();
                            successMsgModel.IsSuccess = true;
                            successMsgModel.Message = ResponseStatus.GeneticAdd;
                            string successMsg = JsonConvert.SerializeObject(successMsgModel);

                            TempData["Message"] = successMsgModel.Message;
                            TempData.Keep("Message");
                            return base.AddUpdate(model);
                        }
                    }
                    else
                    {
                        if (((IGeneticService)service).CheckExist(model.Name, model.NurseryId, model.Id))
                        {
                            ModelState.AddModelError("message", ResponseStatus.GeneticExists);
                            return View("AddUpdate", model);
                        }
                        else
                        {
                            SuccessMessageModel successMsgModel = new SuccessMessageModel();
                            successMsgModel.IsSuccess = true;
                            successMsgModel.Message = ResponseStatus.GeneticUpdated;
                            string successMsg = JsonConvert.SerializeObject(successMsgModel);

                            TempData["Message"] = successMsgModel.Message;
                            TempData.Keep("Message");
                            return base.AddUpdate(model);
                        }
                    }
                }
            }
            return View("AddUpdate", model);
        }

        #endregion


        #region Remove Genetic

        /// <summary>
        /// Remove Genetic
        /// </summary>
        /// <param name="id">Genetic id</param>
        /// <returns></returns>
        [HttpPost]
        public override ActionResult Remove(long id)
        {
            return base.Remove(id);
        }

        #endregion
    }
}