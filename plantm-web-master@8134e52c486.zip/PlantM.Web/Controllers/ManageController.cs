﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Data.Entities.Identity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Shared.Models;

namespace PlantM.Web.Controllers
{
    /// <summary>
    /// manager user
    /// </summary>
    [Authorize]
    public class ManageController : Controller
    {
        private readonly UserManager<User> _userManager;
        private readonly SignInManager<User> _signInManager;

        /// <summary>
        /// construct services
        /// </summary>
        /// <param name="userManager"></param>
        /// <param name="signInManager"></param>
        /// <param name="sendOTPService"></param>
        /// <param name="manageService"></param>
        public ManageController(UserManager<User> userManager, SignInManager<User> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
        }


        #region change password

        /// <summary>
        /// Changes the password.
        /// </summary>
        /// <returns></returns>
        public IActionResult ChangePassword()
        {
            if (TempData["Message"] != null)
            {
                ViewBag.ResultMSG = TempData["Message"];
                TempData["Message"] = null;
            }
            return View();
        }

        /// <summary>
        /// Changes the password.
        /// </summary>
        /// <param name="model">The model.</param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> ChangePassword(ChangePasswordModel model)
        {
            if (ModelState.IsValid)
            {
                var user = await _userManager.GetUserAsync(HttpContext.User);

                bool isPassCorrect = (await _userManager.CheckPasswordAsync(user, model.OldPassword));
                if (isPassCorrect == true)
                {
                    if (model.OldPassword == model.NewPassword)
                    {
                        ModelState.AddModelError("message", ResponseStatus.OldPasswordNewPasswordSame);
                    }
                    else
                    {
                        var result = _userManager.ChangePasswordAsync(user, model.OldPassword, model.NewPassword);

                        if (result.Result.Succeeded == false)
                        {
                            ModelState.AddModelError("message", string.Join(",", result.Result.Errors.Select(a => a.Description).FirstOrDefault()));
                            return View("ChangePassword", model);
                        }
                        else
                        {
                            SuccessMessageModel successMsgModel = new SuccessMessageModel();
                            successMsgModel.IsSuccess = true;
                            successMsgModel.Message = ResponseStatus.PasswordChangeSuccess;
                            string successMsg = JsonConvert.SerializeObject(successMsgModel);

                            TempData["Message"] = successMsgModel.Message;
                            TempData.Keep("Message");

                            if (TempData["Message"] != null)
                            {
                                ViewBag.ResultMSG = TempData["Message"];
                                TempData["Message"] = null;
                            }
                        }
                    }
                }
                else
                {
                    ModelState.AddModelError("message", ResponseStatus.InvalidPassword);
                }
            }
            return View("ChangePassword");
        }

        #endregion

       
    }
}
