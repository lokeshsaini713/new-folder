﻿using Data.Entities.Identity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using PlantM.Web.Extensions;
using Services.IService;
using Shared.Common;
using Shared.Models;
using Shared.Utilities;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace PlantM.Web.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<User> _userManager;
        private readonly SignInManager<User> _signInManager;
        private readonly IUserService _userService;

        public AccountController(UserManager<User> userManager, SignInManager<User> signInManager, IUserService userService)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _userService = userService;
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        #region admin login

        /// <summary>
        /// Logins the specified return URL.
        /// </summary>
        /// <param name="returnUrl">The return URL.</param>
        /// <returns></returns>
        [HttpGet]
        public IActionResult Login(string returnUrl)
        {          
            LoginViewModel model = new LoginViewModel()
            {
                ReturnUrl = returnUrl,
            };
            return View(model);
        }


        /// <summary>
        /// Logins the specified model.
        /// </summary>
        /// <param name="model">The model.</param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = await _userManager.FindByEmailAsync(model.Email);

                bool isPassCorrect = (await _userManager.CheckPasswordAsync(user, model.Password));

                if (user == null)
                {
                    ModelState.AddModelError("message", ResponseStatus.userNotFound);
                    return View(model);
                }
                else if (!isPassCorrect)
                {
                    ModelState.AddModelError("message", ResponseStatus.InvalidCredentials);
                    return View(model);
                }
                else if (await _userManager.IsInRoleAsync(user, UserRoleEnum.Admin.ToString()))
                {
                    var result = await _signInManager.PasswordSignInAsync(user, model.Password, model.RememberMe, ApplicationConstants.LockoutOnFailure);

                    if (result.Succeeded)
                    {
                        return RedirectToAction("Index", "Lookup", new { area = "" });

                    }

                    if (result.IsLockedOut)
                    {
                        return View("Account Locked");
                    }
                }

                ModelState.AddModelError("message", ResponseStatus.InvalidLoginAttempt);
            }

            return View(new LoginViewModel());
        }

        #endregion



        #region Logout user
        /// <summary>
        /// Logouts this instance.
        /// </summary>
        /// <returns></returns>
        [AllowAnonymous]
        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();
            return RedirectToAction("Login", "Account");
        }

        #endregion

        #region access denied

        /// <summary>
        /// This page will display when user session is out with the message accesses denied.
        /// </summary>
        /// <returns></returns>
        [AllowAnonymous]
        [HttpGet]
        public ActionResult AccessDenied()
        {
            return View();
        }

        #endregion


        #region Fogot Password

        /// <summary>
        /// Forgot password
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [AllowAnonymous]
        public IActionResult Forgotpassword()
        {
            return View();
        }

        /// <summary>
        /// Send reset password link while user forgot password
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> ForgotPassword(ForgotPasswordModel model)
        {
            if (ModelState.IsValid)
            {
                var user = await _userManager.FindByEmailAsync(model.Email);

                if (user != null)
                {
                    if (await _userManager.IsInRoleAsync(user, UserRoleEnum.Admin.ToString()))
                    {

                        if (user != null && await _userManager.IsEmailConfirmedAsync(user))
                        {
                            var token = await _userManager.GeneratePasswordResetTokenAsync(user);

                            var passwordResetLink = Url.Action("ResetPassword", "Account",
                                    new { email = model.Email, token = token }, Request.Scheme);

                            _userService.UpdateUserResetToken(user.Id, token);

                            var userName = _userService.GetUserNameById(user.Id);
                            EmailFunctions.SendResetPasswordEmail(ConfigurationKey.AdminForgetEmail, "Reset Password", (string.IsNullOrWhiteSpace(userName) ? user.NormalizedUserName : userName), passwordResetLink);
                            return View("ForgotPasswordConfirmation");
                        }
                        else
                        {
                            ModelState.AddModelError("message", "User Not Found");
                            ViewBag.errors = ResponseStatus.userNotFound;
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("message", ResponseStatus.InvalidUser);
                    }
                }
                else
                {
                    ModelState.AddModelError("message", ResponseStatus.InvalidLoginAttempt);
                }
            }
            return View(model);
        }

        #endregion


        #region  Generate Password

        /// <summary>
        /// Generate Password
        /// </summary>
        /// <param name="token"></param>
        /// <param name="email"></param>
        /// <returns></returns>
        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GeneratePassword(string token, string email)
        {
            if (token == null || email == null)
            {
                ModelState.AddModelError("", "Invalid password reset token");
            }
            var user = await _userManager.FindByEmailAsync(email);
            if (_userService.IsPasswordResetWithToken(user.Id))
            {
                return RedirectToAction("TokenExpired", "Account");
            }
            else
            {
                return View();
            }
        }

        /// <summary>
        /// Generate password after operator added successfully
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> GeneratePassword(ResetPassword model)
        {
            if (ModelState.IsValid)
            {
                var user = await _userManager.FindByEmailAsync(model.Email);

                if (user != null)
                {
                    var result = await _userManager.ResetPasswordAsync(user, model.Token, model.Password);
                    //var result1 = await userManager.ResetPasswordAsync(user, model.Token, model.Password);

                    if (result.Succeeded)
                    {
                        if (await _userManager.IsLockedOutAsync(user))
                        {
                            await _userManager.SetLockoutEndDateAsync(user, DateTimeOffset.UtcNow);
                        }

                        var token = await _userManager.GeneratePasswordResetTokenAsync(user);
                        _userService.SaveToken(user.Id, "", true);
                        return View("GeneratePasswordConfirmation");
                    }
                    else
                    {
                        ModelState.AddModelError("message", result.Errors.FirstOrDefault().Description);

                        return View(model);
                    }
                }
                else
                {
                    ModelState.AddModelError("message", ResponseStatus.InvalidLoginAttempt);

                    return View(model);
                }
            }
            return View(model);
        }


        #endregion


        #region Reset password
        /// <summary>
        /// Reset Password
        /// </summary>
        /// <param name="token"></param>
        /// <param name="email"></param>
        /// <returns></returns>
        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> ResetPassword(string token, string email)
        {
            try
            {
                if (token == null || email == null)
                {
                    ModelState.AddModelError("message", ResponseStatus.InvalidToken);
                }
                var user = await _userManager.FindByEmailAsync(email);
                if (user != null)
                {
                    if (_userService.IsPasswordResetWithToken(user.Id))
                    {
                        return RedirectToAction("TokenExpired", "Account");
                    }
                    else
                    {
                        return View();
                    }
                }
                else
                {
                    return RedirectToAction("TokenExpired", "Account");
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("message", ResponseStatus.InvalidToken);
                return View();
            }
        }

        /// <summary>
        /// Reset password if forgot
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> ResetPassword(ResetPassword model)
        {
            if (ModelState.IsValid)
            {
                var user = await _userManager.FindByEmailAsync(model.Email);

                if (user != null)
                {
                    bool isPassCorrect = (await _userManager.CheckPasswordAsync(user, model.Password));
                    if (isPassCorrect == false)
                    {
                        var result = await _userManager.ResetPasswordAsync(user, model.Token, model.Password);

                        if (result.Succeeded)
                        {
                            if (await _userManager.IsLockedOutAsync(user))
                            {
                                await _userManager.SetLockoutEndDateAsync(user, DateTimeOffset.UtcNow);
                            }

                            var token = await _userManager.GeneratePasswordResetTokenAsync(user);
                            _userService.SaveToken(user.Id, "", true);
                            return View("ResetPasswordConfirmation");
                        }
                        else
                        {
                            ModelState.AddModelError("message", result.Errors.FirstOrDefault().Description);
                            return View(model);
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("message", ResponseStatus.OldPasswordNewPasswordSame);
                        return View(model);
                    }
                }
                else
                {
                    ModelState.AddModelError("message", ResponseStatus.InvalidLoginAttempt);
                    return View(model);
                }
            }
            return View(model);
        }

        #endregion

        #region Token expire

        /// <summary>
        /// when generate password and reset password token expired this page will display with token expired message
        /// </summary>
        /// <returns></returns>
        public ActionResult TokenExpired()
        {
            return View();
        }

        #endregion

        #region Privacy policy

        public IActionResult PrivacyPolicy()
        {
            return View();
        }

        #endregion
    }
}
