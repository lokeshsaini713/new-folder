﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Data.Entities.Identity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using PlantM.Web.Controllers.Base;
using PlantM.Web.Extensions;
using Services.IService;
using Services.IServices;
using Services.Services;
using Shared.Models;
using Shared.Utilities;
using Shared.Utility;

namespace PlantM.Web.Controllers
{
    /// <summary>
    /// usage record
    /// </summary>
    [Authorize(Roles = "Admin")]
    public class UsageReportController : BaseController<UsageRecordModel>
    {
        private readonly UserManager<User> userManager;
        private readonly SignInManager<User> signInManager;
        private readonly INurseryService _nurseryService;
        private readonly ILookUpService _lookUpService;
        private readonly IUserService _userService;


        /// <summary>
        /// construct services
        /// </summary>
        /// <param name="saveFormFileSerivce"></param>
        /// <param name="service"></param>
        public UsageReportController(UserManager<User> userManager, SignInManager<User> signInManager, IUsageRecordService service, INurseryService nurseryService, ILookUpService lookUpService, IUserService userService) : base(service)
        {
            this.userManager = userManager;
            this.signInManager = signInManager;
            this._nurseryService = nurseryService;
            this._lookUpService = lookUpService;
            this._userService = userService;
        }


        #region Usage report list

        /// <summary>
        /// View Usage Report
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {          
            return View();
        }


        /// <summary>
        /// Get all usage record 
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public override ActionResult GetAll()
        {
            List<UsageRecordModel> list = ((IUsageRecordService)service).GetUsageRecordList(null,null);

            return base.GetJoinList(list);
        }


        /// <summary>
        /// Gets record by filter.
        /// </summary>
        /// <param name="fromDate">From date.</param>
        /// <param name="toDate">To date.</param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult GetByFilter(DateTime? fromDate, DateTime? toDate)
        {
            List<UsageRecordModel> list = ((IUsageRecordService)service).GetUsageRecordList(fromDate,toDate);

            return View("GetAll",list);
        }

        #endregion

        #region Export to CSV

        /// <summary>
        /// Checks the record.
        /// </summary>
        /// <param name="fromDate">From date.</param>
        /// <param name="toDate">To date.</param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult checkRecord(DateTime? fromDate, DateTime? toDate)
        {
            List<UsageRecordModel> list = ((IUsageRecordService)service).GetUsageRecordList(fromDate, toDate);

            if(list !=null && list.Count > 0)
            {
                return Json(true);
            }
            else
            {
                return Json(false);
            }
        }


        /// <summary>
        /// Exports to CSV.
        /// </summary>
        /// <param name="fromDate">From date.</param>
        /// <param name="toDate">To date.</param>
        /// <returns></returns>
        public IActionResult ExportToCsv(DateTime? fromDate, DateTime? toDate)
        {
            try
            {
                List<UsageRecordModel> list = ((IUsageRecordService)service).GetUsageRecordList(fromDate,toDate);
               
                    var builder = new StringBuilder();

                    builder.AppendLine("S.No,Submitted Date,User,Planting Contractor,Nursery,Genetic,Compartment,Target Stocking,Number Planted,Temp.,Soil Condition,Weather Condition,Fire Affected,Comments");

                    int i = 0;
                    foreach (var item in list)
                    {
                        i++;
                        builder.AppendLine(string.Join(",", i, item.CreatedOn.Value.ToString("dd/MM/yyyy").TrimEnd(','), Convert.ToString(item.OperatorName).TrimEnd(','), Convert.ToString(item.PlantingContractor).TrimEnd(','), Convert.ToString(item.NurseryName).TrimEnd(','), Convert.ToString(item.GeneticName).TrimEnd(','), Convert.ToString(item.Compartment).TrimEnd(','), Convert.ToString(item.TargetStocking).TrimEnd(','), Convert.ToString(item.NumberPlanted).TrimEnd(','), Convert.ToString(item.Temp).TrimEnd(','),
                            Convert.ToString(item.SoilCondition).TrimEnd(','), Convert.ToString(item.WeatherCondition).TrimEnd(','), Convert.ToString(item.FireAffected == true ? "Yes" : "No").TrimEnd(','), Convert.ToString(item.Comments)));
                    }
                    return File(Encoding.UTF8.GetBytes(builder.ToString()), "text/csv", "UsageReport-" + DateTime.Now.Ticks + ".csv");
                
            }
            catch (Exception ex) { return RedirectToAction("index"); }
        }

        #endregion
    }
}