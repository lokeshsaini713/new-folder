﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PlantM.Web.Controllers.Base;
using PlantM.Web.Extensions;
using Services.IServices;
using Services.Services;
using Shared.Models;
using Shared.Common;
using Shared.Utilities;
using Shared.Utility;
using Newtonsoft.Json;

namespace PlantM.Web.Controllers
{
    /// <summary>
    /// LookUp management
    /// </summary>
    [Authorize(Roles = "Admin")]
    public class LookUpController : BaseController<LookUpModel>
    {

        /// <summary>
        /// construct services
        /// </summary>
        /// <param name="saveFormFileSerivce"></param>
        /// <param name="service"></param>
        public LookUpController(ILookUpService service) : base(service)
        {
        }

        #region Parameter list

        /// <summary>
        /// View Parameter
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            if (TempData["Message"] != null)
            {
                ViewBag.ResultMSG = TempData["Message"];
                TempData["Message"] = null;
            }

            return View();
        }

        /// <summary>
        /// Get all Parameter list
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public override ActionResult GetAll()
        {
            return base.GetAll();
        }
        #endregion


        #region Parameter add and update

        /// <summary>
        /// Get parameter for add or update
        /// </summary>
        /// <param name="id">Parameter id</param>
        /// <returns></returns>
        [HttpGet]
        public override ActionResult AddUpdate(long id)
        {
            ViewBag.ParameterList = CommonFunction.EnumToList<ParameterEnum>();
            return base.AddUpdate(id);
        }

        /// <summary>
        /// added or updated parameter
        /// </summary>
        /// <param name="model">parameter detais</param>
        /// <returns></returns>
        [HttpPost]
        public override ActionResult AddUpdate(LookUpModel model)
        {
            ViewBag.ParameterList = CommonFunction.EnumToList<ParameterEnum>();
            if (ModelState.IsValid)
            {
                if (model != null)
                {

                    if (model.Id == 0)
                    {
                        if (((ILookUpService)service).CheckExist(model.GroupName, model.Value, 0))
                        {
                            ModelState.AddModelError("message", ResponseStatus.ParameterExists);
                            return View("AddUpdate", model);
                        }
                        else
                        {
                            if (((ILookUpService)service).CheckExist(model.GroupName, model.Value, model.Id))
                            {
                                ModelState.AddModelError("message", ResponseStatus.ParameterExists);
                                return View("AddUpdate", model);
                            }
                            else
                            {

                                SuccessMessageModel successMsgModel = new SuccessMessageModel();
                                successMsgModel.IsSuccess = true;
                                successMsgModel.Message = ResponseStatus.ParameterAdd;
                                string successMsg = JsonConvert.SerializeObject(successMsgModel);

                                TempData["Message"] = successMsgModel.Message;
                                TempData.Keep("Message");
                                return base.AddUpdate(model);
                            }
                        }
                    }
                    else
                    {
                        SuccessMessageModel successMsgModel = new SuccessMessageModel();
                        successMsgModel.IsSuccess = true;
                        successMsgModel.Message = ResponseStatus.ParameterUpdated;
                        string successMsg = JsonConvert.SerializeObject(successMsgModel);

                        TempData["Message"] = successMsgModel.Message;
                        TempData.Keep("Message");
                        return base.AddUpdate(model);
                    }
                }
            }
            return View("AddUpdate", model);
        }

        #endregion


        #region Remove parameter

        /// <summary>
        /// Remove parameter
        /// </summary>
        /// <param name="id">parameter id</param>
        /// <returns></returns>
        [HttpPost]
        public override ActionResult Remove(long id)
        {
            return base.Remove(id);
        }

        #endregion

        
    }
}