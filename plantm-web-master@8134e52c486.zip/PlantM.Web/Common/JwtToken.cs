﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Threading.Tasks;

namespace PlantM.Web.Common
{
    public class JwtToken
    {
        private JwtSecurityToken securityToken;

        internal JwtToken(JwtSecurityToken token)
        {
            this.securityToken = token;
        }

        public DateTime ValidTo => securityToken.ValidTo;
        public string Value => new JwtSecurityTokenHandler().WriteToken(this.securityToken);
    }
}