using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Data.Context;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Services.IService;
using Services.Services;
using Shared.Common;
using Shared.Utilities;

namespace PlantM.Web
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            var host = CreateHostBuilder(args).Build();
            using (var scope = host.Services.CreateScope())
            {
                var services = scope.ServiceProvider;
                var loggerFactory = services.GetRequiredService<ILoggerFactory>();

                ExceptionLoggerExtentionMetod.service = services.GetRequiredService<IExceptionLogginService>();
                var webHosting = services.GetRequiredService<IWebHostEnvironment>();
                var _configuration = services.GetRequiredService<IConfiguration>();

                EmailFunctions.WebTemplatePath = string.Format("{0}{1}", webHosting.WebRootPath, _configuration.GetValue<string>("Paths:EmailPath"));
                EmailFunctions.MailLogoPath = string.Format("{0}{1}", webHosting.WebRootPath, _configuration.GetValue<string>("Paths:MailLogoPath"));

                try
                {
                    //migrate database
                    var identityContext = services.GetRequiredService<Data.Context.PlantMAppContext>();
                    await identityContext.Database.MigrateAsync();
                    //import seed data
                    await PlantMAppContextSeed.SeedAsync(services, identityContext);

                }
                catch (Exception ex)
                {
                    var logger = loggerFactory.CreateLogger<Program>();
                    logger.LogError($"An error occurred during migration: {ex.Message}");
                }
            }
            host.Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });
    }
}
