using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Data.Entities.Identity;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using Data.Context;
using PlantM.Web.Extensions;
using PlantM.Web.Helper;
using AutoMapper;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using PlantM.Web.Common;
using Shared.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Shared.Utility;
using Shared.Common;
using Shared.Utilities;
using PlantM.Web.Model;
using Microsoft.OpenApi.Models;

namespace PlantM.Web
{
    public class Startup
    {

        public IConfiguration Configuration { get; }

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddAutoMapper(typeof(MappingProfiles));
            services.AddControllers();

            services.Configure<CookiePolicyOptions>(options =>
            {
                // This lambda determines whether user consent for non-essential cookies is needed for a given request.
                options.CheckConsentNeeded = context => true;
                options.MinimumSameSitePolicy = SameSiteMode.None;
            });

            // The TempData provider cookie is not essential. Make it essential
            // so TempData is functional when tracking is disabled.
            services.Configure<CookieTempDataProviderOptions>(options => {
                options.Cookie.IsEssential = true;
            });

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            .AddJwtBearer(options =>
            {
                options.TokenValidationParameters = new TokenValidationParameters()
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateIssuerSigningKey = true,
                    ValidateLifetime = true,
                    ValidIssuer = Configuration.GetValue<string>("JwtTokenSettings:IsUser"),
                    ValidAudience = Configuration.GetValue<string>("JwtTokenSettings:Audience"),
                    IssuerSigningKey = JwtSecurityKey.Create(Configuration.GetValue<string>("JwtTokenSettings:Secrete")),

                    //RequireExpirationTime = true,
                    //ClockSkew = TimeSpan.Zero
                };
                options.Events = new JwtBearerEvents
                {
                    OnAuthenticationFailed = context =>
                    {
                        context.NoResult();
                        context.Response.StatusCode = ResponseCode.Unauthorized;
                        context.Response.ContentType = "application/json";
                        context.Response.WriteAsync(Newtonsoft.Json.JsonConvert.SerializeObject(
                            new ApiResponses<string> { FailureMsg = ResponseStatus.UnauthorizedMessage, ValidationErrors = new List<string>(), ResponseCode = (short)ResponseCode.Unauthorized, Data = null }

                        , new JsonSerializerSettings
                        {
                            ContractResolver = new CamelCasePropertyNamesContractResolver()
                        })).Wait();
                        return Task.CompletedTask;
                    },
                    OnTokenValidated = context =>
                    {
                        return Task.CompletedTask;
                    }
                };
            });

            services.AddDbContext<Data.Context.PlantMAppContext>(config =>
            {
                config.UseMySQL(Configuration.GetConnectionString("PlantMConection"));
            });

            //AddIdentity register the services
            services.AddIdentity<User, Role>(options =>
            {
                // Password settings.
                options.Password.RequireDigit = false;
                options.Password.RequireLowercase = false;
                options.Password.RequireNonAlphanumeric = false;
                options.Password.RequireUppercase = false;
                options.Password.RequiredLength = 6;
                options.Password.RequiredUniqueChars = 2;

                // Lockout settings.
                options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(5);
                options.Lockout.MaxFailedAccessAttempts = 5;
                options.Lockout.AllowedForNewUsers = true;

                // User settings.
                options.User.AllowedUserNameCharacters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._@+";
                options.User.RequireUniqueEmail = true;
            }).
                AddEntityFrameworkStores<PlantMAppContext>().
                AddDefaultTokenProviders();

          
            services.ConfigureApplicationCookie(options =>
            {
                //Cookie settings
                options.Cookie.Name = "PlantMAuthenticate";
                //options.Cookie.HttpOnly = true;
                options.ExpireTimeSpan = TimeSpan.FromMinutes(60);

                options.LoginPath = "/Account/Login";
                options.AccessDeniedPath = "/Account/AccessDenied";
                options.SlidingExpiration = true;
            });
            
           
            services.AddAuthorization(options =>
            {
                options.AddPolicy("AuthorisedUser", policy =>
                {
                    policy.RequireClaim("UserId");
                });
                options.AddPolicy("AdminAccess", policy =>
                {
                    policy.RequireClaim("UserRole", UserRoleEnum.Admin.ToString());
                });

                options.AddPolicy("AdminRolePolicy", policy =>
                {
                    policy.RequireClaim("Device");
                });

                options.AddPolicy("AdminRolePolicy", policy =>
                {
                    policy.RequireClaim("DeviceType");
                });

                options.AddPolicy("AdminRolePolicy", policy =>
                {
                    policy.RequireClaim("Offset");
                });
            });

            #region Swagger

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Version = "v1",
                    Title = "PlantM API",
                    Description = "The objective of this API is to develop an effective mobile app for customers to avail seed for plantation.",
                });

                c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    Description = "JWT Authorization header using the Bearer scheme. \r\n\r\n Enter 'Bearer' [space] and then your token in the text input below.\r\n\r\nExample: \"Bearer 12345abcdef\"",
                    Name = "Authorization",
                    In = ParameterLocation.Header,
                    Type = SecuritySchemeType.ApiKey,
                    Scheme = "Bearer"
                });

                c.AddSecurityRequirement(new OpenApiSecurityRequirement()
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                            {
                                Type = ReferenceType.SecurityScheme,
                                Id = "Bearer"
                            },
                            Scheme = "oauth2",
                            Name = "Bearer",
                            In = ParameterLocation.Header,
                        },
                        new List<string>()
                    }
                });
            });

            #endregion

            #region Set Constants

            services.Configure<JwtTokenSettings>(Configuration.GetSection("JwtTokenSettings"));//for jwt token

            ConfigurationKey.MailServer = Configuration.GetValue<string>("AppSettings:MailServer");
            ConfigurationKey.EmailFromAddress = Configuration.GetValue<string>("AppSettings:EmailFromAddress");
            ConfigurationKey.EmailFromName = Configuration.GetValue<string>("AppSettings:EmailFromName");
            ConfigurationKey.EmailBCC = Configuration.GetValue<string>("AppSettings:EmailBCC");
            ConfigurationKey.Port = Configuration.GetValue<string>("AppSettings:Port");
            ConfigurationKey.MailAuthUser = Configuration.GetValue<string>("AppSettings:MailAuthUser");
            ConfigurationKey.MailAuthPass = Configuration.GetValue<string>("AppSettings:MailAuthPass");
            ConfigurationKey.EnableSSL = Configuration.GetValue<string>("AppSettings:EnableSSL");
            ConfigurationKey.EmailPath = Configuration.GetValue<string>("AppSettings:EmailPath");

            ConfigurationKey.SaveImagePath = Configuration.GetValue<string>("Paths:ImagesUploadPath");
            ConfigurationKey.ProfilePicPath = Configuration.GetValue<string>("Paths:ProfileImages");

            ConfigurationKey.WebUrl = Configuration.GetValue<string>("AppSettings:WebUrl");
            ConfigurationKey.AdminForgetEmail = Configuration.GetValue<string>("AppSettings:AdminForgetEmail");

            ConfigurationKey.AndroidInAppAccountEmail = Configuration.GetValue<string>("InAppSetting:AndroidInAppAccountEmail");
            ConfigurationKey.AndroidInAppPackage = Configuration.GetValue<string>("InAppSetting:AndroidInAppPackage");
            ConfigurationKey.AndroidInAppCertificatePath = Configuration.GetValue<string>("InAppSetting:AndroidInAppCertificatePath");
            ConfigurationKey.DBConnectionString = Configuration.GetValue<string>("ConnectionStrings:PlantMConection");


            services.Configure<AppSettings>(Configuration.GetSection("AppSettings"));

            #endregion

            services.AddMemoryCache();
            services.AddSession();

            services.AddControllersWithViews();
            services.AddRazorPages();
            services.AddServices();
        }
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                //app.UseDatabaseErrorPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }

            app.UseRouting();

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseCookiePolicy();

            app.UseAuthentication();

            app.UseAuthorization();

            app.UseRequestLocalization();

            // Enable middleware to serve generated Swagger as a JSON endpoint.
            app.UseSwagger();

            // Enable middleware to serve swagger-ui (HTML, JS, CSS, etc.),
            // specifying the Swagger JSON endpoint.
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "PlantM API");
            });

            app.UseSession();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute("areaRoute", "{area:exists}/{controller=Home}/{action=Index}/{id?}");

                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Account}/{action=Login}/{id?}");

                //Configure new area
                endpoints.MapAreaControllerRoute("API",
                    "API",
                    "{controller=swagger}");
            });
        }
    }
}
