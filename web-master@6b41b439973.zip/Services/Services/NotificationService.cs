﻿using Data.Entities;
using Data.IRepository;
using Data.Repository.GenericRepository;
using Microsoft.Data.SqlClient;
using Services.IServices;
using Shared.Common;
using Shared.Models;
using Shared.Models.API;
using Shared.Models.ProcResults;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Services.Services
{
    public class NotificationService : INotifications
    {
        private readonly IGenericProcDataRepository<NotificationsEntity> _repository;
        private readonly FCMPushNotification _fCMPushNotification;
        public NotificationService(IGenericProcDataRepository<NotificationsEntity> repository, FCMPushNotification fCMPushNotification)
        {
            _repository = repository;
            _fCMPushNotification = fCMPushNotification;
        }
        public IList<GetNotification_Result> GetNotification(string userId, PaginationModel pg)
        {
            try
            {
                SqlParameter[] sqlParams = { new SqlParameter("@UserId", userId),
                                         new SqlParameter("@PageNum",pg.PageNo ),
                                        new SqlParameter("@PageSize",pg.PageSize)};

                string sql = "EXEC GetNotification @UserId ,@PageNum ,@PageSize";
                IList<GetNotification_Result> lst = new List<GetNotification_Result>();
                var result = _repository.SqlQueryAPI<GetNotification_Result>(sql, sqlParams);
                if (result != null && result.Count!=0) {
                    lst = result.Select(e => new GetNotification_Result(){
                       ProFilePath = e.ProFilePath,
                       FirstName = e.FirstName,
                       LastName =e.LastName,
                       Description = e.Description,
                       IsRead= e.IsRead,
                       SenderUserId = e.SenderUserId,
                       CreatedOn = e.CreatedOn
                    }).ToList();
                }
                return lst;
            }
            catch (Exception ex)
            {

                ex.Log();
                return new List<GetNotification_Result>();


            }
        }

        public bool SendNotifications()
        {
            string sql = "EXEC GetNotificationUserList";
            IList<GetNotificationUserList_Result> lst = new List<GetNotificationUserList_Result>();
            var result = _repository.SqlQueryAPI<GetNotificationUserList_Result>(sql);
            if (result != null && result.Count != 0)
            {
                lst = result.Select(e => new GetNotificationUserList_Result()
                {
                    UserId = e.UserId,
                    DeviceType = e.DeviceType,
                    DeviceToken = e.DeviceToken,
                    NotificationMessage = e.NotificationMessage
                }).ToList();

                foreach (var item in lst)
                {
                    FCMPushNotificationModel model = new FCMPushNotificationModel();
                    model.DeviceType = item.DeviceType;
                    model.deviceToken = item.DeviceToken;
                    model.Message = item.NotificationMessage;
                    model.TypeOfMessge = "";
                    model.BadgeCount = 1;
                    model.NotificationTitle = "Test Notification";
                    model.NotificationId = 0;
                    _fCMPushNotification.SendNotice(model);
                }
            }
            return true;
        }

        public bool SaveNotification(SaveNotificationRequestModel saveNotificationRequestModel)
        {
            try
            {
                SqlParameter[] sqlParams = { new SqlParameter("@SenderUserId", saveNotificationRequestModel.SenderUserId),
                                         new SqlParameter("@ReceiverUserId",saveNotificationRequestModel.ReceiverUserId ),
                                        new SqlParameter("@Description",saveNotificationRequestModel.Description),
                                        new SqlParameter("@CreatedOn",DateTime.UtcNow.GetLocal())};
                string sql = "EXEC SaveNotification @SenderUserId ,@ReceiverUserId ,@Description,@CreatedOn";
                var result = _repository.SqlQueryAPI<UserDeviceResponseModel>(sql, sqlParams).FirstOrDefault();
                if (result != null)
                {
                    FCMPushNotificationModel model = new FCMPushNotificationModel();
                    model.DeviceType = result.DeviceType;
                    model.deviceToken = result.DeviceToken;
                    model.Message = saveNotificationRequestModel.Description;
                    model.TypeOfMessge = "";
                    model.BadgeCount = 1;
                    model.NotificationTitle = saveNotificationRequestModel.Title;
                    model.NotificationId = 0;
                    _fCMPushNotification.SendNotice(model);
                }
                return true;

            }
            catch (Exception ex)
            {
                ex.Log();
                return false;
            }
        }
    }
}
