﻿using AutoMapper;
using Data.Entities;
using Data.IRepository;
using Data.Repository.GenericRepository;
using Microsoft.Data.SqlClient;
using Services.Generic;
using Services.IServices;
using Shared.Common;
using Shared.Models;
using Shared.Models.ProcResults;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Services.Services
{
    public class CapsoulesShareRequestService : GenericService<CapsoulesShareRequestModel, CapsoulesShareRequestEntity>, ICapsoulesShareRequestService
    {
        private readonly IGenericProcDataRepository<CapsoulesShareRequestEntity> _repository;
        public CapsoulesShareRequestService(GenericDataRepository<CapsoulesShareRequestEntity> repo, IMapper mapper,
            IGenericProcDataRepository<CapsoulesShareRequestEntity> repository
            ) : base(repo, mapper)
        {
            _repository = repository;
        }

        public bool Add(CapsoulesShareRequestModel usercap)
        {
            try
            {
                return base.Add(usercap);
            }
            catch (Exception ex)
            {
                ex.Log();
                return false;
            }
        }

        public IList<GetConnectionList_Result> GetConnectionList(SearchModel model, string UserId)
        {
            try
            {
                IList<GetConnectionList_Result> MyConList = new List<GetConnectionList_Result>();

                SqlParameter[] sqlParams = { new SqlParameter("@UserId", UserId),
                                         new SqlParameter("@PageNo",model.PageNo ),
                                         new SqlParameter("@PageSize",model.PageSize),
                                         new SqlParameter("@Search",model.Search),
                };

                string sql_1 = "EXEC GetConnectionList @UserId, @PageNo, @PageSize, @Search";

                var MyCon = _repository.SqlQueryAPI<GetConnectionList_Result>(sql_1, sqlParams);

                if (MyCon != null && MyCon.Count > 0)
                {
                    MyConList = MyCon.Select(e => new GetConnectionList_Result()
                    {
                        Id = e.Id,
                        Name = e.Name,
                        ProfilePath = e.ProfilePath,
                        UserId= e.UserId
                    }).ToList();
                }
                return MyConList;
            }
            catch (Exception ex)
            {
                ex.Log();
                return new List<GetConnectionList_Result>();
            }
        }

        public bool UpdateStatus(params CapsoulesShareRequestViewModel[] items)
        {
            try
            {
                foreach (var capUserModel in items)
                {
                    var usercap = this.repository.context.CapsoulesShareRequest.FirstOrDefault(e => e.Id == capUserModel.Id);
                    usercap.Status = capUserModel.Status;
                    this.repository.context.SaveChanges();
                }
                return true;
            }
            catch (Exception ex)
            {
                ex.Log();
                return false;
            }
        }

        public bool RemoveUserConnection(Capsoule cap)
        {
            try
            {

                var usercap = this.repository.context.CapsoulesShareRequest.FirstOrDefault(e => e.Id == cap.CapId);
               
                if (usercap != null)
                {
                    usercap.IsDeleted = true;
                    usercap.IsActive = false;
                    usercap.UpdatedOn = DateTime.UtcNow.GetLocal();
                    this.repository.context.Remove(usercap);
                   this.repository.context.SaveChanges();

                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                ex.Log();
                return false;
            }
        }

    }
}
