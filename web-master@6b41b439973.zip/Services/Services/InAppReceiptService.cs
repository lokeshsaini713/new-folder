﻿using AutoMapper;
using Data.Entities;
using Data.IRepository;
using Data.Repository.GenericRepository;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using Services.Generic;
using Services.IServices;
using Services.IServices.Identity;
using Shared.Common;
using Shared.Models;
using Shared.Models.ProcResults;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

/// <summary>
/// 
/// </summary>
namespace Services.Services
{
    public class InAppReceiptService : GenericService<InAppReceiptModel, InAppReceiptEntity>, IInAppReceiptService
    {
        private readonly IGenericDataRepository<InAppReceiptEntity> _repository;
        public InAppReceiptService(GenericDataRepository<InAppReceiptEntity> repo, IMapper mapper,
            IGenericDataRepository<InAppReceiptEntity> repository
            ) : base(repo, mapper)
        {
            _repository = repository;
        }

        public bool Add(InAppReceiptModel receiptModel)
        {
            try
            {
                return base.Add(receiptModel);
            }
            catch (Exception ex)
            {

                ex.Log();
                return false;
            }
        }
    }
}
