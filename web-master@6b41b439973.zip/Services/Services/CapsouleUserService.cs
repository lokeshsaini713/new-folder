﻿using AutoMapper;
using Data.Entities;
using Data.IRepository;
using Data.Repository.GenericRepository;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using Services.Generic;
using Services.IServices;
using Services.IServices.Identity;
using Shared.Common;
using Shared.Models;
using Shared.Models.ProcResults;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

/// <summary>
/// 
/// </summary>
namespace Services.Services
{
    public class CapsouleUserService : GenericService<UserCapsoulesModel, UserCapsoulesEntity>, ICapsouleUser
    {
        private readonly IGenericDataRepository<UserCapsoulesEntity> _repository;
        private readonly IUserService _userManager;
        private readonly ISubscriptionService _subscription;
        public CapsouleUserService(GenericDataRepository<UserCapsoulesEntity> repo, IMapper mapper,
            IGenericDataRepository<UserCapsoulesEntity> repository,
            IUserService userService,
            ISubscriptionService subscription
            ) : base(repo, mapper)
        {
            _repository = repository;
            _userManager = userService;
            _subscription = subscription;
        }


        public bool AddCapsouleUser(UserCapsoulesModel usercap)
        {
            try
            {
                //Check  for user availablity to use app (its free or paid user)

                var userAccess = _subscription.IsAppAccessible(usercap.UserId);

                if (userAccess.Message == "Free" && userAccess.IsAccessAllowed == true)
                {
                    var cap = this.repository.context.UserCapsoules.Where(e => e.UserId == usercap.UserId 
                                                                    && e.IsActive==true 
                                                                    && e.IsDeleted==false).Count();

                    //if free then can add only 3 capsoule
                    if (cap >= 3)
                    {
                        return false;
                    }
                    else
                    {
                        return base.Add(usercap);
                    }
                }
                //if user have paid for the plan
                else if (userAccess.Message == "Access" && userAccess.IsAccessAllowed == true)
                {
                    return base.Add(usercap);
                }

                return false;
            }
            catch (Exception ex)
            {
                ex.Log();
                return false;
            }
        }

        public bool Update(params UserCapsoulesViewModel[] items)
        {
            try
            {
                foreach (var capUserModel in items)
                {

                    var usercap = this.repository.context.UserCapsoules.FirstOrDefault(e => e.Id == capUserModel.Id);

                    usercap.Title = capUserModel.Title;
                    usercap.ProfilePath = capUserModel.ProfilePath;
                    usercap.RelationShipId = capUserModel.RelationShipId != 0 ? capUserModel.RelationShipId : usercap.RelationShipId;
                    usercap.Description = capUserModel.Description;
                    usercap.CoverImage = capUserModel.CoverImage;
                    //usercap.D = capUserModel.DoB;
                    //usercap.UserId = UserId;

                    this.repository.context.SaveChanges();
                }
                return true;
            }
            catch (Exception ex)
            {
                ex.Log();
                return false;
            }
        }

        public bool Remove(Capsoule cap)
        {
            try
            {

                var usercap = this.repository.context.UserCapsoules.FirstOrDefault(e => e.Id == cap.CapId);

                if (usercap != null)
                {
                    usercap.IsDeleted = true;
                    usercap.IsActive = false;
                    usercap.UpdatedOn = DateTime.UtcNow.GetLocal();
                    this.repository.context.SaveChanges();

                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                ex.Log();
                return false;
            }
        }

        public MyWallModel GetMyWallDetail(string userId)
        {
            try
            {
                MyWallModel wallcaps = new MyWallModel();
                //User's created capsoule 
                SqlParameter[] sqlParams = { new SqlParameter("@UserId", userId) };

                string sql = "EXEC GetUserCapbyUserId @UserId";

                var userCap = _repository.SqlQueryAPI<SharedUserCap>(sql, sqlParams);

                if (userCap != null && userCap.Count > 0)
                {
                    wallcaps.UserCapsouleList = userCap.Select(e => new SharedUserCap()
                    {
                        Id = e.Id,
                        Title = e.Title,
                        ProfilePath = e.ProfilePath,
                        Relationship = e.Relationship,
                        CoverImage = e.CoverImage,
                        Description = e.Description

                    }).ToList();
                }

                // user shared capsoule
                SqlParameter[] Param = { new SqlParameter("@UserId", userId) };

                string sql_1 = "EXEC GetSharedCapByUser @UserId";

                var Sharecap = _repository.SqlQueryAPI<SharedUserCap>(sql_1, Param);

                if (Sharecap != null && Sharecap.Count > 0)
                {
                    wallcaps.sharedUserCapList = Sharecap.Select(e => new SharedUserCap()
                    {
                        Id = e.Id,
                        Title = e.Title,
                        ProfilePath = e.ProfilePath,
                        Relationship = e.Relationship,
                        CoverImage = e.CoverImage

                    }).ToList();
                }


                return wallcaps;
            }
            catch (Exception ex)
            {
                ex.Log();
                return new MyWallModel();
            }

        }

        public IList<GetMyConnection_Result> GetMyConnection(SearchModel PgModel, string UserId)
        {
            try
            {
                IList<GetMyConnection_Result> MyConList = new List<GetMyConnection_Result>();

                SqlParameter[] sqlParams = { new SqlParameter("@userId", UserId),
                                             new SqlParameter("@PageNo",PgModel.PageNo ),
                                             new SqlParameter("@PageSize",PgModel.PageSize),
                                             new SqlParameter("@Search",PgModel.Search),
                };

                string sql_1 = "EXEC GetMyConnection @UserId, @PageNo, @PageSize, @Search";

                var MyCon = _repository.SqlQueryAPI<GetMyConnection_Result>(sql_1, sqlParams);

                if (MyCon != null && MyCon.Count > 0)
                {
                    MyConList = MyCon.Select(e => new GetMyConnection_Result()
                    {
                        Id = e.Id,
                        UserId = e.UserId,
                        Name = e.Name,
                        ProfilePath = e.ProfilePath,

                    }).ToList();
                }
                return MyConList;
            }
            catch (Exception ex)
            {
                ex.Log();
                return new List<GetMyConnection_Result>();
            }
        }




    }
}
