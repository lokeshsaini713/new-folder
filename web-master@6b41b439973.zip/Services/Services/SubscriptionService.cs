﻿using AutoMapper;
using Data.Entities;
using Data.IRepository;
using Data.Repository.GenericRepository;
using Services.Generic;
using Services.IServices;
using Shared.Models;
using Shared.Models.ProcResults;
using System;
using System.Collections.Generic;
using System.Linq;
using Google.Apis.AndroidPublisher.v3;
using Google.Apis.Auth.OAuth2;
using Google.Apis.Services;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using Services.InApp;
using Shared.Common;
using Microsoft.Extensions.Options;

namespace Services.Services
{
    public class SubscriptionService : GenericService<SubscriptionsModel, SubscriptionsEntity>, ISubscriptionService
    {
        private readonly IGenericProcDataRepository<SubscriptionsEntity> _repository;
        private readonly ConfigurationKeys _configurationKey;
        private readonly IInAppReceiptService _inAppService;

        public SubscriptionService(GenericDataRepository<SubscriptionsEntity> repo, IMapper mapper,
            IOptions<ConfigurationKeys> configurationKey,
         IInAppReceiptService inAppService
            // GenericProcDataRepository repository
            ) : base(repo, mapper)
        {
            _configurationKey = configurationKey.Value;
            _inAppService = inAppService;
        }
        #region Actions

        public IList<GetSubscription_Result> GetAllSubscription()
        {
            string sql = "EXEC GetSubscription";

            var result = _repository.SqlQueryAPI<GetSubscription_Result>(sql);

            IList<GetSubscription_Result> subscriptions = new List<GetSubscription_Result>();

            if (result != null && result.Count > 0)
            {
                subscriptions = result.Select(e => new GetSubscription_Result()
                {
                    AllowImageUpload = e.AllowImageUpload,
                    AllowVideoUpload = e.AllowVideoUpload,
                    Amount = e.Amount,
                    Description = e.Description,
                    IsActive = e.IsActive,
                    Name = e.Name
                }).ToList();
            }
            return subscriptions;
        }
        #endregion

        #region [InApp Plan Section]
        public AppAccessibleReponse IsAppAccessible(string UserId)
        {
            AppAccessibleReponse appAccessibleReponse = new AppAccessibleReponse();

            try
            {
                var IsAppAccessible = this.repository.context.InAppReceipt.FirstOrDefault(e => e.UserId == UserId);

                if (IsAppAccessible == null)
                {
                    appAccessibleReponse.Message = "Free";
                    appAccessibleReponse.IsAccessAllowed = true;
                    return appAccessibleReponse;
                }
                else
                {
                    if (IsAppAccessible.ExpiryDate > DateTime.Now)
                    {

                        appAccessibleReponse.Message = "Access";
                        appAccessibleReponse.IsAccessAllowed = true;
                        return appAccessibleReponse;

                    }
                    else {
                        appAccessibleReponse.Message = "NoAccess";
                        appAccessibleReponse.IsAccessAllowed = false;
                        return appAccessibleReponse;

                    }
                }
            }
            catch (Exception ex)
            {
                return new AppAccessibleReponse
                {
                    IsAccessAllowed = false,
                    Message = "error"
                };
            }
        }
       

        public bool SaveUserInAppDetails(InAppReceiptModel data)
        {
            try
            {
                ReceiptResult objReceipt = new ReceiptResult();
                if (data.SubscriptionId == 5)
                {
                    objReceipt = GetFreeReceiptData(data.Receipt , data.InAppPassword, data.DeviceType);
                }
                else
                {
                    objReceipt = GetReceiptData(data.Receipt, data.InAppPassword, data.DeviceType);
                }

                if (objReceipt.TransactionId != null && objReceipt.TransactionId != "")
                {
                   return _inAppService.Add(data);

                    //    string sqlQuery = "EXEC [dbo].[SaveUserInAppDetails] @UserId,@PlanId,@Receipt,@InAppPassword,@OriginalPurchaseDate,@ExpiryDate,@ProductId,@TransactionId,@DeviceType";
                    //    SqlParameter parameterUserId = new SqlParameter("@UserId", userId);
                    //    SqlParameter parameterPlanId = new SqlParameter("@PlanId", data.PlanId);
                    //    SqlParameter parameterReceipt = new SqlParameter("@Receipt", data.Receipt);
                    //    SqlParameter parameterInAppPassword = new SqlParameter("@InAppPassword", data.Password);
                    //    SqlParameter parameterOriginalPurchaseDate = new SqlParameter("@OriginalPurchaseDate", objReceipt.OriginalPurchaseDate);
                    //    SqlParameter parameterExpiryDate = new SqlParameter("@ExpiryDate", objReceipt.ExpiryDate);
                    //    SqlParameter parameterProductId = new SqlParameter("@ProductId", objReceipt.ProductId);
                    //    SqlParameter parameterTransactionId = new SqlParameter("@TransactionId", objReceipt.TransactionId);
                    //    SqlParameter parameterDeviceType = new SqlParameter("@DeviceType", data.DeviceType);
                    //    var listData = dbContext.SaveUserInAppDetails_Results.FromSqlRaw(sqlQuery, parameterUserId, parameterPlanId, parameterReceipt,
                    //        parameterInAppPassword, parameterOriginalPurchaseDate, parameterExpiryDate, parameterProductId, parameterTransactionId,
                    //        parameterDeviceType).ToList();
                    //    return new ApiResponses<bool>(ResponseMsg.Ok, true, _errors, successMsg: ResponseStatus.success, apiName: "SaveUserInAppDetails");
                }
                else
                {
                    return false; }
            }
            catch (Exception ex)
            {
                ex.Log();
                return false;
            }
        }

       
        /// <summary>
        /// To get original purchase date and expiry date for android receipt token - for in app purchase.
        /// </summary>
        /// <param name="receiptToken"></param>
        /// <returns></returns>
        public ReceiptResult GetAndroidInAppReceiptDetail(string subscriptionId, string receiptToken)
        {
            ReceiptResult obj = new ReceiptResult();
            string packageName = string.Empty;
            try
            {
                string serviceAccountEmail = _configurationKey.AndroidInAppAccountEmail;
                packageName = _configurationKey.AndroidInAppPackage;
                //var certificate = new X509Certificate2(@"E:\WorkingDir\Git_Projects\FishingApp\FishingTrip.Web\wwwroot\InAppCertificate\SiteBox-afee685d51c0.p12", "notasecret", X509KeyStorageFlags.Exportable);
                var certificate = new X509Certificate2(_configurationKey.AndroidInAppCertificatePath, "notasecret", X509KeyStorageFlags.Exportable);
                //var certificate = new X509Certificate2("E:\\appdemo\\wds2\\FishingTripDemo\\wwwroot\\InAppCertificate\\fishing-trips-293411-d82bd4dbf760.p12", "notasecret", X509KeyStorageFlags.Exportable);
                //var certificate = new X509Certificate2("F:\\FishingTrip\\FishingTrip.Web\\wwwroot\\InAppCertificate\\fishing-trips-293411-d82bd4dbf760.p12", "notasecret", X509KeyStorageFlags.Exportable);
                ServiceAccountCredential credential = new ServiceAccountCredential(
                   new ServiceAccountCredential.Initializer(serviceAccountEmail)
                   {
                       Scopes = new[] { "https://www.googleapis.com/auth/androidpublisher" }
                   }.FromCertificate(certificate));

                var service = new AndroidPublisherService(
               new BaseClientService.Initializer()
               {
                   HttpClientInitializer = credential,
                   ApplicationName = "Memory Capsoule",
               });
                var pur = service.Purchases;
                var sub = pur.Subscriptions.Get(packageName, subscriptionId, receiptToken).Execute();

                double ticks = double.Parse(Convert.ToString(sub.StartTimeMillis));//InitiationTimestampMsec
                TimeSpan time = TimeSpan.FromMilliseconds(ticks);
                DateTime dtPurchase = new DateTime(1970, 1, 1) + time;

                ticks = double.Parse(Convert.ToString(sub.ExpiryTimeMillis));//ValidUntilTimestampMsec
                time = TimeSpan.FromMilliseconds(ticks);
                DateTime dtExpiry = new DateTime(1970, 1, 1) + time;

                obj.OriginalPurchaseDate = dtPurchase;
                obj.ExpiryDate = dtExpiry;
                obj.SubscriptionId = sub.OrderId;
                obj.TransactionId = sub.Kind;
            }
            catch (Exception ex)
            {
                ex.Log();
                //obj.ProductId = JsonConvert.SerializeObject(ex);
               //ErrorLog(JsonConvert.SerializeObject(ex), _configurationKey.AndroidInAppCertificatePath);

                //string InputData = string.Format(CultureInfo.InvariantCulture, "receiptToken: {0}, subscriptionId: {1}", receiptToken, subscriptionId);
                //ErrorLogBusiness.LogErrorOccured(ReturnMessage.Failed, "GetAndroidInAppReceiptDetail", InputData, ex.Message, ReturnMessage.Failed, 0, "InAppBusiness", ex.ToString());
            }
            return obj;
        }

        //public static void ErrorLog(string sErrMsg, string errorpath)
        //{
        //    var sLogFormat = DateTime.Now.ToShortDateString().ToString() + " " + DateTime.Now.ToLongTimeString().ToString() + " ==> ";

        //    //this variable used to create log filename format "
        //    //for example filename : ErrorLogYYYYMMDD
        //    string sYear = DateTime.Now.Year.ToString();
        //    string sMonth = DateTime.Now.Month.ToString();
        //    string sDay = DateTime.Now.Day.ToString();
        //    var sErrorTime = sYear + sMonth + sDay;

        //    StreamWriter sw = new StreamWriter("C:\\websites\\fishingappdemo.24livehost.com\\wwwroot\\wwwroot\\EmailTemplates\\" + sErrorTime + ".txt", true);
        //    sw.WriteLine(sLogFormat + sErrMsg + "\n\n" + errorpath);
        //    sw.Flush();
        //    sw.Close();
        //}

        public bool CheckSubscriptionAvailability(string UserId)
        {
            //List<GetUserReceiptDetails_Result> lstReceiptDetails = new List<GetUserReceiptDetails_Result>();
            bool IsSubscriptionAvail = true;
            DateTime ExpiryDateDB = DateTime.MinValue;
            int deviceType ;
            string receiptData = string.Empty;
            string password = string.Empty;
            DateTime ExpiryDate = DateTime.MinValue;
            try
            {
                //string sqlQuery = "EXEC [dbo].[GetUserReceiptDetails] @UserId";
                //SqlParameter parameterUserId = new SqlParameter("@UserId", UserId);
                var ReceiptDetails = this.repository.context.InAppReceipt.FirstOrDefault(x=>x.UserId == UserId);
                //lstReceiptDetails = dbContext.GetUserReceiptDetails_Results.FromSqlRaw(sqlQuery, parameterUserId).ToList();
                if (ReceiptDetails != null )
                {
                    ExpiryDateDB = Convert.ToDateTime(ReceiptDetails.ExpiryDate);
                    deviceType = ReceiptDetails.DeviceType;
                    receiptData = ReceiptDetails.Receipt;
                    password = ReceiptDetails.InAppPassword;
                    //if expiry date in database is lower than current date then check receipt validation on apple or play store
                    if (ExpiryDateDB.Date < DateTime.UtcNow.Date)
                    {
                        ReceiptResult objReceipt = new ReceiptResult();
                        objReceipt = GetReceiptData(receiptData, password, deviceType);
                        ExpiryDate = objReceipt.ExpiryDate;

                        //if new expiry date from apple or play store is less than current date then don't allow the users to access the app
                        if (ExpiryDate.Date < DateTime.UtcNow.Date)
                        {
                            IsSubscriptionAvail = false;
                        }
                        if (ExpiryDate != DateTime.MinValue)
                        {
                            //update new expiry date in database
                            var recData = this.repository.context.InAppReceipt.FirstOrDefault(x => x.Id == ReceiptDetails.Id);
                            recData.ExpiryDate = ExpiryDate;
                            this.repository.context.SaveChanges();



                            //string UpdateQuery = "EXEC [dbo].[UpdateReceiptExpiryDate] @UserId,@ExpiryDate";
                            //SqlParameter paramUserId = new SqlParameter("@UserId", UserId);
                            //SqlParameter paramExpiryDate = new SqlParameter("@ExpiryDate", ExpiryDate);
                            //var listObj = dbContext.UpdateReceiptExpiryDate_Results.FromSqlRaw(UpdateQuery, parameterUserId).ToList();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ex.Log();
                //string InputData = string.Format(CultureInfo.InvariantCulture, "UserId: {0}", UserId);
                //ErrorLogBusiness.LogErrorOccured(ReturnMessage.Failed, "CheckSubscriptionAvailability", InputData, ex.Message, ReturnMessage.Failed, 0, "InAppBusiness", ex.ToString());
            }
            return IsSubscriptionAvail;
        }

        /// <summary>
        /// It posts the receipt request to apple or google play and retrieves all the information (expiry date, original purchase date etc.)
        /// </summary>
        /// <param name="receiptData"></param>
        /// <param name="password"></param>
        /// <param name="deviceType"></param>
        private ReceiptResult GetReceiptData(string receiptData, string password, int deviceType)
        {
            ReceiptResult obj = new ReceiptResult();
            if (deviceType == 1) //iOS
            {
                if (!string.IsNullOrEmpty(receiptData))
                {
                    // make sandbox false before going live
                    Receipt receipt = ReceiptVerification.GetReceipt(false, receiptData, password);
                    //Do the actual verification // this makes the https post to itunes verification servers
                    if (ReceiptVerification.IsReceiptValid(receipt))
                    {
                        //split the receipt information
                        if (receipt != null)
                        {
                            obj.OriginalPurchaseDate = Convert.ToDateTime(receipt.OriginalPurchaseDate);
                            obj.ExpiryDate = Convert.ToDateTime(receipt.expires_date);
                            obj.SubscriptionId = receipt.ProductId;
                            obj.TransactionId = receipt.TransactionId;
                        }
                    }
                }
            }
            else if (deviceType == 2) //android
            {
                obj = GetAndroidInAppReceiptDetail(password, receiptData);
            }
            return obj;
        }

        private ReceiptResult GetFreeReceiptData(string receiptData, string password, int deviceType)
        {
            ReceiptResult obj = new ReceiptResult();
            obj.OriginalPurchaseDate = Convert.ToDateTime(DateTime.Now);
            obj.ExpiryDate = Convert.ToDateTime(DateTime.Now.AddYears(1));
            obj.SubscriptionId = "0";
            obj.TransactionId = "0";

            return obj;
        }

        #endregion [InApp Plan Section]
    }
}
