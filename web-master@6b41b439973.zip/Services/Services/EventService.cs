﻿using AutoMapper;
using Data.Entities;
using Data.IRepository;
using Data.Repository.GenericRepository;
using Microsoft.Data.SqlClient;
using Services.Generic;
using Services.IServices;
using Shared.Models;
using Shared.Models.ProcResults;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

namespace Services.Services
{
    public class EventService : GenericService<UserEventsModel, UserEventsEntity>, IEventService
    {
        private readonly IGenericDataRepository<UserEventRequestEntity> _repository;

        public EventService(GenericDataRepository<UserEventsEntity> repo, IMapper mapper,
            IGenericDataRepository<UserEventRequestEntity> repository
            ) : base(repo, mapper)
        {
            _repository = repository;
        }
        public bool Add(UserEventsViewModel items, string UserId)
        {
            try
            {
                if (items.UserId.Count != 0 && items.UserId != null)
                {
                    UserEventsModel userEvents = new UserEventsModel();
                    userEvents.UserId = UserId;
                    userEvents.EventDate = items.EventDate.Date;
                    DateTime dateTime = DateTime.ParseExact(items.EventTime, "HH:mm", CultureInfo.InvariantCulture);
                    userEvents.EventTime = dateTime;//items.EventTime;
                    userEvents.Venue = items.Venue;
                    userEvents.Title = items.Title;
                    userEvents.ProfilePath = items.ProfilePath;
                    userEvents.UserCapsoulesID = items.UserCapsoulesID;
                    var EventId = base.Add_GetId(userEvents);

                    foreach (var user in items.UserId)
                    {
                        //Adding Event Request
                        UserEventRequestEntity requestModel = new UserEventRequestEntity();
                        requestModel.ReceiverUserId = user;
                        requestModel.SenderUserId = UserId;
                        requestModel.UserEventId = Convert.ToInt32(EventId);
                        requestModel.Status = 0;

                        this.repository.context.UserEventRequest.Add(requestModel);
                        this.repository.context.SaveChanges();

                    }
                }

                //var usercap = this.repository.context.CapsoulesShareRequest.FirstOrDefault(e => e.Id == capUserModel.Id);
                //usercap.Status = capUserModel.Status;
                //this.repository.context.SaveChanges();

                return true;
            }
            catch (Exception ex)
            {
                ex.Log();
                return false;
            }
        }
        public bool Update(params UserEventsViewModel[] items)
        {
            try
            {
                UserEventsModel userEvents = new UserEventsModel();

                foreach (var eventModel in items)
                {
                    var usercap = this.repository.context.UserEvents.FirstOrDefault(e => e.Id == eventModel.Id);
                    usercap.EventDate = userEvents.EventDate;
                    usercap.EventTime = userEvents.EventTime;
                    usercap.Venue = userEvents.Venue;
                    usercap.Title = userEvents.Title;
                    usercap.ProfilePath = userEvents.ProfilePath;
                    this.repository.context.SaveChanges();
                }
                return true;
            }
            catch (Exception ex)
            {
                ex.Log();
                return false;
            }
        }

        public IList<GetMyEventList_Result> GetMyEventLst(SearchModel model, string UserId)
        {
            try
            {
                SqlParameter[] sqlParams = { new SqlParameter("@UserId", UserId),
                                         new SqlParameter("@PageNo",model.PageNo ),
                                         new SqlParameter("@PageSize",model.PageSize ),
                                        new SqlParameter("@Search",model.Search)};

                string sql = "EXEC GetMyEventList @UserId,@PageNo,@PageSize,@Search";
                IList<GetMyEventList_Result> lst = new List<GetMyEventList_Result>();
                var result = _repository.SqlQueryAPI<GetMyEventList_Result>(sql, sqlParams);
                if (result != null && result.Count != 0)
                {
                    lst = result.Select(e => new GetMyEventList_Result()
                    {
                        Id = e.Id,
                        Title = e.Title,
                        Venue = e.Venue,
                        EventDate = e.EventDate,
                        EventTime = e.EventTime
                    }).ToList();
                }
                return lst;
            }
            catch (Exception ex)
            {
                ex.Log();
                return new List<GetMyEventList_Result>();
            }
        }


        public IList<GetMyEventList_Result> GetEventLst(SearchModel model, string UserId)
        {
            try
            {
                SqlParameter[] sqlParams = { new SqlParameter("@UserId", UserId),
                                         new SqlParameter("@PageNo",model.PageNo ),
                                         new SqlParameter("@PageSize",model.PageSize ),
                                        new SqlParameter("@Search",model.Search)};

                string sql = "EXEC GetAllEventList @UserId,@PageNo,@PageSize,@Search";
                IList<GetMyEventList_Result> lst = new List<GetMyEventList_Result>();
                var result = _repository.SqlQueryAPI<GetMyEventList_Result>(sql, sqlParams);
                if (result != null && result.Count != 0)
                {
                    lst = result.Select(e => new GetMyEventList_Result()
                    {
                        Id = e.Id,
                        Title = e.Title,
                        Venue = e.Venue,
                        EventDate = e.EventDate,
                        EventTime = e.EventTime
                    }).ToList();
                }
                return lst;
            }
            catch (Exception ex)
            {
                ex.Log();
                return new List<GetMyEventList_Result>();
            }
        }

        public GetEventDetail_Result GetEventDetailById(int Id)
        {
            try
            {
                SqlParameter[] sqlParams = { new SqlParameter("@EveId", Id) };

                string sql = "EXEC GetEventDetailById @EveId";

                IList<GetEventDetail_Result> data = new List<GetEventDetail_Result>();

                var result = _repository.SqlQuery<GetEventDetail_Result>(sql, sqlParams);

                if (result != null && result.Count != 0)
                {

                    data = result.Select(e => new GetEventDetail_Result()
                    {
                        CapId = e.CapId,
                        Title = e.Title,
                        Venue = e.Venue,
                        EventDate = e.EventDate,
                        EventTime = e.EventTime,
                        InvitedUser = e.InvitedUser,
                        ProfilePath = e.ProfilePath
                    }).ToList();

                    var img = this.repository.context.MediaCapsoules.Where(x => x.UserCapsoulesId == data[0].CapId 
                    && x.IsDeleted == false && x.IsActive == true).ToList();
                    if (img.Count != 0)
                    {
                        data[0].medialist = img.Select(e => new MediaFiles()
                        {
                            FilePath = e.FilePath,
                            FileType = e.FileType,
                            CreatedOn = e.CreatedOn.Date,
                            Thumbnail = e.Thumbnail
                           
                        }).ToList();

                    }

                    return data[0];

                }
                else
                {
                    return new GetEventDetail_Result();
                }

            }
            catch (Exception ex)
            {
                ex.Log();
                return new GetEventDetail_Result();
            }
        }
    }
}
