﻿using AutoMapper;
using Data.Entities;
using Data.IRepository;
using Data.Repository.GenericRepository;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using Services.Generic;
using Services.IServices;
using Services.IServices.Identity;
using Shared.Common;
using Shared.Models;
using Shared.Models.ProcResults;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Services.Services
{
    public class CapsoulesConnectionService : GenericService<CapsoulesConnectionModel, CapsoulesConnectionEntityEntity>, ICapsoulesConnectionService
    {
        private readonly IGenericDataRepository<UserCapsoulesEntity> _repository;
        private readonly ISubscriptionService _subscription;
        public CapsoulesConnectionService(GenericDataRepository<CapsoulesConnectionEntityEntity> repo, IMapper mapper
            , IGenericDataRepository<UserCapsoulesEntity> repository,
             ISubscriptionService subscription
            ) : base(repo, mapper)
        {
            _repository = repository;
        }

        public bool Add(CapsoulesConnectionModel usercap)
        {
            try
            {
                //Check  for user availablity to use app (its free or paid user)
                var userAccess = _subscription.IsAppAccessible(usercap.SenderUserId);

                if (userAccess.Message == "Free" && userAccess.IsAccessAllowed == true)
                {
                    //get the count of connection if free user than it can only connect to one cap per per
                    var Count = this.repository.context.CapsoulesConnection.Where
                                                            (e => e.SenderUserId == usercap.SenderUserId
                                                            && e.ReceiverUserId == usercap.ReceiverUserId
                                                            && e.UserCapsoulesId == usercap.UserCapsoulesId && e.IsActive == true
                                                            && e.IsDeleted == false).Count();
                    if (Count >= 1)
                    {
                        return false;
                    }
                    else
                    {
                        return base.Add(usercap);
                    }
                }
                else if (userAccess.Message == "Access" && userAccess.IsAccessAllowed == true)
                {
                    var Connection = this.repository.context.CapsoulesConnection.FirstOrDefault
                                                      (e => e.SenderUserId == usercap.SenderUserId
                                                      && e.ReceiverUserId == usercap.ReceiverUserId
                                                      && e.UserCapsoulesId == usercap.UserCapsoulesId);
                    if (Connection != null)
                    {
                        if (Connection.IsDeleted == true && Connection.IsActive == false)
                        {
                            return base.Add(usercap);
                        }

                    }
                    else
                    {
                        return base.Add(usercap);
                    }
                }
                return false;

            }
            catch (Exception ex)
            {
                ex.Log();
                return false;
            }
        }


        public IList<GetConnectionUserByCap_Result> GetCapConnectedUserByCapId(CapCon cap)
        {
            try
            {
                IList<GetConnectionUserByCap_Result> MyConList = new List<GetConnectionUserByCap_Result>();

                SqlParameter[] sqlParams = { new SqlParameter("@CapId", cap.Id),

                };

                string sql_1 = "EXEC GetConnectionUserByCap @CapId";

                var MyCon = _repository.SqlQueryAPI<GetConnectionUserByCap_Result>(sql_1, sqlParams);

                if (MyCon != null && MyCon.Count > 0)
                {
                    MyConList = MyCon.Select(e => new GetConnectionUserByCap_Result()
                    {
                        Id = e.Id,
                        ConnectionId = e.ConnectionId,
                        Name = e.Name,
                        ProFilePath = e.ProFilePath


                    }).ToList();
                }
                return MyConList;
            }
            catch (Exception ex)
            {
                ex.Log();
                return new List<GetConnectionUserByCap_Result>();
            }
        }

        public bool RemoveConnection(CapCon usercap)
        {
            try
            {
                var Connection = this.repository.context.CapsoulesConnection.FirstOrDefault
                                                (e => e.Id == usercap.Id);
                if (Connection != null)
                {
                    Connection.IsDeleted = true;
                    Connection.IsActive = false;
                    Connection.UpdatedOn = DateTime.UtcNow.GetLocal();
                    this.repository.context.SaveChanges();
                    return true;
                }
                else return false;
            }
            catch (Exception ex)
            {
                ex.Log();
                return false;
            }
        }

    }
}
