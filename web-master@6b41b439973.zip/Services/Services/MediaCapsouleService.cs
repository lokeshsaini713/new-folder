﻿using AutoMapper;
using Data.Entities;
using Data.IRepository;
using Data.Repository.GenericRepository;
using Microsoft.Data.SqlClient;
using Services.Generic;
using Services.IServices;
using Shared.Common;
using Shared.Models;
using Shared.Models.ProcResults;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Services.Services
{
    public class MediaCapsouleService : GenericService<MediaCapsoulesModel, MediaCapsoulesEntity>, IMediaCapsoulesService
    {
        private readonly IGenericProcDataRepository<MediaCapsoulesEntity> _repository;
        private readonly IGenericDataRepository<UserCapsoulesEntity> _userCaprepository;

        public MediaCapsouleService(IGenericDataRepository<MediaCapsoulesEntity> repo, IMapper mapper,
           IGenericDataRepository<UserCapsoulesEntity> userCaprepository,
           IGenericProcDataRepository<MediaCapsoulesEntity> repository
            ) : base(repo, mapper)
        {
            _repository = repository;
            _userCaprepository = userCaprepository;
        }


        CapDetailsWithMedia IMediaCapsoulesService.GetCapDetailsWithMedia(RequestMedia media, string UserId)
        {
            try
            {
                CapDetailsWithMedia capMedia = new CapDetailsWithMedia();
                //Get the user capsoule details

                var usercap = _userCaprepository.GetSingle(media.UserCapId);
                if (usercap != null)
                {
                    capMedia.Createdon = usercap.CreatedOn;
                    capMedia.Title = usercap.Title;
                    capMedia.Description = usercap.Description;
                    capMedia.ProfilePath = usercap.ProfilePath;
                    capMedia.CoverImage = usercap.CoverImage;
                }

                SqlParameter[] sqlParams = { new SqlParameter("@UserId", UserId),
                                        new SqlParameter("@UsercapId",media.UserCapId ),
                                        new SqlParameter("@Type",media.FileType ),
                                        new SqlParameter("@PageNo",media.PageNo),
                                        new SqlParameter("@PageSize", media.PageSize)};

                string sql = "EXEC GetMediaFile @UserId ,@UsercapId, @Type, @PageNo ,@PageSize";

                var Mediafile = _repository.SqlQueryAPI<MediaFiles>(sql, sqlParams);

                if (Mediafile != null && Mediafile.Count > 0)
                {
                    capMedia.MediaFilesList = Mediafile.Select(e => new MediaFiles()
                    {
                        Id = e.Id,
                        FilePath = e.FilePath,
                        FileType = e.FileType,
                        CreatedOn = e.CreatedOn,
                        Thumbnail = e.Thumbnail
                    }).ToList();
                }
                return capMedia;
            }
            catch (Exception ex)
            {
                ex.Log();
                return new CapDetailsWithMedia();

            }
        }

        public bool Remove(Media media)
        {
            try
            {

                var Mediacap = this.repository.context.MediaCapsoules.FirstOrDefault(e => e.Id == media.MediaId);

                if (Mediacap != null)
                {
                    Mediacap.IsDeleted = true;
                    Mediacap.IsActive = false;
                    Mediacap.UpdatedOn = DateTime.UtcNow.GetLocal();
                    this.repository.context.SaveChanges();

                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                ex.Log();
                return false;
            }
        }

    }
}