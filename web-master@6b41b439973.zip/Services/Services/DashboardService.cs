﻿using Data.Entities;
using Data.IRepository;
using Data.Repository.GenericRepository;
using Services.IServices;
using Shared.Models;
using Shared.Models.ProcResults;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Services.Services
{
    public class DashboardService : IDashboardService
    {
        private readonly IGenericDataRepository<SubscriptionsEntity> _repository;

        public DashboardService(IGenericDataRepository<SubscriptionsEntity> repository)
        {
            _repository = repository;
        }
        #region Actions

        public DashBoardModel GetDashBoardData()
        {
            string sql = "EXEC GetDashboardWidgets";

            var result = _repository.SqlQuery<GetDashboardWidgets_Result>(sql);

            DashBoardModel model = new DashBoardModel(result.FirstOrDefault());

            return model;
        }

        #endregion
    }
}
