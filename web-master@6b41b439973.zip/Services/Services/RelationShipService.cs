﻿using AutoMapper;
using Data.Entities;
using Data.IRepository;
using Data.Repository.GenericRepository;
using Services.Generic;
using Services.IServices;
using Shared.Models;
using Shared.Models.ProcResults;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Services.Services
{
    public class RelationShipService : GenericService<RelationShipModel, RelationShipEntity>, IRelationShipService
    {
        //private readonly IGenericProcDataRepository<RelationShipEntity> _repository;

        public RelationShipService(GenericDataRepository<RelationShipEntity> repo, IMapper mapper
            //,IGenericProcDataRepository<RelationShipEntity> repository
            ) : base(repo, mapper)
        {
            //_repository = repository;
        }
        #region Actions



        //public IList<RelationShipModel> GetRelationShipList() 
        //{
           // return base.GetAll() ?? new List<RelationShipModel>();

            //if (result != null && result.Count > 0) 
            //{
            //    lstRelations= mapper.Map<IList<RelationShipModel>>(result);

            //}
            //return lstRelations;
        //}

        #endregion
    }
}
