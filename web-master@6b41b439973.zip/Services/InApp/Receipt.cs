﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Services.InApp
{
    [Serializable()]
    public class Receipt
    {
        #region Constructor

        /// <summary>
        /// Creates the receipt from Apple's Response
        /// </summary>
        /// <param name="receipt"></param>
        public Receipt(string receipt)
        {
            JObject json = JObject.Parse(receipt);
            int status = -1;
            int.TryParse(json["status"].ToString(), out status);
            this.Status = status;
            if (json["status"].ToString() == "0")
            {
                //apple has changed the format of response, instead of last object we will have to use obj itself to fetch the data.
                dynamic objData = JsonConvert.DeserializeObject(json["latest_receipt_info"].ToString());
                //dynamic obj = objData[objData.Length-1];

                this.OriginalTransactionId = objData[0]["original_transaction_id"].ToString();
                this.ProductId = objData[0]["product_id"].ToString().Replace("\"", string.Empty);
                DateTime purchaseDate = DateTime.MinValue;
                if (DateTime.TryParseExact(objData[0]["purchase_date"].ToString().Replace(" Etc/GMT", string.Empty).Replace("\"", string.Empty).Trim(), "yyyy-MM-dd HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out purchaseDate))
                    this.PurchaseDate = purchaseDate;
                DateTime originalPurchaseDate = DateTime.MinValue;
                if (DateTime.TryParseExact(objData[0]["original_purchase_date"].ToString().Replace(" Etc/GMT", string.Empty).Replace("\"", string.Empty).Trim(), "yyyy-MM-dd HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out originalPurchaseDate))
                    this.OriginalPurchaseDate = originalPurchaseDate;

                DateTime expires_date = DateTime.MinValue;
                if (DateTime.TryParseExact(objData[0]["expires_date"].ToString().Replace(" Etc/GMT", string.Empty).Replace("\"", string.Empty).Trim(), "yyyy-MM-dd HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out expires_date))
                    this.expires_date = expires_date;
                this.TransactionId = objData[0]["transaction_id"].ToString().Replace("\"", string.Empty);
            }
        }
        #endregion Constructor

        #region Properties

        public string OriginalTransactionId
        {
            get;
            set;
        }

        public string Bvrs
        {
            get;
            set;
        }

        public string ProductId
        {
            get;
            set;
        }

        public DateTime? PurchaseDate
        {
            get;
            set;
        }



        public string BundleIdentifier
        {
            get;
            set;
        }

        public DateTime? OriginalPurchaseDate
        {
            get;
            set;
        }

        public DateTime? expires_date
        {
            get;
            set;
        }


        public string TransactionId
        {
            get;
            set;
        }

        public int Status
        {
            get;
            set;
        }


        #endregion Properties
    }
}
