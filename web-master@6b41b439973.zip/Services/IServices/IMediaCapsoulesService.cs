﻿using Shared.Models;
using Shared.Models.ProcResults;
using System.Collections.Generic;

namespace Services.IServices
{
   public interface IMediaCapsoulesService : IGenericService<MediaCapsoulesModel>
    {

        CapDetailsWithMedia GetCapDetailsWithMedia(RequestMedia media,string UserId);

        bool Remove(Media media);
    }
}
