﻿using Shared.Models;
using Shared.Models.ProcResults;
using System.Collections.Generic;

namespace Services.IServices
{
    public interface IRelationShipService : IGenericService<RelationShipModel>
    {
        //IList<RelationShipModel> GetRelationShipList();
    }
}