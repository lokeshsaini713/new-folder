﻿using Shared.Models;
using Shared.Models.ProcResults;
using System.Collections.Generic;

namespace Services.IServices
{
    public interface ISubscriptionService : IGenericService<SubscriptionsModel>
    {
        // IList<GetSubscription_Result> GetAllSubscription();
         AppAccessibleReponse IsAppAccessible(string UserId);
         bool SaveUserInAppDetails(InAppReceiptModel data);
        ReceiptResult GetAndroidInAppReceiptDetail(string subscriptionId, string receiptToken);
        bool CheckSubscriptionAvailability(string UserId);

    }
}