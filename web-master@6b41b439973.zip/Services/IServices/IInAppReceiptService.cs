﻿using Shared.Models;
using Shared.Models.ProcResults;
using System;
using System.Collections.Generic;
using System.Text;

namespace Services.IServices
{
    public interface IInAppReceiptService : IGenericService<InAppReceiptModel>
    {
        public bool Add(InAppReceiptModel usercap);
    }
}
