﻿using Shared.Models;
using Shared.Models.ProcResults;
using System;
using System.Collections.Generic;
using System.Text;
namespace Services.IServices
{
    public interface ICapsoulesConnectionService : IGenericService<CapsoulesConnectionModel>
    {
        bool Add(CapsoulesConnectionModel usercap);

        IList<GetConnectionUserByCap_Result> GetCapConnectedUserByCapId(CapCon cap);
        bool RemoveConnection(CapCon usercap);

    }
}
