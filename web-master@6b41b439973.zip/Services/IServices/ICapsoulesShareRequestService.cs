﻿using Shared.Models;
using Shared.Models.ProcResults;
using System;
using System.Collections.Generic;
using System.Text;

namespace Services.IServices
{
  public  interface ICapsoulesShareRequestService : IGenericService<CapsoulesShareRequestModel>
    {
        bool Add(CapsoulesShareRequestModel usercap);

        IList<GetConnectionList_Result> GetConnectionList(SearchModel model,string UserId);

        bool UpdateStatus(params CapsoulesShareRequestViewModel[] items);

        bool RemoveUserConnection(Capsoule cap);
    }
}
