﻿using Shared.Models;
using Shared.Models.API;
using Shared.Models.ProcResults;
using System.Collections.Generic;

namespace Services.IServices
{
    public interface INotifications
    {
        IList<GetNotification_Result> GetNotification(string userId, PaginationModel pg);
        bool SendNotifications();

        bool SaveNotification(SaveNotificationRequestModel saveNotificationRequestModel);
    }
}
