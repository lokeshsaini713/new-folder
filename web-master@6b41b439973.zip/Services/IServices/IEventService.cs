﻿using Shared.Models;
using Shared.Models.ProcResults;
using System.Collections.Generic;

namespace Services.IServices
{
   public interface IEventService : IGenericService<UserEventsModel>
    {
        bool Add(UserEventsViewModel items,string UserId);

        IList<GetMyEventList_Result> GetMyEventLst(SearchModel model, string UserId);
        IList<GetMyEventList_Result> GetEventLst(SearchModel model, string UserId);
        GetEventDetail_Result GetEventDetailById(int Id);
    }
}
