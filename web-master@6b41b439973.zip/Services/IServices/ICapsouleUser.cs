﻿using Shared.Models;
using Shared.Models.ProcResults;
using System.Collections.Generic;


namespace Services.IServices
{
    public interface ICapsouleUser : IGenericService<UserCapsoulesModel>
    {
        bool AddCapsouleUser(UserCapsoulesModel usercap);

        bool Update(params UserCapsoulesViewModel[] items);

        MyWallModel GetMyWallDetail(string Userid);

        IList<GetMyConnection_Result> GetMyConnection(SearchModel PgModel, string UserId);

        bool Remove(Capsoule cap);
    }
}
