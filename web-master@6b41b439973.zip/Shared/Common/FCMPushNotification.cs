﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Shared.Models.API;

namespace Shared.Common
{
    public class FCMPushNotification
    {
        private readonly ConfigurationKeys _configurationKey;
        public FCMPushNotification(IOptions<ConfigurationKeys> configurationKey)
        {
            _configurationKey = configurationKey.Value;
        }
        public void SendNotice(FCMPushNotificationModel fCMPushNotificationModel)
        {
            SendPushNotification(fCMPushNotificationModel.DeviceType, fCMPushNotificationModel.deviceToken, fCMPushNotificationModel.Message, fCMPushNotificationModel.TypeOfMessge, fCMPushNotificationModel.BadgeCount, fCMPushNotificationModel.NotificationTitle, fCMPushNotificationModel.NotificationId);
        }
        public string SendPushNotification(short DeviceType, string deviceToken, string Message, string TypeOfMessge = "", int BadgeCount = 0, string NotificationTitle = "",long NotificationId = 0)
        {
            try
            {
                var applicationID = _configurationKey.applicationID;
                var senderId = _configurationKey.senderId;

                WebRequest tRequest = WebRequest.Create("https://fcm.googleapis.com/fcm/send");
                tRequest.Method = "post";
                tRequest.ContentType = "application/json";
                //var serializer = new JsonConvert.D();
                var json = "";
                // android=1
                // New code
                if (DeviceType == 0)//for android
                {
                    var body = new
                    {
                        to = deviceToken,
                        //collapse_key = "type_a",
                        notification = new
                        {
                            title = TypeOfMessge,
                            body = Message,
                            sound = "default",
                            priority = "high",
                            show_in_foreground = true,
                        },
                        data = new
                        {
                            title = TypeOfMessge,
                            body = Message,
                            //sound = "default",
                            //priority = "high",
                            //show_in_foreground = true,
                            targetScreen = TypeOfMessge,//"detail",
                            //jobid = JobId,
                            //customerid = CustomerId,
                            //repairerid = RepairerId,
                            notificationId = NotificationId,
                            notificationTitle = NotificationTitle,
                            notificationMessage = Message,
                            notificationType = TypeOfMessge

                        },

                        //priority = 10
                    };

                    json = JsonConvert.SerializeObject(body);
                }
                else
                {
                    //ios code
                    var body = new
                    {
                        to = deviceToken,
                        content_available = true,
                        notification = new
                        {
                            title = TypeOfMessge,
                            body = Message,
                            sound = "default",
                            show_in_foreground = true,
                        },
                        data = new
                        {
                            targetScreen = TypeOfMessge,
                            //jobid = JobId,
                            //customerid = CustomerId,
                            //repairerid = RepairerId,
                            notificationId = NotificationId,
                            notificationTitle = NotificationTitle,
                            notificationMessage = Message,
                            notificationType = TypeOfMessge
                        },
                        priority = 10
                    };
                    json = JsonConvert.SerializeObject(body);
                }

                Byte[] byteArray = Encoding.UTF8.GetBytes(json);
                tRequest.Headers.Add(string.Format("Authorization: key={0}", applicationID));
                //tRequest.Headers.Add(string.Format("Sender: id={0}", senderId));
                tRequest.ContentLength = byteArray.Length;
                using (Stream dataStream = tRequest.GetRequestStream())
                {
                    dataStream.Write(byteArray, 0, byteArray.Length);
                    using (WebResponse tResponse = tRequest.GetResponse())
                    {
                        using (Stream dataStreamResponse = tResponse.GetResponseStream())
                        {
                            using (StreamReader tReader = new StreamReader(dataStreamResponse))
                            {
                                String sResponseFromServer = tReader.ReadToEnd();
                                string str = sResponseFromServer;
                                return str;
                            }
                        }
                    }
                }


            }
            catch (Exception ex)
            {
                string str = ex.Message;
                return str;
            }
        }
    }
}
