﻿using Shared.Models.Base;
using System;
using System.ComponentModel.DataAnnotations;

namespace Shared.Models
{
    public class CapsoulesShareRequestModel : BaseModel
    {
       
        public int? UserCapsoulesId { get; set; }
        [MaxLength(256)]
        public string SenderUserId { get; set; }
        
        [MaxLength(256)]
        public string ReceiverUserID { get; set; }

        public int Status { get; set; }
       
    }
    public class CapsoulesShareRequestViewModel 
    {
      
        public int Id { get; set; }

        public string ReceiverUserID { get; set; }

        public int Status { get; set; }


    }
}
