﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shared.Models
{
   public class MyWallModel
    {
        public string Name { get; set; }
        public string UserId { get; set; }
        public string UserImage { get; set; }
        public List<SharedUserCap> sharedUserCapList { get; set; }
        public List<SharedUserCap> UserCapsouleList { get; set; }
    }

    public class SharedUserCap
    {

        public int Id { get; set; }
        public string Title { get; set; }
        public string ProfilePath { get; set; }
        public string Relationship { get; set; }
        public string Description { get; set; }
        public string CoverImage { get; set; }
    }
}
