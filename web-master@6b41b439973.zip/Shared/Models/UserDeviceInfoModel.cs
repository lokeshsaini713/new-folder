﻿using Shared.Models.Base;
using System;

namespace Shared.Models
{
    public class UserDeviceInfoModel : BaseModel
    {
       
     
        public string UserId { get; set; }
       
        public string AuthorizationToken { get; set; }
        public int DeviceType { get; set; }
        public string DeviceToken { get; set; }
      
    }

}
