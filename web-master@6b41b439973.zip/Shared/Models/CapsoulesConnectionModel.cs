﻿using Shared.Common;
using Shared.Models.Base;
using System;
using System.ComponentModel.DataAnnotations;

namespace Shared.Models
{
    public class CapsoulesConnectionModel: BaseModel
    {

        public string SenderUserId { get; set; }
       
        public string ReceiverUserId { get; set; }
        
        public long UserCapsoulesId { get; set; }
    }
    public class CapsoulesConnectionViewModel 
    {

        // public string SenderUserId { get; set; }

        public int Id { get; set; }

        public string ReceiverUserId { get; set; }

        public long UserCapsoulesId { get; set; }
    }

   public class CapCon
    {
        public int Id { get; set; }
    }

}
