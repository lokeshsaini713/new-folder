﻿using Shared.Common;
using Shared.Models.Base;
using Shared.Models.ProcResults;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.Models
{
    public class DashBoardModel 
    {
        public DashBoardModel() { }
        public int TotalUsers { get; set; }
        public int ActiveUsers { get; set; }
        public int DeactiveUsers { get; set; }

        public DashBoardModel(GetDashboardWidgets_Result e) 
        {
            if (e != null) 
            {
                TotalUsers = e.TotalUsers;
                ActiveUsers = e.ActiveUsers;
                DeactiveUsers = e.DeactiveUsers;
            }
        }
    }
}
