﻿using Shared.Common;
using Shared.Models.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Shared.Models
{
    public class UserEventsModel : BaseModel
    {

        public string UserId { get; set; }
        public string Title { get; set; }
        public string ProfilePath { get; set; }
        public string Venue { get; set; }
        public DateTime EventDate { get; set; }
        public DateTime EventTime { get; set; }
        public long UserCapsoulesID { get; set; }
    }
    public class UserEventsViewModel
    {
        public int Id { get; set; }
        public List<string> UserId { get; set; }
        public string Title { get; set; }
        public string ProfilePath { get; set; }
        public string Venue { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime EventDate { get; set; }
       
        //[DataType(DataType.Time)]
        //[DisplayFormat(DataFormatString = "{0:HH:mm}", ApplyFormatInEditMode = true)]
        public string EventTime { get; set; }
        public long UserCapsoulesID { get; set; }

    }

   public class Event
    {
        public int EventId { get; set; }
    }
}
