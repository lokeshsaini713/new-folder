﻿using Shared.Models.Base;
using System;
using System.ComponentModel.DataAnnotations;

namespace Shared.Models
{
    public class RelationShipModel : BaseModel
    {
        [MaxLength(50)]
        public string Title { get; set; }
    }

    public class RelationShipViewModel 
    {
        [MaxLength(50)]
        public string Title { get; set; }
    }

}
