﻿using Shared.Models.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Shared.Models
{
    public class InAppReceiptModel : BaseModel
    {
        public string UserId { get; set; }

        public int SubscriptionId { get; set; }

        public string Receipt { get; set; }

        public DateTime PurchaseDate { get; set; }

        public DateTime ExpiryDate { get; set; }

        public string TransactionId { get; set; }

        public string InAppPassword { get; set; }

        public int DeviceType { get; set; }

    }

    public class InAppReceiptViewModel
    {
        public string UserId { get; set; }

        public int SubscriptionId { get; set; }

        public string Receipt { get; set; }

        public DateTime PurchaseDate { get; set; }

       public DateTime ExpiryDate { get; set; }

        public string TransactionId { get; set; }

        public string InAppPassword { get; set; }

        public int DeviceType { get; set; }
        public string Price { get; set; }

    }

    public class AppAccessibleReponse
    {
        /// <summary>
        /// Gets or sets the message.
        /// </summary>
        /// <value>
        /// The message.
        /// </value>
        public string Message { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is access allowed.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is access allowed; otherwise, <c>false</c>.
        /// </value>
        public bool IsAccessAllowed { get; set; }
    }


    /// <summary>
    /// Receipt Result
    /// </summary>
    public class ReceiptResult
    {
        /// <summary>
        /// Gets or sets the original purchase date.
        /// </summary>
        /// <value>
        /// The original purchase date.
        /// </value>
        public DateTime OriginalPurchaseDate { get; set; }

        /// <summary>
        /// Gets or sets the expiry date.
        /// </summary>
        /// <value>
        /// The expiry date.
        /// </value>
        public DateTime ExpiryDate { get; set; }

        /// <summary>
        /// Gets or sets the product identifier.
        /// </summary>
        /// <value>
        /// The product identifier.
        /// </value>
        public string SubscriptionId { get; set; }

        /// <summary>
        /// Gets or sets the transaction identifier.
        /// </summary>
        /// <value>
        /// The transaction identifier.
        /// </value>
        public string TransactionId { get; set; }
    }
}
