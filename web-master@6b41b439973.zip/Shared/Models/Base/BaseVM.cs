﻿using Shared.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.Models.Base
{
    public abstract class BaseModel
    {
        public long Id { get; set; }
      
        private DateTime? createdOn;
        public DateTime? CreatedOn
        {
            get
            {
                if (createdOn == null || createdOn == DateTime.MinValue)
                {
                    createdOn = DateTime.UtcNow.GetLocal();
                }
                return createdOn.Value;
            }
            set { createdOn = value; }
        }
        private DateTime? updatedOn;
        public DateTime? UpdatedOn
        {
            get
            {
                if (updatedOn == null || updatedOn == DateTime.MinValue)
                {
                    updatedOn = DateTime.UtcNow.GetLocal();
                }
                return updatedOn.Value;
            }
            set { updatedOn = value; }
        }

        private bool? isActive;
        public bool IsActive
        {
            get
            {
                return isActive ?? true;
            }
            set
            {
                isActive = value;
            }
        }

        private bool? isDeleted;
        public bool IsDeleted
        {
            get
            {
                return isDeleted ?? false;
            }
            set
            {
                isDeleted = value;
            }
        }

        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
    }

}
