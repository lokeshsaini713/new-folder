﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shared.Models.ProcResults
{
     public class GetEventDetail_Result
    {
        public int CapId { get; set; }
        public string Title { get; set; }
        public string ProfilePath { get; set; }
        public string Venue { get; set; }
        public string EventDate { get; set; }
        public string EventTime { get; set; }
        public int InvitedUser { get; set; }
        public List<MediaFiles> medialist { get; set; }
    }

    
}
