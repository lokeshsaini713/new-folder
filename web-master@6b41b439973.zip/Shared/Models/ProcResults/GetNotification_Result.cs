﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shared.Models.ProcResults
{
    public class GetNotification_Result
    {
        public string ProFilePath { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string SenderUserId { get; set; }
        public string Description { get; set; }
        public bool IsRead { get; set; }
        public DateTime CreatedOn { get; set; }
    }
}
