﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shared.Models.ProcResults
{
    public class GetMyEventList_Result
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Venue { get; set; }
        public string EventDate { get; set; }
        public string EventTime { get; set; }
    }
}
