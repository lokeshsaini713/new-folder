﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shared.Models.ProcResults
{
    public class CapDetailsWithMedia
    {
        public int Id { get; set; }
        public string ProfilePath { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime Createdon { get; set; }
        public string  CoverImage { get; set; }
        public List<MediaFiles> MediaFilesList { get; set; }
    }
    public class MediaFiles
    {
        public int Id { get; set; }
        public string FilePath { get; set; }
        public int FileType { get; set; }
        public DateTime CreatedOn { get; set; }
        public string Thumbnail { get; set; }
    }
    public class RequestMedia
    {
        public int UserCapId { get; set; }
        public int FileType { get; set; }
        public int PageNo { get; set; }
        public int PageSize { get; set; }
    }
}
