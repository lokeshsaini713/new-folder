﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shared.Models.ProcResults
{
    public class GetDashboardWidgets_Result
    {
        public int TotalUsers { get; set; }
        public int ActiveUsers { get; set; }
        public int DeactiveUsers { get; set; }
    }
}
