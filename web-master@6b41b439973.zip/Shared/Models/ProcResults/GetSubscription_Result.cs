﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shared.Models.ProcResults
{
    public class GetSubscription_Result
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal Amount { get; set; }
        public int AllowImageUpload { get; set; }
        public int AllowVideoUpload { get; set; }
        public bool IsActive { get; set; }
    }
}
