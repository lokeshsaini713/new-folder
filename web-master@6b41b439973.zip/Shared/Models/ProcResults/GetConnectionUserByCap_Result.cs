﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shared.Models.ProcResults
{
   public class GetConnectionUserByCap_Result
    {
        public string Id { get; set; }
        public int ConnectionId { get; set; }
        public string Name { get; set; }
        public string ProFilePath { get; set; }

    }
}