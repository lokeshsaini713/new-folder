﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shared.Models.ProcResults
{
    public class GetNotificationUserList_Result
    {
        public string UserId { get; set; }
        public short DeviceType { get; set; }
        public string DeviceToken { get; set; }
        public string NotificationMessage { get; set; }
    }
}
