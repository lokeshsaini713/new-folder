﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shared.Models.API
{
    public class UserDeviceResponseModel
    {
        public short DeviceType { get; set; }
        public string DeviceToken { get; set; }
    }
}
