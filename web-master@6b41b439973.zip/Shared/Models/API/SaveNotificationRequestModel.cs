﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shared.Models.API
{
    public class SaveNotificationRequestModel
    {
        public string SenderUserId { get; set; }
        public string ReceiverUserId { get; set; }
        public string Description { get; set; }
        public string Title { get; set; }
    }
}
