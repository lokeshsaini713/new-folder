﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shared.Models.API
{
    public class FCMPushNotificationModel
    {
        public short DeviceType { get; set; }
        public string deviceToken { get; set; }
        public string Message { get; set; }
        public string TypeOfMessge { get; set; }
        public int BadgeCount { get; set; }
        public string NotificationTitle { get; set; }
        public long NotificationId { get; set; }
    }
}
