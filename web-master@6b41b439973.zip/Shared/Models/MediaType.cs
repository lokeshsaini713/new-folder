﻿using System.ComponentModel;
using System;
using System.Collections.Generic;
using System.Text;

namespace Shared.Models
{


    public enum MediaType
    {
        [Description("Image")]
        Image = 1,
        [Description("Audio")]
        Audio = 2,
        [Description("Video")]
        Video = 3,
        [Description("Document")]
        Document = 4
    }

}
