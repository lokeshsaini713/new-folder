﻿using Shared.Common;
using Shared.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.Models
{
    public class UserModel :BaseModel
    {
      

        // Summary:
        //     Gets or sets a telephone number for the user.
        public string PhoneNumber { get; set; }
        //
        // Summary:
        //     Gets or sets the normalized email address for this user.
        public string NormalizedEmail { get; set; }
        //
        // Summary:
        //     Gets or sets the email address for this user.
        public string Email { get; set; }
        //
        // Summary:
        //     Gets or sets the normalized user name for this user.
        public string NormalizedUserName { get; set; }
        //
        // Summary:
        //     Gets or sets the user name for this user.
        public string UserName { get; set; }
        //
        // Summary:
        //     Gets or sets the primary key for this user.
       
        

    }


    public class UserDetailModel
    {
        public string Id { get; set; }
     
        //
        // Summary:
        //     Gets or sets the email address for this user.
        public string Email { get; set; }
       
        //
        // Summary:
        //     Gets or sets the user name for this user.
        public string UserName { get; set; }
        //
        // Summary:
        //     Gets or sets the primary key for this user.

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string AboutMe { get; set; }
        public DateTime DOB { get; set; }
        public string ProFilePath { get; set; }

    }

}
