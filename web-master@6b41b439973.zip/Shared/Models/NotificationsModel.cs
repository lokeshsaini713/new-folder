﻿using Shared.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace Shared.Models
{


    public class NotificationsModel
    {

        public int Id { get; set; }
       
        public string SenderUserId { get; set; }
     

      
        public string ReceiverUserId { get; set; }
    

        public string Description { get; set; }

        public bool IsRead { get; set; }
        public DateTime CreatedOn { get; set; }
      
        private DateTime? updatedOn;
        public DateTime UpdatedOn
        {
            get
            {
                if (updatedOn == null || updatedOn == DateTime.MinValue)
                {
                    updatedOn = DateTime.UtcNow.GetLocal();
                }
                return updatedOn.Value;
            }
            set { updatedOn = value; }
        }

       
    }

}
