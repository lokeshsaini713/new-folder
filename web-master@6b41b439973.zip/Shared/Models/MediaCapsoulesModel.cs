﻿using Shared.Common;
using Shared.Models.Base;
using System;
using System.ComponentModel.DataAnnotations;

namespace Shared.Models
{
    public class MediaCapsoulesModel : BaseModel
    {
        [MaxLength(256)]
        public string UserId { get; set; }
        public int UserCapsoulesId { get; set; }
        public string  FilePath { get; set; }
        public int FileType { get; set; }

        [MaxLength(50)]
        public string Title { get; set; }

        public string Thumbnail { get; set; }
    }

    public class MediaCapsoulesViewModel
    {
        [MaxLength(256)]
        public string UserId { get; set; }
        public int UserCapsoulesId { get; set; }
        public string FilePath { get; set; }
        public int FileType { get; set; }

        [MaxLength(50)]
        public string Title { get; set; }
        public string Thumbnail { get; set; }


    }

    public class Media
    {
        public int MediaId { get; set; }

    }
}
