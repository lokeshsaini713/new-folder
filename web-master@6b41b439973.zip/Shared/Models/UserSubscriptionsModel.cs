﻿using Shared.Models.Base;
using System;

namespace Shared.Models
{
    public class UserSubscriptionsModel : BaseModel
    {
       
        public string UserId { get; set; }
        public DateTime PurchaseOn { get; set; }
        public decimal Amount { get; set; }
        public int AllowImageUpload { get; set; }            
        public int AllowVideoUpload { get; set; }
    }

}
