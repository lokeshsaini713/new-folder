﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shared.Models
{
    public class PaginationModel
    {
        public int PageNo { get; set; }
        public int PageSize { get; set; }
    }

    public class SearchModel : PaginationModel
    {
        public string Search { get; set; }
        
    }
}
