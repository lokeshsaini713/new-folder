﻿using Shared.Models.Base;
using System;

namespace Shared.Models
{
    public class UserEventRequestModel : BaseModel
    {
        public long UserEventId { get; set; }
        public string SenderUserId { get; set; }
        public string ReceiverUserId { get; set; }
        public int Status { get; set; }
    }

}
