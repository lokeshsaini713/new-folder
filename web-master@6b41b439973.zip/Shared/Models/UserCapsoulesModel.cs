﻿using Shared.Common;
using Shared.Models.Base;
using System;
using System.ComponentModel.DataAnnotations;

namespace Shared.Models
{
    public class UserCapsoulesModel : BaseModel
    {
        [MaxLength(256)]
        public string UserId { get; set; }
        [MaxLength(30)]
        public string Title { get; set; }
        //public string FirstName { get; set; }
        //[MaxLength(30)]
        //public string LastName { get; set; }
        public int? RelationShipId { get; set; }
        public string RelationshipName { get; set; }
        [MaxLength(500)]
        public string ProfilePath { get; set; }
        //public DateTime? DoB { get; set; }
        [MaxLength(250)]
        public string Description { get; set; }
        public string CoverImage { get; set; }

    }
    public class UserCapsoulesViewModel
    {
       
        public int Id { get; set; }
        [MaxLength(30)]
        public string Title { get; set; }
        //public string FirstName { get; set; }
        //[MaxLength(30)]
        //public string LastName { get; set; }
        public int RelationShipId { get; set; }
        public string RelationshipName { get; set; }

        [MaxLength(500)]
        public string ProfilePath { get; set; }
        public string CoverImage { get; set; }
        //public DateTime? DoB { get; set; }
        [MaxLength(250)]
        public string Description { get; set; }
    }

    public class Capsoule {
        public int CapId { get; set; }
    }
}
