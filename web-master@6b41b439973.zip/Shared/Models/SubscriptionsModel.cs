﻿using Shared.Models.Base;
using System;

namespace Shared.Models
{
    public class SubscriptionsModel : BaseModel
    {
       
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal Amount { get; set; }
        public int AllowImageUpload { get; set; }
        public int AllowVideoUpload { get; set; }
    }

}
