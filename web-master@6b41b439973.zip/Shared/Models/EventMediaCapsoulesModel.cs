﻿using Shared.Models.Base;
using System;

namespace Shared.Models
{
    public class EventMediaCapsoulesModel: BaseModel
    {
        public long UserEventId { get; set; }
        public long MediaCapsoulesId { get; set; }
    }

}
