﻿using Shared.Models.Base;
using System.ComponentModel.DataAnnotations;

namespace Shared.Models
{
    public class MediaCapsouleFilesModel : BaseModel
    {
       
        public long MediaCapsouleID { get; set; }

        public int FileType { get; set; }

        [MaxLength(500)]
        public string FilePath { get; set; }

    }

}
