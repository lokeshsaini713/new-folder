﻿using MemoryCapsoule.Web.Areas.API.Controllers.Base;
using Communication.Mail;
using Data.Entities.Identity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Services.IServices.Identity;
using Shared.Common.Enums;
using Shared.Models.API;
using Shared.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Services.IServices;
using Shared.Models;
using Shared.Models.ProcResults;

namespace MemoryCapsoule.Web.Areas.API.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    /// <seealso cref="MemoryCapsoule.Web.Areas.API.Controllers.Base.BaseAPIController" />
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
    public class CapsouleUserController : BaseAPIController
    {

        private List<string> _errors = new List<string>();
        private readonly JwtTokenSettings _jwtTokenSettings;
        private readonly IUserService _userservice;
        private readonly EmailFunctions _emailFunctions;
        private readonly ICapsouleUser _capsouleUserService;
        private readonly IMediaCapsoulesService _mediaCapsoulesService;
        private readonly ICapsoulesShareRequestService _capShareService;
        private readonly ICapsoulesConnectionService _capConnectionService;
        private readonly INotifications _notificationsService;


        /// <summary>
        /// Initializes a new instance of the <see cref="CapsouleUserController"/> class.
        /// </summary>
        /// <param name="jwtOptions">The JWT options.</param>
        /// <param name="userservice">The userservice.</param>
        /// <param name="emailFunctions">The email functions.</param>
        /// <param name="capsouleUserService">The capsoule user service.</param>
        public CapsouleUserController(IOptions<JwtTokenSettings> jwtOptions, IUserService userservice, EmailFunctions emailFunctions,
            ICapsouleUser capsouleUserService, IMediaCapsoulesService mediaCapsoulesService,
            ICapsoulesShareRequestService capShareService, ICapsoulesConnectionService capConnectionService, INotifications notificationsService)
        {
            _jwtTokenSettings = jwtOptions.Value;
            _userservice = userservice;
            _emailFunctions = emailFunctions;
            _capsouleUserService = capsouleUserService;
            _mediaCapsoulesService = mediaCapsoulesService;
            _capShareService = capShareService;
            _capConnectionService = capConnectionService;
            _notificationsService = notificationsService;
        }
        /// <summary>
        /// Add new capsoule User 
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("AddNewCapsouleUser"), Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
        public async Task<ApiResponses<bool>> AddNewCapsouleUser(UserCapsoulesViewModel capUserModel)
        {
            UserCapsoulesModel usercap = new UserCapsoulesModel();
            usercap.Title = capUserModel.Title;
            // usercap.LastName = capUserModel.LastName;
            usercap.ProfilePath = capUserModel.ProfilePath;
            //usercap.RelationShipId = capUserModel.RelationShipId;
            usercap.Description = capUserModel.Description;
            usercap.CoverImage = capUserModel.CoverImage;
            usercap.RelationshipName = capUserModel.RelationshipName;

            usercap.UserId = UserId;
            var result = _capsouleUserService.AddCapsouleUser(usercap);
            if (result == true)
            {
                return new ApiResponses<bool>(ResponseMsg.Ok, result,_errors, successMsg: "Created Successfully");
            }
            else {
                return new ApiResponses<bool>(ResponseMsg.Error, result, _errors,failureMsg:"Failed to created Capsoule");
            }
            
        }

        /// <summary>
        /// edit new capsoule User 
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("EditNewCapsouleUser"), Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
        public async Task<ApiResponses<bool>> EditNewCapsouleUser(UserCapsoulesViewModel capUserModel)
        {

            return new ApiResponses<bool>(ResponseMsg.Ok, _capsouleUserService.Update(capUserModel), _errors);
        }

        /// <summary>
        /// Remove capsoule User 
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("RemoveCapsoule"), Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
        public async Task<ApiResponses<bool>> RemoveCapsoule(Capsoule capUserModel)
        {

            return new ApiResponses<bool>(ResponseMsg.Ok, _capsouleUserService.Remove(capUserModel), _errors);
        }


        /// <summary>
        /// Add Media Files 
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("AddMediaFiles"), Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
        public async Task<ApiResponses<bool>> AddMediaFiles(MediaCapsoulesViewModel mediaCapsoulesModel)
        {
            MediaCapsoulesModel model = new MediaCapsoulesModel();
            model.Thumbnail = mediaCapsoulesModel.Thumbnail;
            model.Title = mediaCapsoulesModel.Title;
            model.UserCapsoulesId = mediaCapsoulesModel.UserCapsoulesId;
            model.UserId = UserId;
            model.FilePath = mediaCapsoulesModel.FilePath;
            model.FileType = mediaCapsoulesModel.FileType;

            return new ApiResponses<bool>(ResponseMsg.Ok, _mediaCapsoulesService.Add(model), _errors);
        }

        /// <summary>
        /// Remove Media Files 
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("RemoveMediaFiles"), Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
        public async Task<ApiResponses<bool>> RemoveMediaFiles(Media media)
        {
            return new ApiResponses<bool>(ResponseMsg.Ok, _mediaCapsoulesService.Remove(media), _errors);
        }

        /// <summary>
        /// Get capsoule details with media file
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("GetCapsouleWithMedia"), Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
        public async Task<ApiResponses<CapDetailsWithMedia>> GetCapsouleWithMedia(RequestMedia requestMedia)
        {
            return new ApiResponses<CapDetailsWithMedia>(ResponseMsg.Ok, _mediaCapsoulesService.GetCapDetailsWithMedia(requestMedia, UserId), _errors);
        }

        /// <summary>
        /// Get my wall details
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("GetMyWallDetails"), Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
        public async Task<ApiResponses<MyWallModel>> GetMyWallDetails()
        {
            var user = await _userservice.FindByIdAsync(UserId);
            var wallDetails = _capsouleUserService.GetMyWallDetail(UserId);
            wallDetails.UserImage = user.ProFilePath;
            wallDetails.Name = user.FirstName;
            wallDetails.UserId = UserId;
            return new ApiResponses<MyWallModel>(ResponseMsg.Ok, wallDetails, _errors);
        }

        /// <summary>
        /// Get my connections 
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("GetMyConnectionsList"), Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
        public async Task<ApiResponses<IList<GetMyConnection_Result>>> GetMyConnectionsList(SearchModel PgModel)
        {
            return new ApiResponses<IList<GetMyConnection_Result>>(ResponseMsg.Ok, _capsouleUserService.GetMyConnection(PgModel, UserId), _errors);
        }

        /// <summary>
        /// Get  connections List
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("GetConnectionsList"), Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
        public async Task<ApiResponses<IList<GetConnectionList_Result>>> GetConnectionsList(SearchModel PgModel)
        {
            return new ApiResponses<IList<GetConnectionList_Result>>(ResponseMsg.Ok, _capShareService.GetConnectionList(PgModel, UserId), _errors);
        }


        /// <summary>
        /// Send request to user
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("RequestUser"), Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
        public async Task<ApiResponses<bool>> RequestUser(CapsoulesShareRequestViewModel model)
        {

            CapsoulesShareRequestModel capsoulesShare = new CapsoulesShareRequestModel();
            capsoulesShare.SenderUserId = UserId;
            capsoulesShare.ReceiverUserID = model.ReceiverUserID;

            //save and send push notification
            SaveNotificationRequestModel saveNotificationRequestModel = new SaveNotificationRequestModel();
            saveNotificationRequestModel.SenderUserId = UserId;
            saveNotificationRequestModel.ReceiverUserId = model.ReceiverUserID;
            saveNotificationRequestModel.Description = ResponseStatus.YouReceivedRequest;
            saveNotificationRequestModel.Title = ResponseStatus.ReceivedRequest;
            _notificationsService.SaveNotification(saveNotificationRequestModel);

            return new ApiResponses<bool>(ResponseMsg.Ok, _capShareService.Add(capsoulesShare), _errors);
        }


        /// <summary>
        /// Connection Accept/Reject
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("UpdateConnectionStatus"), Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
        public async Task<ApiResponses<bool>> UpdateConnectionStatus(CapsoulesShareRequestViewModel model)
        {
            //save and send push notification
            SaveNotificationRequestModel saveNotificationRequestModel = new SaveNotificationRequestModel();
            saveNotificationRequestModel.SenderUserId = UserId;
            saveNotificationRequestModel.ReceiverUserId = model.ReceiverUserID;
            saveNotificationRequestModel.Description = ResponseStatus.YouRequestAccepted;
            saveNotificationRequestModel.Title = ResponseStatus.RequestAccepted;
            _notificationsService.SaveNotification(saveNotificationRequestModel);
            return new ApiResponses<bool>(ResponseMsg.Ok, _capShareService.UpdateStatus(model), _errors);
        }

        /// <summary>
        /// Share Capsoule
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("ShareCapsoule"), Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
        public async Task<ApiResponses<bool>> ShareCapsoule(CapsoulesConnectionViewModel model)
        {
            CapsoulesConnectionModel ccm = new CapsoulesConnectionModel();
            ccm.ReceiverUserId = model.ReceiverUserId;
            ccm.UserCapsoulesId = model.UserCapsoulesId;
            ccm.SenderUserId = UserId;

            //save and send push notification
            SaveNotificationRequestModel saveNotificationRequestModel = new SaveNotificationRequestModel();
            saveNotificationRequestModel.SenderUserId = UserId;
            saveNotificationRequestModel.ReceiverUserId = model.ReceiverUserId;
            saveNotificationRequestModel.Description = ResponseStatus.ReceivedShareProfile;
            saveNotificationRequestModel.Title = ResponseStatus.ShareProfile;
            _notificationsService.SaveNotification(saveNotificationRequestModel);

            //return new ApiResponses<bool>(ResponseMsg.Ok, _capConnectionService.Add(ccm), _errors);

            var result = _capConnectionService.Add(ccm);

            if (result == true)
            {
                return new ApiResponses<bool>(ResponseMsg.Ok, result, _errors, successMsg: "Capsoule shared successfully");
            }
            else
            {
                return new ApiResponses<bool>(ResponseMsg.Error, result, _errors, failureMsg: "Failed to share capsoule");
            }
        }

        /// <summary>
        /// Remove User Connection 
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("RemoveUserConnection"), Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
        public async Task<ApiResponses<bool>> RemoveUserConnection(Capsoule capUserModel)
        {

            return new ApiResponses<bool>(ResponseMsg.Ok, _capShareService.RemoveUserConnection(capUserModel), _errors);
        }

        /// <summary>
        /// Remove User Connection 
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("RemoveCapConnection"), Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
        public async Task<ApiResponses<bool>> RemoveCapConnection(CapCon capUserModel)
        {

            return new ApiResponses<bool>(ResponseMsg.Ok, _capConnectionService.RemoveConnection(capUserModel), _errors);
        }
        /// <summary>
        /// Get Shared User List by capsouleId
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("GetConnectedUserByCap"), Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
        public async Task<ApiResponses<IList<GetConnectionUserByCap_Result>>> GetConnectedUserByCap(CapCon capUserModel)
        {

            return new ApiResponses<IList<GetConnectionUserByCap_Result>>(ResponseMsg.Ok, _capConnectionService.GetCapConnectedUserByCapId(capUserModel), _errors);
        }

    }
}
