﻿using MemoryCapsoule.Web.Areas.API.Controllers.Base;
using Communication.Mail;
using Data.Entities.Identity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Services.IServices.Identity;
using Shared.Common.Enums;
using Shared.Models.API;
using Shared.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Services.IServices;
using Shared.Models;
using Shared.Models.ProcResults;

namespace MemoryCapsoule.Web.Areas.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
    public class EventController : BaseAPIController
    {
        private List<string> _errors = new List<string>();
        private readonly JwtTokenSettings _jwtTokenSettings;
        private readonly IUserService _userservice;
        private readonly EmailFunctions _emailFunctions;
        private readonly IEventService _eventUserService;
        private readonly INotifications _notificationsService;
        /// <summary>
        /// Initializes a new instance of the <see cref="CapsouleUserController"/> class.
        /// </summary>
        /// <param name="jwtOptions">The JWT options.</param>
        /// <param name="userservice">The userservice.</param>
        /// <param name="emailFunctions">The email functions.</param>
        public EventController(IOptions<JwtTokenSettings> jwtOptions, IUserService userservice, 
            EmailFunctions emailFunctions,IEventService eventService, INotifications notificationsService
            )
        {
            _jwtTokenSettings = jwtOptions.Value;
            _userservice = userservice;
            _emailFunctions = emailFunctions;
            _eventUserService = eventService;
            _notificationsService = notificationsService;
        }

        /// <summary>
        /// Add new event 
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("AddNewEvent"), Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
        public async Task<ApiResponses<bool>> AddNewEvent(UserEventsViewModel userEventModel)
        {
            //UserEventsModel userEvents = new UserEventsModel();
            //userEvents.UserId = UserId;
            //userEvents.EventDate = userEventModel.EventDate;
            //userEvents.EventTime = userEventModel.EventTime;
            //userEvents.Venue = userEventModel.Venue;
            //userEvents.Title = userEventModel.Title;
            //userEvents.ProfilePath = userEventModel.ProfilePath;
            //userEvents.UserCapsoulesID = userEventModel.UserCapsoulesID;
            foreach (var user in userEventModel.UserId)
            {
                //save and send push notification
                SaveNotificationRequestModel saveNotificationRequestModel = new SaveNotificationRequestModel();
                saveNotificationRequestModel.SenderUserId = UserId;
                saveNotificationRequestModel.ReceiverUserId = user;
                saveNotificationRequestModel.Description = ResponseStatus.NewEvenetAdded;
                saveNotificationRequestModel.Title = ResponseStatus.NewEvent;
                _notificationsService.SaveNotification(saveNotificationRequestModel);
            }
            return new ApiResponses<bool>(ResponseMsg.Ok, _eventUserService.Add(userEventModel,UserId), _errors);
        }

        /// <summary>
        /// Get Event Details
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("GetEventDetails"), Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
        public async Task<ApiResponses<GetEventDetail_Result>> GetEventDetails(Event eve)
        {
            return new ApiResponses<GetEventDetail_Result>(ResponseMsg.Ok, _eventUserService.GetEventDetailById(eve.EventId), _errors);
        }


        /// <summary>
        /// Update event 
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("UpdateEvent"), Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
        public async Task<ApiResponses<bool>> UpdateEvent(UserEventsViewModel userEventModel)
        {
            //UserEventsModel userEvents = new UserEventsModel();
            //userEvents.UserId = UserId;
            //userEvents.EventDate = userEventModel.EventDate;
            //userEvents.EventTime = userEventModel.EventTime;
            //userEvents.Venue = userEventModel.Venue;
            //userEvents.Title = userEventModel.Title;
            //userEvents.ProfilePath = userEventModel.ProfilePath;
            //userEvents.UserCapsoulesID = userEventModel.UserCapsoulesID;
            return new ApiResponses<bool>(ResponseMsg.Ok, _eventUserService.Add(userEventModel,UserId), _errors);
        }

        /// <summary>
        ///Get My Event List 
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("GetMyEventList"), Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
        public async Task<ApiResponses<IList<GetMyEventList_Result>>> GetMyEventList(SearchModel Model)
        {
            return new ApiResponses<IList<GetMyEventList_Result>>(ResponseMsg.Ok, _eventUserService.GetMyEventLst(Model, UserId), _errors);
        }

        /// <summary>
        ///Get  Event List 
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("GetEventList"), Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
        public async Task<ApiResponses<IList<GetMyEventList_Result>>> GetEventList(SearchModel Model)
        {
            return new ApiResponses<IList<GetMyEventList_Result>>(ResponseMsg.Ok, _eventUserService.GetEventLst(Model, UserId), _errors);
        }

    }
}
