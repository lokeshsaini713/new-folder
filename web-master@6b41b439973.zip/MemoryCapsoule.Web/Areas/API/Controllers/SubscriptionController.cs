﻿using MemoryCapsoule.Web.Areas.API.Controllers.Base;
using Communication.Mail;
using Data.Entities.Identity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Services.IServices.Identity;
using Shared.Common.Enums;
using Shared.Models.API;
using Shared.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Services.IServices;
using Shared.Models.ProcResults;
using Shared.Models;

namespace MemoryCapsoule.Web.Areas.API.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
    public class SubscriptionController : BaseAPIController
    {
        private List<string> _errors = new List<string>();
        private readonly JwtTokenSettings _jwtTokenSettings;
        private readonly IUserService _userservice;
        private readonly EmailFunctions _emailFunctions;
        private readonly ISubscriptionService _subscriptionService;
        private readonly IInAppReceiptService _inAppService;


        /// <summary>
        /// Initialized services
        /// </summary>
        /// <param name="jwtOptions"></param>
        /// <param name="userservice"></param>
        /// <param name="emailFunctions"></param>
        /// <param name="subscriptionService"></param>
        public SubscriptionController(IOptions<JwtTokenSettings> jwtOptions, IUserService userservice, EmailFunctions emailFunctions,
            ISubscriptionService subscriptionService, IInAppReceiptService inAppService)
        {
            _jwtTokenSettings = jwtOptions.Value;
            _userservice = userservice;
            _emailFunctions = emailFunctions;
            _subscriptionService = subscriptionService;
            _inAppService = inAppService;
        }

        /// <summary>
        /// Get subscription plans
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("GetSubscriptionList"), Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
        public async Task<ApiResponses<IList<SubscriptionsModel>>> GetSubscriptionList()
        {
            return new ApiResponses<IList<SubscriptionsModel>>(ResponseMsg.Ok, _subscriptionService.GetAll(), _errors);
        }

        /// <summary>
        /// Get subscription plans
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("IsAppAccessible"), Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
        public async Task<ApiResponses<AppAccessibleReponse>> IsAppAccessible()
        {
            return new ApiResponses<AppAccessibleReponse>(ResponseMsg.Ok, _subscriptionService.IsAppAccessible(UserId), _errors);
        }

        /// <summary>
        /// InApp Purchase
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("PurchaseApp"), Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
        public async Task<ApiResponses<bool>> PurchaseApp(InAppReceiptViewModel model)
        {
            InAppReceiptModel appPurchase = new InAppReceiptModel();
            appPurchase.InAppPassword = "a996e5667b204941ba46476fb52d68f1";
            appPurchase.PurchaseDate = model.PurchaseDate;
            appPurchase.UserId = UserId;
            appPurchase.SubscriptionId = model.SubscriptionId;
            appPurchase.Receipt = model.Receipt;
            appPurchase.PurchaseDate = model.PurchaseDate;
            appPurchase.ExpiryDate = model.ExpiryDate.AddMonths(1);
            appPurchase.TransactionId = model.TransactionId;
            appPurchase.DeviceType = model.DeviceType;
            if (model.Price=="0.9") {
                appPurchase.ExpiryDate = model.ExpiryDate.AddDays(30);
            }
            else {
                appPurchase.ExpiryDate = model.ExpiryDate.AddYears(1);
            }
            return new ApiResponses<bool>(ResponseMsg.Ok, _subscriptionService.SaveUserInAppDetails(appPurchase), _errors);
        }
    }
}
