﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using MemoryCapsoule.Web.Areas.API.Controllers.Base;
using Communication.Mail;
using Data.Entities.Identity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.EntityFrameworkCore.Internal;
using Microsoft.Extensions.Options;
using PlantM.Web.Common;
using Services.IServices.Identity;
using Services.Services;
using Shared.Common;
using Shared.Common.Enums;
using Shared.Models;
using Shared.Models.API;
using Shared.Models.Base;
using AutoMapper;
using Shared.Models.ProcResults;

namespace MemoryCapsoule.Web.Areas.API.Controllers
{
    /// <summary>
    /// User account controller
    /// This controller will contains all method related to user login,signup,change password.
    /// </summary>

    [ApiController]
    [Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
    [Route("api/[controller]")]
    public class UserAccountController : BaseAPIController
    {
        #region [ Variables & Ctrs]

        private List<string> _errors = new List<string>();
        private readonly JwtTokenSettings jwtTokenSettings;
        private readonly ISignInService signInService;
        private readonly IUserService userservice;
        private readonly EmailFunctions _emailFunctions;
        private readonly IMapper _mapper;

        /// <summary>
        /// Initialize connstructor
        /// </summary>
        /// <param name="jwtOptions"></param>
        /// <param name="signInService"></param>
        /// <param name="userservice"></param>
        /// <param name="emailFunctions"></param>
        /// <param name="mapper"></param>

        public UserAccountController(IOptions<JwtTokenSettings> jwtOptions, ISignInService signInService,
            IUserService userservice, EmailFunctions emailFunctions, IMapper mapper)
        {
            this.signInService = signInService;
            this.jwtTokenSettings = jwtOptions.Value;
            this.userservice = userservice;
            _emailFunctions = emailFunctions;
            _mapper = mapper;
        }

        #endregion [ Variables & Ctrs]

        #region [LOGIN AND LOGOUT SECTION]

        /// <summary>
        /// Login user from app
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [Route("Login")]
        [HttpPost, AllowAnonymous]
        public async Task<ApiResponses<LoginResponseModel>> Login([FromBody] UserLoginViewModel request)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var loginModel = await userservice.FindByEmailAsync(request.Email);

                    if (loginModel != null)
                    {
                        if (!loginModel.EmailConfirmed)
                        {
                            return new ApiResponses<LoginResponseModel>(ResponseMsg.Error, null, _errors, failureMsg: ResponseStatus.EmailNotVarified, apiName: "Login");
                        }
                        if (!(await userservice.CheckPasswordAsync(loginModel, request.Password)))
                        {
                            return new ApiResponses<LoginResponseModel>(ResponseMsg.Error, null, _errors, failureMsg: ResponseStatus.InvalidPassword, apiName: "Login");
                        }

                        if (!(loginModel.IsActive))
                        {
                            return new ApiResponses<LoginResponseModel>(ResponseMsg.Error, null, _errors, failureMsg: ResponseStatus.UserAccountInActiveContactAdmin, apiName: "Login");
                        }

                        var userSignInResult = await signInService.PasswordSignInAsync(loginModel, request.Password, true, true);

                        if (userSignInResult.Succeeded)
                        {
                            if (loginModel.IsActive)
                            {
                                JwtTokenBuilder tokenBuilder = new JwtTokenBuilder();

                                var roles = await userservice.GetRolesAsync(loginModel);

                                var token = tokenBuilder.GetToken(jwtTokenSettings, loginModel.Id, roles.FirstOrDefault() ?? UserTypes.Customer.ToDescriptionString());

                                userservice.ManageLoginDeviceInfo(loginModel.Id, request.DeviceType, request.DeviceToken, token.Value);

                                LoginResponseModel responseModel = new LoginResponseModel();

                                responseModel = new LoginResponseModel()
                                {
                                    UserId = loginModel.Id,
                                    AuthorizationToken = token.Value,
                                    TokenExpiredOn = token.ValidTo,
                                    Email = request.Email,
                                    Name = loginModel.UserName,
                                };

                                return new ApiResponses<LoginResponseModel>(ResponseMsg.Ok, responseModel, _errors, successMsg: ResponseStatus.success, apiName: "Login");
                            }
                            else
                            {
                                return new ApiResponses<LoginResponseModel>(ResponseMsg.Error, null, _errors, failureMsg: ResponseStatus.AccountDeactivated, apiName: "Login");

                            }
                        }
                        else
                        {
                            return new ApiResponses<LoginResponseModel>(ResponseMsg.Error, null, _errors, failureMsg: ResponseStatus.InvalidCredentials, apiName: "Login");
                        }
                    }
                    else
                    {
                        return new ApiResponses<LoginResponseModel>(ResponseMsg.Error, null, _errors, failureMsg: ResponseStatus.InvalidEmailCredentials, apiName: "Login");
                    }
                }
                else
                {
                    return new ApiResponses<LoginResponseModel>(ResponseMsg.Error, null, _errors, failureMsg: ValidationErrors(), apiName: "Login");
                }
            }
            catch (Exception ex)
            {

                ex.Log();
                throw;
            }
        }

        /// <summary>
        /// Signup a new user
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [Route("SignUp")]
        [HttpPost, AllowAnonymous]
        public async Task<ApiResponses<LoginResponseModel>> SignUp([FromBody] UserSignUpModel request)
        {
            if (ModelState.IsValid)
            {
                try
                {

                    var userList = await userservice.GetUsersInRoleAsync(ApplicationConstants.Customer);
                    if ((userList.Where(x => x.Email.Trim() == request.Email.Trim()).FirstOrDefault()) == null)
                    {
                        User user = new User();

                        user.Email = request.Email;
                        user.FirstName = request.FirstName;
                        user.LastName = request.LastName;
                        user.UserName = request.UserName;
                        user.DOB = request.DOB;
                        user.EmailConfirmed = true;
                        var result = await userservice.CreateAsync(user, request.Password);

                        if (result.Succeeded)
                        {
                            await userservice.AddToRoleAsync(user, UserTypes.Customer.ToDescriptionString());

                            JwtTokenBuilder tokenBuilder = new JwtTokenBuilder();

                            var token = tokenBuilder.GetToken(jwtTokenSettings, user.Id, UserTypes.Customer.ToDescriptionString());

                            userservice.ManageLoginDeviceInfo(user.Id, request.DeviceType, request.DeviceToken, token.Value);

                            LoginResponseModel responseModel = new LoginResponseModel();

                            responseModel = new LoginResponseModel()
                            {
                                UserId = user.Id,
                                AuthorizationToken = token.Value,
                                TokenExpiredOn = token.ValidTo,
                                Email = request.Email,
                                Name = user.UserName,
                            };

                            return new ApiResponses<LoginResponseModel>(ResponseMsg.Ok, responseModel, _errors, successMsg: ResponseStatus.success, apiName: "SignUp");
                        }
                        else
                        {
                            return new ApiResponses<LoginResponseModel>(ResponseMsg.Error, null, _errors, failureMsg: result.Errors?.Select(e => e.Description)?.FirstOrDefault() ?? ResponseStatus.FailedToCreatePofile, apiName: "SignUp");
                        }
                    }
                    else
                        return new ApiResponses<LoginResponseModel>(ResponseMsg.Error, null, _errors, failureMsg: ResponseStatus.FailedToCreatePofile, apiName: "SignUp");

                }
                catch (Exception ex)
                {
                    ex.Log();
                    return new ApiResponses<LoginResponseModel>(ResponseMsg.Error, null, _errors, failureMsg: ResponseStatus.FailedToCreatePofile, apiName: "SignUp");
                }
            }
            else
            {
                return new ApiResponses<LoginResponseModel>(ResponseMsg.Error, null, _errors, failureMsg: ValidationErrors(), apiName: "SignUp");
            }
        }


        /// <summary>
        /// log out the user
        /// </summary>
        /// <returns></returns>
        [Route("Logout")]
        [HttpPost]
        public async Task<ApiResponses<bool>> Logout()
        {
            if (!string.IsNullOrWhiteSpace(UserId))
            {
                await signInService.SignOutAsync();
                return userservice.Logout(UserId);
            }
            else
                return new ApiResponses<bool>(ResponseMsg.Error, false, _errors, failureMsg: ResponseStatus.InvalidToken, apiName: "Logout");
        }

        /// <summary>
        /// refresh token
        /// </summary>
        /// <returns></returns>
        [Route("RefreshToken")]
        [HttpGet]
        public async Task<ApiResponses<string>> RefreshToken()
        {
            try
            {
                var user = await userservice.FindByIdAsync(UserId);
                if (user == null)
                {
                    return new ApiResponses<string>(ResponseMsg.Error, null, _errors, failureMsg: ResponseStatus.userNotFound, apiName: "RefreshToken");
                }
                else
                {
                    JwtTokenBuilder tokenBuilder = new JwtTokenBuilder();

                    var roles = await userservice.GetRolesAsync(user);
                    var token = tokenBuilder.GetToken(jwtTokenSettings, user.Id, roles.FirstOrDefault() ?? UserTypes.Customer.ToDescriptionString());
                    userservice.UpdateUserToken(UserId, token.Value);
                    return new ApiResponses<string>(ResponseMsg.Ok, token.Value, _errors, successMsg: ResponseStatus.TokenRefershed, apiName: "RefreshToken");
                }
            }
            catch (Exception ex)
            {
                ex.Log();
                return new ApiResponses<string>(ResponseMsg.Error, null, _errors, failureMsg: ValidationErrors(), apiName: "RefreshToken");
            }
        }

        #endregion [LOGIN AND LOGOUT SECTION]

        #region Change Password

        /// <summary>
        /// Change Password
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [Route("ChangePassword")]
        [HttpPost]
        public async Task<ApiResponses<bool>> ChangePassword(ChangePasswordModel model)
        {
            if (!string.IsNullOrWhiteSpace(UserId))
            {
                var user = await userservice.FindByIdAsync(UserId);

                bool isPassCorrect = (await userservice.CheckPasswordAsync(user, model.OldPassword));
                if (isPassCorrect == true)
                {
                    if (model.OldPassword == model.NewPassword)
                    {
                        return new ApiResponses<bool>(ResponseMsg.Error, false, _errors, failureMsg: ResponseStatus.OldPasswordNewPasswordSame, apiName: "ChangePassword");
                    }
                    else
                    {
                        var result = userservice.ChangePasswordAsync(user, model.OldPassword, model.NewPassword);

                        if (result.Result.Succeeded == false)
                        {
                            return new ApiResponses<bool>(ResponseMsg.Error, false, _errors, failureMsg: result.Result.Errors.FirstOrDefault().Description == "Incorrect password." ? "Incorrect old password." : result.Result.Errors.FirstOrDefault()?.Description, apiName: "ChangePassword");
                        }
                        else
                        {
                            return new ApiResponses<bool>(ResponseMsg.Ok, true, _errors, successMsg: ResponseStatus.PasswordChangeSuccess, apiName: "ChangePassword");
                        }
                    }
                }
                else
                {
                    return new ApiResponses<bool>(ResponseMsg.Error, false, _errors, failureMsg: ResponseStatus.WrongOldPassword, apiName: "ChangePassword");
                }
            }
            else
                return new ApiResponses<bool>(ResponseMsg.Error, false, _errors, failureMsg: ResponseStatus.InvalidToken, apiName: "ChangePassword");
        }

        #endregion

        #region User Status

        /// <summary>
        /// update user status
        /// </summary>
        /// <returns></returns>
        [Route("UserStatus")]
        [HttpPost]
        public async Task<ApiResponses<LoginResponseModel>> UserStatus()
        {
            LoginResponseModel responseModel = new LoginResponseModel();
            if (!string.IsNullOrWhiteSpace(UserId))
            {
                var user = await userservice.FindByIdAsync(UserId);
                if (user != null)
                {
                    if (user.IsActive == true)
                    {
                        responseModel = new LoginResponseModel()
                        {
                            UserId = user.Id,
                            Email = user.Email,
                            Name = user.UserName,
                        };
                        return new ApiResponses<LoginResponseModel>(ResponseMsg.Ok, responseModel, _errors, successMsg: ResponseStatus.success, apiName: "UserStatus");
                    }
                    else
                    {
                        return new ApiResponses<LoginResponseModel>(ResponseMsg.Error, null, _errors, failureMsg: ResponseStatus.userNotFound, apiName: "UserStatus");
                    }
                }
                else
                {
                    return new ApiResponses<LoginResponseModel>(ResponseMsg.Error, null, _errors, failureMsg: ResponseStatus.userNotFound, apiName: "UserStatus");
                }
            }
            else
            {
                return new ApiResponses<LoginResponseModel>(ResponseMsg.Error, null, _errors, failureMsg: ResponseStatus.InvalidToken, apiName: "UserStatus");
            }
        }

        #endregion

        #region [FORGOT PASSWORD ]

        /// <summary>
        /// Forget user password
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [Route("ForgotPassword")]
        [HttpPost, AllowAnonymous]
        public async Task<ApiResponses<bool>> ForgotPassword([FromBody] ForgotPassword request)
        {
            TResponse response = new TResponse();
            if (ModelState.IsValid)
            {
                var user = await userservice.FindByEmailAsync(request.EmailID);

                if (user != null && await userservice.IsEmailConfirmedAsync(user))
                {
                    var token = await userservice.GeneratePasswordResetTokenAsync(user);

                    var passwordResetLink = Url.Action("ResetPassword", "Account", new { email = request.EmailID, token = token }, Request.Scheme);
                    _emailFunctions.SendResetPasswordEmail(request.EmailID, "Forgot Password", (string.IsNullOrWhiteSpace(user?.UserName) ? user.NormalizedUserName : user?.UserName), passwordResetLink);

                    await userservice.SaveToken(user.Id, token, false);

                    return new ApiResponses<bool>(ResponseMsg.Ok, true, _errors, successMsg: ResponseStatus.ForgotPasswordSuccess, apiName: "ForgotPassword");
                }
                else
                {
                    return new ApiResponses<bool>(ResponseMsg.Error, false, _errors, failureMsg: ResponseStatus.ForgotPasswordFailed, apiName: "ForgotPassword");
                }
            }
            else
            {
                return new ApiResponses<bool>(ResponseMsg.Error, false, _errors, failureMsg: ValidationErrors(), apiName: "ForgotPassword");
            }
        }

        #endregion [FORGOT PASSWORD ]

        #region Validation error

        private string ValidationErrors()
        {
            return string.Join(", ", ModelState.Values.Where(E => E.Errors.Count > 0).SelectMany(E => E.Errors).Select(E => E.ErrorMessage)).ToString().Trim(',').Trim();
        }

        #endregion


        #region UserList

        /// <summary>
        /// Get all admin users
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("GetCustomerList"), Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
        public async Task<ApiResponses<IList<UserModel>>> GetCustomerList()
        {
            var userInRole = await userservice.GetUsersInRoleAsync(ApplicationConstants.Customer);
            //, IMapper mapper
            var result = _mapper.Map<IList<UserModel>>(userInRole);

            return new ApiResponses<IList<UserModel>>(ResponseMsg.Ok, result, _errors);
        }

        /// <summary>
        /// Get user list with filter by name 
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("GetUserList"), Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
        public async Task<ApiResponses<IList<GetUserList_Result>>> GetUserList(SearchModel search)
        {
            return new ApiResponses<IList<GetUserList_Result>>(ResponseMsg.Ok, userservice.GetUserList(search, UserId), _errors);
        }
        #endregion
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("GetUserDetails"), Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
        public async Task<ApiResponses<UserDetailModel>> GetUserDetails()
        {
            var user = await userservice.GetUserDetails(UserId);
            //, IMapper mapper
            //var result = _mapper.Map<UserDetailModel>(user);
            return new ApiResponses<UserDetailModel>(ResponseMsg.Ok, user, _errors);
        }

        /// <summary>
        /// Edit user profile 
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("EditUserProfile"), Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
        public async Task<ApiResponses<bool>> EditUser(UserDetailModel model)
        {
            return new ApiResponses<bool>(ResponseMsg.Ok, await userservice.UpdateUserProfile(model), _errors);
        }

        /// <summary>
        /// Get User Tag List 
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("GetUserTagList"), Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
        public async Task<ApiResponses<IList<GetMyConnection_Result>>> GetUserTagList()
        {
            return new ApiResponses<IList<GetMyConnection_Result>>(ResponseMsg.Ok, userservice.GetUserTag(UserId), _errors);
        }


    }
}
