﻿using MemoryCapsoule.Web.Areas.API.Controllers.Base;
using Communication.Mail;
using Data.Entities.Identity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Services.IServices.Identity;
using Shared.Common.Enums;
using Shared.Models.API;
using Shared.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Services.IServices;
using Shared.Models.ProcResults;
using Shared.Models;

namespace MemoryCapsoule.Web.Areas.API.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
    public class RelationShipController : BaseAPIController
    {
        private List<string> _errors = new List<string>();
        private readonly JwtTokenSettings _jwtTokenSettings;
     
        private readonly IRelationShipService _relationShipService;

        /// <summary>
        /// Initialized services
        /// </summary>
        /// <param name="jwtOptions"></param>
        /// <param name="relationShipService"></param>

        public RelationShipController(IOptions<JwtTokenSettings> jwtOptions, IRelationShipService relationShipService)
        {
            _jwtTokenSettings = jwtOptions.Value;
            _relationShipService = relationShipService;
        }

        /// <summary>
        /// Get Relationship list
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("GetRelationShipList"), Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
        public async Task<ApiResponses<IList<RelationShipModel>>> GetRelationShipList()
        {
            return new ApiResponses<IList<RelationShipModel>>(ResponseMsg.Ok, _relationShipService.GetAll(), _errors);
        }

        /// <summary>
        /// Add relationship
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("AddRelationShip"), Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
        public async Task<ApiResponses<bool>> AddRelationShip(RelationShipViewModel relation)
        {
            RelationShipModel model = new RelationShipModel();
            model.Title = relation.Title;
            return new ApiResponses<bool>(ResponseMsg.Ok, _relationShipService.Add(model), _errors);
        }
    }
}
