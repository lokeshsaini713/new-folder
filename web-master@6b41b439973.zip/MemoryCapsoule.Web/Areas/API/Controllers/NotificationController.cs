﻿using MemoryCapsoule.Web.Areas.API.Controllers.Base;
using Communication.Mail;
using Data.Entities.Identity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Services.IServices.Identity;
using Shared.Common.Enums;
using Shared.Models.API;
using Shared.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Services.IServices;
using Shared.Models;
using Shared.Models.ProcResults;

namespace MemoryCapsoule.Web.Areas.API.Controllers
{/// <summary>
 /// 
 /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
    public class NotificationController : BaseAPIController
    {
        private List<string> _errors = new List<string>();
        private readonly JwtTokenSettings _jwtTokenSettings;
        private readonly IUserService _userservice;
        private readonly EmailFunctions _emailFunctions;
        private readonly INotifications _notificationService;

        /// <summary>
        /// Initializes a new instance of the <see cref="NotificationController"/> class.
        /// </summary>
        /// <param name="jwtOptions">The JWT options.</param>
        /// <param name="userservice">The userservice.</param>
        /// <param name="emailFunctions">The email functions.</param>
        /// <param name="notificationService">The notification service.</param>
        public NotificationController(IOptions<JwtTokenSettings> jwtOptions, IUserService userservice, EmailFunctions emailFunctions,
            INotifications notificationService)
        {
            _jwtTokenSettings = jwtOptions.Value;
            _userservice = userservice;
            _emailFunctions = emailFunctions;
            _notificationService = notificationService;
        }

        /// <summary>
        /// Get subscription plans
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("GetNotificationList"), Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
        public async Task<ApiResponses<IList<GetNotification_Result>>> GetNotificationList(PaginationModel pg)
        {
            return new ApiResponses<IList<GetNotification_Result>>(ResponseMsg.Ok, _notificationService.GetNotification(UserId,pg), _errors);
        }

        /// <summary>
        /// Send notifications
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("SendNotifications"), Authorize(AuthenticationSchemes = "Bearer", Policy = "AuthorisedUser")]
        public async Task<ApiResponses<bool>> SendNotifications()
        {
            return new ApiResponses<bool>(ResponseMsg.Ok, _notificationService.SendNotifications(), _errors);
        }
    }

}
