﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Services.IServices;
using Shared.Models;

namespace MemoryCapsoule.Web.Areas.Admin.Controllers
{
    /// <summary>
    /// basic management here
    /// </summary>
    [Authorize(Roles = "Admin, Manager")]
    [Area(areaName: "admin")]
    public class HomeController : Controller
    {
        private readonly IDashboardService _dashboardService;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dashboardService"></param>
        public HomeController(IDashboardService dashboardService)
        {
            _dashboardService = dashboardService;
        }

        /// <summary>
        /// view
        /// </summary>
        /// <returns></returns>
        public IActionResult Index()
        {
            DashBoardModel model = _dashboardService.GetDashBoardData();
            return View(model);
        }

        /// <summary>
        /// About us
        /// </summary>
        /// <returns></returns>
        public IActionResult AboutUs()
        {
            return View();
        }

        /// <summary>
        /// Contact us
        /// </summary>
        /// <returns></returns>
        public IActionResult ContactUS()
        {
            return View();
        }
    }
}
