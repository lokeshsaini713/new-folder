﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using MemoryCapsoule.Web.Extensions;
using Data.Entities.Identity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Services.Generic;
using Services.IServices.Identity;
using Shared.Models;
using Shared.Common;

namespace MemoryCapsoule.Web.Areas.Admin.Controllers
{
    /// <summary>
    /// Role management controller
    /// </summary>
    [Authorize(Roles = "Admin")]
    [Area(areaName: "admin")]
    public class CustomerController : Controller
    {
        private readonly IUserService _userManager;


        //var roleStore = new RoleStore<IdentityRole>(context);
        //var roleMngr = new RoleManager<IdentityRole>(roleStore);

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="userManager"></param>

        public CustomerController(IUserService userManager)
        {
            _userManager = userManager;

        }

        /// <summary>
        /// View roles
        /// </summary>
        /// <returns></returns>
        public async Task<IActionResult> Customer()
        {
            List<User> result = (await _userManager.GetUsersInRoleAsync(ApplicationConstants.Customer)).ToList();
            return View(result);
        }
        public async Task<IActionResult> GetUserList()
        {
            List<User> result = (await _userManager.GetUsersInRoleAsync(ApplicationConstants.Customer)).ToList();
            return View(result);
        }

        /// <summary>
        /// View roles
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> StatusUpdate(string customerId)
        {
            if (!string.IsNullOrEmpty(customerId))
                return Json(await _userManager.UpdateStatusAsync(customerId));
            else
                return Json(false);
        }

    }
}
