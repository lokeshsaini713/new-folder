﻿using Shared.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Entities.Base
{
    public abstract class BaseEntity
    {
        public BaseEntity()
        {
            CreatedOn = CreatedOn;
            UpdatedOn = UpdatedOn;
            IsActive = IsActive;
            IsDeleted = IsDeleted;
        }
        [Key]
        public int Id { get; set; }

        private DateTime? createdOn;
        public DateTime CreatedOn
        {
            get
            {
                if (createdOn == null || createdOn == DateTime.MinValue)
                {
                    createdOn = DateTime.UtcNow.GetLocal();
                }
                return createdOn.Value;
            }
            set { createdOn = value; }
        }
        private DateTime? updatedOn;
        public DateTime UpdatedOn
        {
            get
            {
                if (updatedOn == null || updatedOn == DateTime.MinValue)
                {
                    updatedOn = DateTime.UtcNow.GetLocal();
                }
                return updatedOn.Value;
            }
            set { updatedOn = value; }
        }

        private bool? isActive;
        public bool IsActive
        {
            get
            {
                if (isActive == null)
                {
                    isActive = true;
                }
                return isActive.Value;
            }
            set
            {
                isActive = value;
            }
        }

        private bool? isDeleted;
        public bool IsDeleted
        {
            get
            {
                if (isDeleted == null)
                {
                    isDeleted = false;
                }
                return isDeleted.Value;
            }
            set
            {
                isDeleted = value;
            }
        }

    }
}
