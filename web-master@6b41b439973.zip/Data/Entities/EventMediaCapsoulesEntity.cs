﻿using Data.Entities.Base;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Data.Entities
{
    //[Table("EventMediaCapsoules")]
    //public class EventMediaCapsoulesEntity : BaseEntity
    //{
    //    //public long Id { get; set; }

    //    [ForeignKey("UserEvent")]
    //    public long UserEventId { get; set; }
    //    public UserEventsEntity UserEvent { get; set; }

    //    [ForeignKey("MediaCapsoule")]
    //    public long MediaCapsoulesId { get; set; }
    //    public MediaCapsoulesEntity MediaCapsoule { get; set; }

    //    public bool? IsDeleted { get; set; }
    //    public DateTime CreatedOn { get; set; }
    //}

}
