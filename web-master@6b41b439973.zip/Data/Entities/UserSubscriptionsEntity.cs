﻿using Data.Entities.Base;
using Data.Entities.Identity;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Data.Entities
{
    [Table("UserSubscriptions")]
    public class UserSubscriptionsEntity : BaseEntity
    {

        //public int Id { get; set; }
        [ForeignKey("User")]
        public string UserId { get; set; }
        public User User { get; set; }
        public DateTime PurchaseOn { get; set; }
        //[DataType("smallmoney")]
        [Column(TypeName = "decimal(18,2)")]
        public decimal Amount { get; set; }
        public int AllowImageUpload { get; set; }
        public int AllowVideoUpload { get; set; }
    }

}
