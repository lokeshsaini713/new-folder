﻿using Data.Entities.Base;
using Data.Entities.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Data.Entities
{
    [Table("UserCapsoules")]
    public class UserCapsoulesEntity : BaseEntity
    {
        //public int Id { get; set; }
       
        [ForeignKey("User")]
        //[MaxLength(256)]
        public string UserId { get; set; }
        public User User { get; set; }

        //[MaxLength(30)]
        //public string FirstName { get; set; }
        //[MaxLength(30)]
        //public string LastName { get; set; }

        [MaxLength(200)]
        public string Title { get; set; }

        
        public int? RelationShipId { get; set; }

        public string RelationshipName { get; set; }

        public RelationShipEntity RelationShip { get; set; }

        [MaxLength(500)]
        public string ProfilePath { get; set; }
        //public DateTime? DoB { get; set; }

        [MaxLength(250)]
        public string Description { get; set; }
        public string CoverImage { get; set; }
    }
}
