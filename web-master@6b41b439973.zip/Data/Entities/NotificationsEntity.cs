﻿using Data.Entities.Base;
using Data.Entities.Identity;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Data.Entities
{
    [Table("Notifications")]
    public class NotificationsEntity : BaseEntity
    {

        //public long Id { get; set; }
        [ForeignKey("User")]
        public string SenderUserId { get; set; }
        public User SenderUser { get; set; }

        [ForeignKey("User")]
        public string ReceiverUserId { get; set; }
        public User ReceiverUser { get; set; }
        [MaxLength(250)]
        public string Description { get; set; }

        public bool IsRead { get; set; }
    }

}
