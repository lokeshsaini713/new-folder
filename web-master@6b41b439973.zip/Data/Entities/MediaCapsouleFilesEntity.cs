﻿using Data.Entities.Base;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Data.Entities
{
    //[Table("MediaCapsouleFiles")]
    //public class MediaCapsouleFilesEntity : BaseEntity
    //{
    //    //public long Id { get; set; }

    //    [ForeignKey("MediaCapsoule")]
    //    public long MediaCapsouleID { get; set; }
    //    public MediaCapsoulesEntity MediaCapsoule { get; set; }

    //    public int FileType { get; set; }

    //    [MaxLength(500)]
    //    public string FilePath { get; set; }

    //}

}
