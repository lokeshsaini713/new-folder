﻿using Data.Entities.Base;
using Data.Entities.Identity;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Data.Entities
{
    [Table("UserEvents")]
    public class UserEventsEntity : BaseEntity
    {
        //public long Id { get; set; }

        [ForeignKey("User")]
        public string UserId { get; set; }
        public User User { get; set; }

        [MaxLength(50)]
        public string Title { get; set; }
        [MaxLength(500)]
        public string ProfilePath { get; set; }

        [MaxLength(100)]
        public string Venue { get; set; }
        public DateTime EventDate { get; set; }
        public DateTime EventTime { get; set; }

        [ForeignKey("UserCapsoule")]
        public int UserCapsoulesID { get; set; }
        public UserCapsoulesEntity UserCapsoule { get; set; }
    }

}
