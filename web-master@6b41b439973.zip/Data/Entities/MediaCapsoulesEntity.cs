﻿using Data.Entities.Base;
using Data.Entities.Identity;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Data.Entities
{
    [Table("MediaCapsoules")]
    public class MediaCapsoulesEntity : BaseEntity
    {
        //public long Id { get; set; }
        [ForeignKey("User")]

        //[MaxLength(256)]
        public string UserId { get; set; }
        public User User { get; set; }

        [ForeignKey("UserCapsoule")]
        public int UserCapsoulesId { get; set; }
        public UserCapsoulesEntity UserCapsoule { get; set; }

        public int FileType { get; set; }

        [MaxLength(500)]
        public string FilePath { get; set; }
        public string Thumbnail { get; set; }

    }

}
