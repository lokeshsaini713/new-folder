﻿using Data.Entities.Base;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Data.Entities
{
    [Table("InAppReceipt")]
    public class InAppReceiptEntity : BaseEntity
    {

        public string UserId { get; set; }

        public int SubscriptionId { get; set; }

        public string  Receipt { get; set; }

        public DateTime  PurchaseDate { get; set; }
        public DateTime  ExpiryDate { get; set; }

        public string TransactionId { get; set; }

        public string InAppPassword { get; set; }

        public int DeviceType { get; set; }
    }
}
