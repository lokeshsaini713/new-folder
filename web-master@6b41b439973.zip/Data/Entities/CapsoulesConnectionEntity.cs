﻿using Data.Entities.Base;
using Data.Entities.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Data.Entities
{
    [Table("CapsoulesConnection")]
    public class CapsoulesConnectionEntityEntity : BaseEntity
    {
        [ForeignKey("User")]
        public string SenderUserId { get; set; }
        public User SenderUser { get; set; }

        [ForeignKey("User")]
        public string ReceiverUserId { get; set; }
        public User ReceiverUser { get; set; }

        [ForeignKey("UserCapsoule")]
        public int UserCapsoulesId { get; set; }
        public UserCapsoulesEntity UserCapsoule { get; set;}
    }


   
    
}
