﻿using Data.Entities.Base;
using Data.Entities.Identity;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Data.Entities
{
    [Table("UserDeviceInfo")]
    public class UserDeviceInfoEntity : BaseEntity
    {
        //public long Id { get; set; }
        [ForeignKey("User")]
        public string UserId { get; set; }
        public User User { get; set; }

        [MaxLength(256)]
        public string AuthorizationToken { get; set; }
        public int DeviceType { get; set; }

        [MaxLength(256)]
        public string DeviceToken { get; set; }
    }

}
