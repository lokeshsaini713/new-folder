﻿using Data.Entities.Base;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Data.Entities
{
    [Table("Subscriptions")]
    public class SubscriptionsEntity : BaseEntity
    {
        //public int Id { get; set; } 

        [MaxLength(30)]
        public string Name { get; set; }
        [MaxLength(250)]
        public string Description { get; set; }
        //[DataType("smallmoney")]
        [Column(TypeName = "decimal(18,2)")]
        public decimal Amount { get; set; }
        public int NoOfCap { get; set; }
        public int NoOfUserShared { get; set; }
        public DateTime CreatedDate { get; set; }
    }

}
