﻿using Data.Entities.Base;
using Data.Entities.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Data.Entities
{
    [Table("CapsoulesShareRequest")]
    public class CapsoulesShareRequestEntity : BaseEntity
    {
        //public int Id { get; set; }

        [ForeignKey("UserCapsoule")]
        public int? UserCapsoulesId { get; set; }
        public UserCapsoulesEntity UserCapsoule { get; set; }

        [ForeignKey("SenderUser")]
        //[MaxLength(256)]
        public string SenderUserId { get; set; }
        public User SenderUser { get; set; }

        [ForeignKey("ReceiverUser")]
        //[MaxLength(256)]
        public string ReceiverUserID { get; set; }
        public User ReceiverUser { get; set; }

        public int Status { get; set; }
    }

}
