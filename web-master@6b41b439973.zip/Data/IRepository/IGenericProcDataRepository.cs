﻿using Data.Entities.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Data.IRepository
{
    public interface IGenericProcDataRepository<T>  where T : class
    {
        IList<E> SqlQuery<E>(string sql, params object[] parameters) where E : class;
        IList<E> SqlQueryAPI<E>(string sql, params object[] parameters) where E : class;
    }
}
