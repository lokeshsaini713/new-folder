﻿using Data.Context;
using Data.Entities.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Data.IRepository
{
    public interface IGenericDataRepository<T> where T : BaseEntity
    {
        DataContext context { get; }

        IList<T> GetAll(params Expression<Func<T, object>>[] navigationProperties);
        IList<T> GetList(Func<T, bool> where, params Expression<Func<T, object>>[] navigationProperties);
        T GetSingle(long id, params Expression<Func<T, object>>[] navigationProperties);
        T GetSingle(Func<T, bool> where, params Expression<Func<T, object>>[] navigationProperties);
        bool Add(params T[] items);
        long Add_GetId(T[] item);
        bool Update(params T[] items);
        bool Remove(params T[] items);
        bool Remove(long Id);
        bool ChangeStatus(long id);
        IList<T> GetAllWitnInActive(params Expression<Func<T, object>>[] navigationProperties);

        IList<E> SqlQuery<E>(string sql, params object[] parameters) where E : class;
        IList<E> SqlQueryAPI<E>(string sql, params object[] parameters) where E : class;
    }
}
