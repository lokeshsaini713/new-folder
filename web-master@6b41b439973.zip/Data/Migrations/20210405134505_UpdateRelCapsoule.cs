﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Data.Migrations
{
    public partial class UpdateRelCapsoule : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_UserCapsoules_RelationShip_RelationShipId",
                table: "UserCapsoules");

            migrationBuilder.AlterColumn<int>(
                name: "RelationShipId",
                table: "UserCapsoules",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddColumn<string>(
                name: "RelationshipName",
                table: "UserCapsoules",
                nullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_UserCapsoules_RelationShip_RelationShipId",
                table: "UserCapsoules",
                column: "RelationShipId",
                principalTable: "RelationShip",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_UserCapsoules_RelationShip_RelationShipId",
                table: "UserCapsoules");

            migrationBuilder.DropColumn(
                name: "RelationshipName",
                table: "UserCapsoules");

            migrationBuilder.AlterColumn<int>(
                name: "RelationShipId",
                table: "UserCapsoules",
                type: "int",
                nullable: false,
                oldClrType: typeof(int),
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_UserCapsoules_RelationShip_RelationShipId",
                table: "UserCapsoules",
                column: "RelationShipId",
                principalTable: "RelationShip",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
