﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Data.Migrations.AppIdentity
{
    public partial class UpdateEntity : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            //migrationBuilder.DropColumn(
            //    name: "CreatedBy",
            //    table: "RoleActions");

            //migrationBuilder.DropColumn(
            //    name: "CreatedDate",
            //    table: "RoleActions");

            //migrationBuilder.DropColumn(
            //    name: "ModifiedBy",
            //    table: "RoleActions");

            //migrationBuilder.DropColumn(
            //    name: "ModifiedDate",
            //    table: "RoleActions");

            //migrationBuilder.AlterColumn<int>(
            //    name: "Id",
            //    table: "RoleActions",
            //    nullable: false,
            //    oldClrType: typeof(long),
            //    oldType: "bigint")
            //    .Annotation("SqlServer:Identity", "1, 1")
            //    .OldAnnotation("SqlServer:Identity", "1, 1");

            //migrationBuilder.AddColumn<DateTime>(
            //    name: "CreatedOn",
            //    table: "RoleActions",
            //    nullable: false,
            //    defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            //migrationBuilder.AddColumn<DateTime>(
            //    name: "UpdatedOn",
            //    table: "RoleActions",
            //    nullable: false,
            //    defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CreatedOn",
                table: "RoleActions");

            migrationBuilder.DropColumn(
                name: "UpdatedOn",
                table: "RoleActions");

            migrationBuilder.AlterColumn<long>(
                name: "Id",
                table: "RoleActions",
                type: "bigint",
                nullable: false,
                oldClrType: typeof(int))
                .Annotation("SqlServer:Identity", "1, 1")
                .OldAnnotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AddColumn<string>(
                name: "CreatedBy",
                table: "RoleActions",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedDate",
                table: "RoleActions",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "ModifiedBy",
                table: "RoleActions",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedDate",
                table: "RoleActions",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));
        }
    }
}
