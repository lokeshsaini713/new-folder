﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Data.Migrations
{
    public partial class updateinappreceipt : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Recipt",
                table: "InAppReceipt");

            migrationBuilder.AddColumn<string>(
                name: "Receipt",
                table: "InAppReceipt",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Receipt",
                table: "InAppReceipt");

            migrationBuilder.AddColumn<string>(
                name: "Recipt",
                table: "InAppReceipt",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
