﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Data.Migrations
{
    public partial class updateForeignKey : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CapsoulesShareRequest_UserCapsoules_UserCapsoulesId",
                table: "CapsoulesShareRequest");

            migrationBuilder.AlterColumn<int>(
                name: "UserCapsoulesId",
                table: "CapsoulesShareRequest",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddForeignKey(
                name: "FK_CapsoulesShareRequest_UserCapsoules_UserCapsoulesId",
                table: "CapsoulesShareRequest",
                column: "UserCapsoulesId",
                principalTable: "UserCapsoules",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CapsoulesShareRequest_UserCapsoules_UserCapsoulesId",
                table: "CapsoulesShareRequest");

            migrationBuilder.AlterColumn<int>(
                name: "UserCapsoulesId",
                table: "CapsoulesShareRequest",
                type: "int",
                nullable: false,
                oldClrType: typeof(int),
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_CapsoulesShareRequest_UserCapsoules_UserCapsoulesId",
                table: "CapsoulesShareRequest",
                column: "UserCapsoulesId",
                principalTable: "UserCapsoules",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
